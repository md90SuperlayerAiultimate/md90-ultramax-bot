import os

# Menentukan direktori utama proyek secara dinamis
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# Mendefinisikan LOG_DIR (mengarahkan ke folder 'logs' yang sudah ada di root proyek Anda)
LOG_DIR = os.path.join(BASE_DIR, 'logs')

# Mendefinisikan zona waktu presisi untuk sinkronisasi tick data dan bot telegram
TIMEZONE = 'Asia/Jakarta'
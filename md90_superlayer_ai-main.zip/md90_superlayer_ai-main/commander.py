import subprocess
import time
import sys
import os

# Konfigurasi Trinitas MD90
bots = [
    {"name": "CORE_MERIDIAN", "path": "bot.py"},
    {"name": "SCALPER_SUPREME", "path": "MD90_All_Bot/main_scalping.py"},
    {"name": "COMPOUND_ENGINE", "path": "MD90_All_Bot/main_compound.py"}
]

processes = []

print("="*60)
print("🛡️ MD90 TRINITAS DEPLOYMENT: MERIDIAN - SCALPING - COMPOUND")
print("="*60)

for bot in bots:
    if not os.path.exists(bot['path']):
        print(f"⚠️ File {bot['path']} tidak ditemukan!")
        continue

    print(f"🚀 Launching {bot['name']}...")
    try:
        # Gunakan env saat ini dan paksa UTF-8
        current_env = os.environ.copy()
        current_env["PYTHONUTF8"] = "1"
        
        # Jalankan sebagai proses baru
        p = subprocess.Popen([sys.executable, bot['path']], env=current_env)
        processes.append(p)
        time.sleep(5) 
    except Exception as e:
        print(f"❌ Gagal menyalakan {bot['name']}: {e}")

print("\n✅ TRINITAS OPERASIONAL. JANGAN TUTUP JENDELA INI.")

try:
    while True:
        time.sleep(1)
except KeyboardInterrupt:
    print("\n🛑 Mematikan seluruh mesin...")
    for p in processes:
        p.terminate()
    print("🏁 Sistem Shutdown.")
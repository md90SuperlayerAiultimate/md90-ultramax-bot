#!/usr/bin/env python3
"""
MD90 ALLIN FUSION - Entry Point CLI
Bot Meridian Ultimate v2.0
"""

import os
import sys
import argparse
import asyncio
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Tambahkan path utils
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from bot import MeridianBot


def parse_args():
    parser = argparse.ArgumentParser(description="MD90 ALLIN FUSION Bot - Meridian Ultimate")
    parser.add_argument("--pair",      default=os.getenv("PAIR", "BTC/USDT"),         help="Trading pair")
    parser.add_argument("--mode",      choices=["scalp", "swing", "hybrid"],
                        default=os.getenv("MODE", "hybrid"))
    parser.add_argument("--timeframe", default=os.getenv("TIMEFRAME", "15m"))
    parser.add_argument("--dry",       action="store_true", help="Paper trading (dry run)")
    parser.add_argument("--live",      action="store_true", help="Live trading mode")
    parser.add_argument("--api_key",   default=os.getenv("EXCHANGE_API_KEY", ""))
    parser.add_argument("--api_secret",default=os.getenv("EXCHANGE_API_SECRET", ""))
    parser.add_argument("--csv",       help="CSV file for backtest")
    parser.add_argument("--equity",    type=float, default=float(os.getenv("START_EQUITY", "2000.0")))
    parser.add_argument("--risk",      type=float, default=float(os.getenv("RISK_PER_TRADE", "0.01")))
    parser.add_argument("--loop",      type=int,   default=int(os.getenv("LOOP_SECONDS", "30")))
    parser.add_argument("--log",       default=os.getenv("LOG_FILE", "logs/md90_trades.jsonl"))
    parser.add_argument("--soccer",    action="store_true", help="Enable soccer analyzer")
    parser.add_argument("--match",     help="JSON string or key=value pairs for soccer match data")
    return parser.parse_args()


def main():
    args = parse_args()

    # Siapkan konfigurasi
    cfg = {
        "pair":                 args.pair,
        "mode":                 args.mode,
        "timeframe":            args.timeframe,
        "dry_run":              args.dry or not args.live,
        "live_mode":            args.live,
        "api_key":              args.api_key,
        "api_secret":           args.api_secret,
        "csv_path":             args.csv,
        "start_equity":         args.equity,
        "risk_per_trade":       args.risk,
        "loop_seconds":         args.loop,
        "log_file":             args.log,
        "soccer_enabled":       args.soccer,
        "soccer_match_data":    None,
        # Parameter dari environment
        "rsi_len":              int(os.getenv("RSI_LEN",  "14")),
        "atr_len":              int(os.getenv("ATR_LEN",  "14")),
        "rsi_buy_scalp":        int(os.getenv("RSI_BUY_SCALP",  "38")),
        "rsi_sell_scalp":       int(os.getenv("RSI_SELL_SCALP", "62")),   # BUG FIX: was "RLI_SELL_SCALP"
        "rsi_buy_swing":        int(os.getenv("RSI_BUY_SWING",  "45")),
        "rsi_sell_swing":       int(os.getenv("RSI_SELL_SWING", "55")),
        "atr_sl_mult":          float(os.getenv("ATR_SL_MULT",  "1.2")),
        "atr_tp_mult":          float(os.getenv("ATR_TP_MULT",  "1.6")),
        "trail_mult":           float(os.getenv("TRAIL_MULT",   "1.0")),
        "slip":                 float(os.getenv("SLIP",         "0.0005")),
        "max_consecutive_losses": int(os.getenv("MAX_CONSECUTIVE_LOSSES", "3")),
        "all_in_threshold":     float(os.getenv("ALL_IN_THRESHOLD",  "0.85")),
        "fusion_enabled":       os.getenv("FUSION_ENABLED", "true").lower() == "true",
        "min_confidence":       float(os.getenv("MIN_CONFIDENCE",    "75")),
        "min_fusion_score":     float(os.getenv("MIN_FUSION_SCORE",  "0.75")),
        "league_avg_goals":     float(os.getenv("LEAGUE_AVG_GOALS",  "2.5")),
        "league_avg_corners":   float(os.getenv("LEAGUE_AVG_CORNERS","10.0")),
        "exchange":             os.getenv("EXCHANGE_NAME",   "binance"),
        "ml_config_file":       os.getenv("ML_CONFIG_FILE", "md90_ml_config.json"),
        "copy_trade_enabled":   os.getenv("COPY_TRADE_ENABLED", "true").lower() == "true",
    }

    # Jika ada data match untuk soccer
    if args.match:
        try:
            import json
            match_data = json.loads(args.match)
        except Exception:
            match_data = {}
            for item in args.match.split():
                if "=" in item:
                    k, v = item.split("=", 1)
                    try:
                        match_data[k] = float(v) if "." in v else int(v)
                    except Exception:
                        match_data[k] = v
        cfg["soccer_match_data"] = match_data

    # Konfirmasi live mode
    if cfg["live_mode"] and not cfg["dry_run"]:
        print("⚠️  LIVE MODE AKTIF. Ketik 'CONFIRM' untuk melanjutkan.")
        confirm = input("> ").strip()
        if confirm != "CONFIRM":
            print("Dibatalkan.")
            sys.exit(0)

    # Buat direktori log
    os.makedirs(os.path.dirname(cfg["log_file"]) if os.path.dirname(cfg["log_file"]) else "logs", exist_ok=True)

    # Jalankan bot
    bot = MeridianBot(cfg)
    asyncio.run(bot.run())


if __name__ == "__main__":
    main()

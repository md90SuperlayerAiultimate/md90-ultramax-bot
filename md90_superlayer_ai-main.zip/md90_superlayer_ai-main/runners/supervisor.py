import time, subprocess, os

TARGETS = [
    ("scripts/collector_binance.py", []),
    ("scripts/collector_mexc.py", []),
    ("runners/run_all_bots.py", []),
    ("scripts/weekly_report.py", []),
]

def spawn(cmd):
    return subprocess.Popen(["python3", cmd])

def main():
    procs = {cmd: spawn(cmd) for cmd, _ in TARGETS}
    while True:
        for cmd, _ in list(TARGETS):
            p = procs.get(cmd)
            if p and p.poll() is not None:
                print("[supervisor] restarting", cmd)
                procs[cmd] = spawn(cmd)
        time.sleep(5)

if __name__ == "__main__":
    main()

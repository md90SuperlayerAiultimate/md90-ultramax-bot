import os, subprocess, time

BOT_DIRS = ["bots/scalping", "bots/compound", "bots/sniper", "bots/parlay", "bots/spaceman", "bots/togel"]

def discover_scripts():
    scripts = []
    for d in BOT_DIRS:
        if os.path.isdir(d):
            for fn in os.listdir(d):
                if fn.endswith(".py"):
                    scripts.append(os.path.join(d, fn))
    return scripts

def main():
    procs = []
    for script in discover_scripts():
        print("[run] starting", script)
        procs.append(subprocess.Popen(["python3", script]))
        time.sleep(0.5)
    for p in procs:
        p.wait()

if __name__ == "__main__":
    main()

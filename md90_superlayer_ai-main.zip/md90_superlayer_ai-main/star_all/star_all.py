import os
import subprocess

print("🔧 Menginstal dependensi jika belum...")
subprocess.call(["pip", "install", "xgboost", "pandas", "scikit-learn", "flask", "python-telegram-bot"])

print("🚀 Menjalankan semua file Python di folder ini...")

files = [f for f in os.listdir() if f.endswith(".py") and f != "start_all.py"]

for file in files:
    print(f"▶️ Menjalankan: {file}")
    subprocess.run(["python", file])

print("✅ Semua file telah dijalankan.")

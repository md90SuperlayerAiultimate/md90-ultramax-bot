import subprocess

files = [
    "main.py",
    "md90_superlayer_ai.py",
    "md90_dashboard_ui.py",
    "telegram_bot.py"
]

for file in files:
    print(f"▶️ Menjalankan: {file}")
    subprocess.run(["python", file])

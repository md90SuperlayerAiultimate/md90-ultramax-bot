#!/usr/bin/env python3
"""
MD90 Meridian v3 — Polymarket Latency Arbitrage
- 3 explicit flags WAJIB sebelum go live
- 20% daily drawdown kill switch
- Direct Binance WS (<50ms)
- SQLite trade logging
- Terminal dashboard
"""
import os,sys,asyncio,argparse,logging,time,yaml
from dotenv import load_dotenv
load_dotenv()
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[logging.FileHandler("logs/meridian.log"), logging.StreamHandler(sys.stdout)]
)
logger = logging.getLogger("meridian")

def load_config(path="config/settings.yaml"):
    return yaml.safe_load(open(path)) if os.path.exists(path) else {}

def parse_args():
    p = argparse.ArgumentParser(description="MD90 Meridian Polymarket Bot v3")
    p.add_argument("--dry",       action="store_true")
    p.add_argument("--live",      action="store_true")
    p.add_argument("--confirm1",  action="store_true", help="Live flag 1/3")
    p.add_argument("--confirm2",  action="store_true", help="Live flag 2/3")
    p.add_argument("--confirm3",  action="store_true", help="Live flag 3/3")
    p.add_argument("--markets",   nargs="+", default=["BTC-15MIN","BTC-5MIN","ETH-15MIN"])
    p.add_argument("--capital",   type=float, default=5000.0)
    p.add_argument("--max-trade", type=float, default=0.08, help="Max portfolio%% per trade")
    p.add_argument("--kill-pct",  type=float, default=20.0, help="Daily drawdown kill switch")
    p.add_argument("--min-edge",  type=float, default=5.0,  help="Min edge%% to execute")
    p.add_argument("--config",    default="config/settings.yaml")
    p.add_argument("--no-dash",   action="store_true")
    return p.parse_args()

def verify_live(args) -> bool:
    if not args.live:
        return False
    flags = [args.confirm1, args.confirm2, args.confirm3]
    if not all(flags):
        print(f"\n❌ LIVE mode butuh 3 flags. Kamu set {sum(flags)}/3.")
        print("   Gunakan: --live --confirm1 --confirm2 --confirm3")
        print("   Atau --dry untuk paper trading dulu (WAJIB 200+ trades)\n")
        sys.exit(1)
    print("\n" + "⚠️ "*20)
    print(f"LIVE MODE — REAL MONEY | Capital: ${args.capital:,.2f}")
    print("Ketik 'I UNDERSTAND THE RISKS' untuk lanjut:\n> ", end="")
    if input().strip() != "I UNDERSTAND THE RISKS":
        print("Dibatalkan."); sys.exit(0)
    return True

async def run_bot(config: dict):
    from src.data.binance_ws_feed import BinancePriceFeed, LatencyOracleEngine
    from src.data.trade_logger import TradeLogger
    from src.risk.risk_manager import PolymarketRiskManager
    from src.execution.polygon_executor import PolygonExecutionEngine
    from src.core.dashboard import TerminalDashboard

    dry_run   = config["dry_run"]
    markets   = config["target_markets"]
    capital   = config["capital"]["total_usd"]
    kill_pct  = config.get("kill_pct", 20.0) / 100
    min_edge  = config.get("min_edge_pct", 5.0)
    max_trade = config.get("max_trade_pct", 0.08)

    logger.info(f"🚀 Meridian v3 | {'DRY' if dry_run else 'LIVE'} | {markets}")

    trade_db = TradeLogger()
    trade_db.log_event("BOT_START", f"dry={dry_run} capital={capital}")

    binance  = BinancePriceFeed(symbols=["BTCUSDT","ETHUSDT","SOLUSDT"])
    oracle   = LatencyOracleEngine(binance)
    oracle.MIN_EDGE_PCT   = min_edge
    oracle.MIN_CONFIDENCE = 0.85

    risk_cfg = {**config.get("risk",{}),
                "total_usd": capital,
                "max_position_usd": capital * max_trade,
                "circuit_breaker_drawdown": kill_pct}
    risk = PolymarketRiskManager(risk_cfg)
    exec_ = PolygonExecutionEngine({"dry_run": dry_run})
    dash  = TerminalDashboard(trade_db, risk, binance)

    THRESHOLDS = {
        "BTC-15MIN":104000,"BTC-5MIN":104000,
        "ETH-15MIN":3800,  "ETH-5MIN":3800,
        "SOL-1DAY":150
    }

    async def arb_loop():
        trades = 0
        while True:
            try:
                daily   = trade_db.get_daily_pnl() or {}
                day_pnl = daily.get("net_pnl", 0)
                loss_pct = abs(day_pnl)/capital if day_pnl < 0 else 0
                risk.circuit_breakers.check_daily_loss(loss_pct)

                if risk.circuit_breakers.is_triggered():
                    await asyncio.sleep(5); continue

                for mid in markets:
                    # pm_yes_price: dari WebSocket feed (placeholder 0.5 jika belum konek)
                    pm_yes_price = 0.5
                    threshold    = THRESHOLDS.get(mid, 100000)
                    opp = oracle.get_arbitrage_opportunity(mid, pm_yes_price, threshold)
                    if not opp:
                        continue

                    sig = {
                        "type":"HFT_LATENCY","market_id":mid,
                        "side":opp["direction"],"confidence":opp["confidence"],
                        "edge_pct":opp["edge_pct"],"implied_prob":opp["implied_prob"],
                        "pm_price":opp["pm_price"],"binance_price":opp["binance_price"],
                        "latency_ms":opp["latency_ms"],
                        "size_suggestion": risk.calculate_kelly_size(opp),
                    }
                    valid, reason = risk.validate_signal(sig)
                    if not valid: continue

                    trade_id = trade_db.log_trade_open(sig, dry_run=dry_run)
                    result   = await exec_.execute_signals([sig])
                    if result and result[0].get("status") in ("OK","SIMULATED"):
                        trades += 1
                        icon = "📋" if dry_run else "💰"
                        logger.info(f"{icon} #{trades}: {opp['direction']} {mid} "
                                    f"edge={opp['edge_pct']:.1f}% "
                                    f"conf={opp['confidence']*100:.0f}% "
                                    f"${sig['size_suggestion']:.2f}")
            except Exception as e:
                logger.error(f"Arb loop: {e}")
            await asyncio.sleep(0.1)

    tasks = [
        asyncio.create_task(binance.start()),
        asyncio.create_task(arb_loop()),
    ]
    if not config.get("no_dashboard"):
        tasks.append(asyncio.create_task(dash.start()))

    try:
        await asyncio.gather(*tasks)
    except (KeyboardInterrupt, asyncio.CancelledError):
        logger.info("🛑 Stopped")
    finally:
        trade_db.log_event("BOT_STOP", str(trade_db.get_stats()))
        logger.info("✅ Shutdown complete")

def main():
    args   = parse_args()
    config = load_config(args.config)
    live   = verify_live(args)

    config.update({
        "dry_run":True if not live else False,
        "live_mode":live,
        "target_markets":args.markets,
        "kill_pct":args.kill_pct,
        "min_edge_pct":args.min_edge,
        "max_trade_pct":args.max_trade,
        "no_dashboard":args.no_dash,
        "capital":{"total_usd":args.capital},
    })
    if "risk" not in config: config["risk"] = {}
    os.makedirs("logs", exist_ok=True)

    print(f"\n{'─'*60}")
    print(f"  MD90 MERIDIAN v3 | {'⚠️ LIVE' if live else '📋 PAPER'}")
    print(f"  Markets : {args.markets}")
    print(f"  Capital : ${args.capital:,.2f}")
    print(f"  Min Edge: {args.min_edge:.1f}% | Kill: {args.kill_pct:.0f}% | Max/trade: {args.max_trade*100:.0f}%")
    print(f"{'─'*60}\n")

    asyncio.run(run_bot(config))

if __name__ == "__main__":
    main()

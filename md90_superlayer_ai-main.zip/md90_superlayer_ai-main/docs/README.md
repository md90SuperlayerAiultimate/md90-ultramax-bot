# md90_superlayer_ai

## Overview
This repository is designed for a modular architecture to separate concerns clearly.

## Directory Structure
- `config/`: Configuration files for the application.
- `core/`: Core logic and functionalities.
- `strategies/`: Implementations of different strategies.
- `utils/`: Utility functions.
- `docs/`: Documentation.

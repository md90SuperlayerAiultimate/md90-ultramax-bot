"""
MD90 Meridian - Polygon Execution Engine
Eksekusi order di Polymarket via Web3/Polygon blockchain
"""

import os
import logging
import asyncio
from typing import Optional, Dict, List

logger = logging.getLogger(__name__)

try:
    from web3 import Web3
    from eth_account import Account
    WEB3_OK = True
except ImportError:
    WEB3_OK = False

try:
    import aiohttp
    AIOHTTP_OK = True
except ImportError:
    AIOHTTP_OK = False


class NonceManager:
    """Kelola nonce untuk HFT — hindari collision di Polygon"""

    def __init__(self, web3, address: str):
        self.web3    = web3
        self.address = address
        self._nonce: Optional[int] = None

    async def get_nonce(self) -> int:
        if self._nonce is None:
            self._nonce = self.web3.eth.get_transaction_count(self.address, "pending")
        return self._nonce

    def increment(self):
        if self._nonce is not None:
            self._nonce += 1

    def reset(self):
        self._nonce = None


class PolymarketCLOBClient:
    """
    Client untuk Polymarket CLOB (Central Limit Order Book) API.
    Eksekusi order via REST API Polymarket.
    """

    CLOB_URL = "https://clob.polymarket.com"

    def __init__(self, api_key: str, secret: str, passphrase: str):
        self.api_key    = api_key
        self.secret     = secret
        self.passphrase = passphrase

    async def place_order(self,
                          market_id: str,
                          side:      str,   # 'BUY' | 'SELL'
                          outcome:   str,   # 'YES' | 'NO'
                          size:      float,
                          price:     float,
                          order_type: str = "MARKET") -> Optional[dict]:
        """Place order ke Polymarket CLOB"""
        if not AIOHTTP_OK:
            logger.error("aiohttp diperlukan untuk CLOB client")
            return None

        payload = {
            "market":     market_id,
            "side":       side,
            "outcome":    outcome,
            "size":       str(round(size, 2)),
            "price":      str(round(price, 4)),
            "type":       order_type,
        }

        headers = {
            "POLY-API-KEY":    self.api_key,
            "POLY-PASSPHRASE": self.passphrase,
            "Content-Type":    "application/json",
        }

        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    f"{self.CLOB_URL}/order",
                    json=headers,
                    headers=headers,
                    timeout=aiohttp.ClientTimeout(total=5)
                ) as resp:
                    if resp.status in (200, 201):
                        result = await resp.json()
                        logger.info(f"✅ Order placed: {market_id} {outcome} {side} ${size:.2f}")
                        return result
                    else:
                        body = await resp.text()
                        logger.error(f"❌ Order failed ({resp.status}): {body}")
                        return None
        except asyncio.TimeoutError:
            logger.error("❌ Order timeout (>5s) — Polymarket CLOB slow")
            return None
        except Exception as e:
            logger.error(f"❌ Order error: {e}")
            return None

    async def cancel_order(self, order_id: str) -> bool:
        if not AIOHTTP_OK:
            return False
        headers = {
            "POLY-API-KEY":    self.api_key,
            "POLY-PASSPHRASE": self.passphrase,
        }
        try:
            async with aiohttp.ClientSession() as session:
                async with session.delete(
                    f"{self.CLOB_URL}/order/{order_id}",
                    headers=headers,
                    timeout=aiohttp.ClientTimeout(total=5)
                ) as resp:
                    return resp.status == 200
        except Exception:
            return False

    async def cancel_all_pending_orders(self) -> bool:
        """Emergency: cancel semua pending orders"""
        headers = {
            "POLY-API-KEY":    self.api_key,
            "POLY-PASSPHRASE": self.passphrase,
        }
        try:
            async with aiohttp.ClientSession() as session:
                async with session.delete(
                    f"{self.CLOB_URL}/orders",
                    headers=headers,
                    timeout=aiohttp.ClientTimeout(total=10)
                ) as resp:
                    ok = resp.status == 200
                    if ok:
                        logger.info("✅ All pending orders cancelled")
                    return ok
        except Exception as e:
            logger.error(f"Cancel all orders error: {e}")
            return False

    async def get_portfolio(self) -> dict:
        """Ambil posisi dan balance dari Polymarket"""
        headers = {
            "POLY-API-KEY":    self.api_key,
            "POLY-PASSPHRASE": self.passphrase,
        }
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    f"{self.CLOB_URL}/balance",
                    headers=headers,
                    timeout=aiohttp.ClientTimeout(total=10)
                ) as resp:
                    if resp.status == 200:
                        return await resp.json()
        except Exception as e:
            logger.warning(f"Portfolio fetch error: {e}")
        return {}


class PolygonExecutionEngine:
    """
    Orchestrator eksekusi: validasi → CLOB order → monitoring
    Support DRY_RUN mode untuk paper trading.
    """

    def __init__(self, config: dict):
        self.config  = config
        self.dry_run = config.get("dry_run", True)

        # CLOB client
        self.clob = PolymarketCLOBClient(
            api_key    = os.getenv("POLYMARKET_API_KEY",    ""),
            secret     = os.getenv("POLYMARKET_SECRET",    ""),
            passphrase = os.getenv("POLYMARKET_PASSPHRASE", ""),
        )

        self.pending_orders: Dict[str, dict] = {}
        self.execution_log:  List[dict]      = []

    # ------------------------------------------------------------------
    async def execute_signals(self, signals: List[dict]) -> List[dict]:
        """Eksekusi list signals yang sudah divalidasi"""
        results = []
        for sig in signals:
            result = await self._execute_one(sig)
            results.append(result)
        return results

    async def _execute_one(self, signal: dict) -> dict:
        market_id = signal.get("market_id",      "")
        side      = signal.get("side",            "YES")
        size_usd  = signal.get("size_suggestion", 10.0)
        sig_type  = signal.get("type",            "UNKNOWN")

        # Convert signal side ke CLOB format
        outcome   = side if side in ("YES", "NO") else "YES"
        order_side = "BUY"  # Selalu BUY outcome di Polymarket (buy YES atau buy NO)

        if self.dry_run:
            result = {
                "dry_run":   True,
                "market_id": market_id,
                "outcome":   outcome,
                "size_usd":  size_usd,
                "strategy":  sig_type,
                "status":    "SIMULATED",
            }
            logger.info(f"📋 DRY RUN: {sig_type} {outcome} {market_id} ${size_usd:.2f}")
        else:
            # Get current price dari orderbook
            price = signal.get("price", 0.5)
            resp  = await self.clob.place_order(
                market_id  = market_id,
                side       = order_side,
                outcome    = outcome,
                size       = size_usd,
                price      = price,
                order_type = "MARKET",
            )
            result = {
                "market_id": market_id,
                "outcome":   outcome,
                "size_usd":  size_usd,
                "strategy":  sig_type,
                "status":    "OK" if resp else "FAILED",
                "response":  resp,
            }

        self.execution_log.append(result)
        return result

    async def cancel_all_pending_orders(self):
        if not self.dry_run:
            await self.clob.cancel_all_pending_orders()
        logger.info("All pending orders cancelled (emergency)")

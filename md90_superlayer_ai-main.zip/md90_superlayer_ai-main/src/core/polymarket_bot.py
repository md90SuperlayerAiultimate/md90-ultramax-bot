"""
MD90 Meridian - PolymarketBot (Orchestrator)
Integrasi penuh: DataFeed → Strategy → Risk → Execution → Monitoring
"""

import asyncio
import logging
import os
import time
from typing import Dict, List, Optional

from src.data.websocket_feed import PolymarketWebSocketFeed
from src.strategies.hft_latency import HFTLatencyStrategy, OracleFeed
from src.strategies.reverse_strategy import ReverseStrategy
from src.strategies.correlation import CorrelationArbitrageStrategy
from src.risk.risk_manager import PolymarketRiskManager
from src.execution.polygon_executor import PolygonExecutionEngine

logger = logging.getLogger(__name__)


class PolymarketBot:
    """
    Bot Polymarket lengkap — 5 layer architecture:
    Layer 1: Data Ingestion (WebSocket)
    Layer 2: Strategy Engine (HFT + Reverse + Correlation)
    Layer 3: Risk Fortress (Kelly + Circuit Breakers)
    Layer 4: Execution Engine (CLOB API)
    Layer 5: Monitoring (Telegram + Dashboard)
    """

    def __init__(self, config: dict):
        self.config  = config
        self.running = False
        self.dry_run = config.get("dry_run", True)

        # Layer 1: Data
        self.feed = PolymarketWebSocketFeed(
            api_key   = os.getenv("POLYMARKET_API_KEY", ""),
            on_update = self._on_market_update,
        )

        # Layer 2: Strategies
        oracle            = OracleFeed()
        self.hft          = HFTLatencyStrategy(
                                config.get("strategies", {}).get("hft_latency", {}),
                                oracle, self.feed
                            )
        self.reverse      = ReverseStrategy(
                                config.get("strategies", {}).get("reverse_strategy", {})
                            )
        self.corr_arb     = CorrelationArbitrageStrategy(
                                config.get("strategies", {}).get("correlation_arb", {}),
                                min_gap=0.05
                            )

        # Layer 3: Risk
        self.risk = PolymarketRiskManager(config.get("risk", {}))

        # Layer 4: Execution
        self.execution = PolygonExecutionEngine(config)

        # State
        self.target_markets: List[str] = config.get("target_markets", [
            "BTC-15MIN", "ETH-15MIN"
        ])
        self.last_strategy_eval = 0.0
        self.last_rebalance     = 0.0
        self.total_trades       = 0
        self.total_pnl          = 0.0

    # ------------------------------------------------------------------
    async def run(self):
        """Main event loop"""
        self.running = True
        logger.info(f"🚀 PolymarketBot STARTED | Mode: {'DRY RUN' if self.dry_run else 'LIVE'}")
        print(f"🎯 Polymarket Bot — {'PAPER' if self.dry_run else '⚠️ LIVE'} mode")
        print(f"   Markets: {self.target_markets}")

        # Connect ke WebSocket feed
        try:
            await self.feed.connect()
            for market_id in self.target_markets:
                await self.feed.subscribe_market(market_id)
        except Exception as e:
            logger.warning(f"WebSocket connect failed: {e} — using REST fallback")

        # Start parallel tasks
        tasks = [
            asyncio.create_task(self._high_freq_loop()),    # 1 detik
            asyncio.create_task(self._strategy_loop()),     # 30 detik
            asyncio.create_task(self._rebalance_loop()),    # 5 menit
            asyncio.create_task(self._listen_feed()),       # WebSocket listen
        ]

        try:
            await asyncio.gather(*tasks)
        except KeyboardInterrupt:
            print("\n🛑 Bot stopped by user")
        finally:
            await self._shutdown()

    # ------------------------------------------------------------------
    async def _high_freq_loop(self):
        """Tier 1: High frequency (setiap 1 detik)"""
        while self.running:
            try:
                # Update portfolio state
                all_markets = self.feed.get_all_markets()

                # Check circuit breakers
                if self.risk.circuit_breakers.is_triggered():
                    logger.warning(f"⚡ Circuit breaker active: {self.risk.circuit_breakers.reason}")
                    await asyncio.sleep(1)
                    continue

                # HFT scan per market
                for market_id in self.target_markets:
                    hft_signal = await self.hft.scan(market_id)
                    if hft_signal and hft_signal.confidence > 0.7:
                        await self._process_signal({
                            "type":            "HFT",
                            "market_id":       hft_signal.market_id,
                            "side":            hft_signal.direction,
                            "confidence":      hft_signal.confidence,
                            "size_suggestion": self.risk.calculate_kelly_size({
                                "confidence": hft_signal.confidence
                            }),
                            "reasoning":       hft_signal.reasoning,
                        })

            except Exception as e:
                logger.error(f"HF loop error: {e}")

            await asyncio.sleep(1)

    async def _strategy_loop(self):
        """Tier 2: Strategy evaluation (setiap 30 detik)"""
        while self.running:
            try:
                all_markets = self.feed.get_all_markets()
                if not all_markets:
                    await asyncio.sleep(30)
                    continue

                signals = []

                # Reverse Strategy
                for market_id, state in all_markets.items():
                    market_data = {**state, "id": market_id}
                    rev_signals = self.reverse.evaluate(market_data)
                    signals.extend(rev_signals)

                # Correlation Arbitrage
                corr_signals = self.corr_arb.evaluate(all_markets)
                signals.extend(corr_signals)

                # Process all signals dengan risk validation
                for sig in signals:
                    await self._process_signal(sig)

                logger.info(f"📊 Strategy eval: {len(signals)} signals generated")

            except Exception as e:
                logger.error(f"Strategy loop error: {e}")

            await asyncio.sleep(30)

    async def _rebalance_loop(self):
        """Tier 3: Portfolio rebalancing (setiap 5 menit)"""
        while self.running:
            try:
                skew = self.risk.portfolio.get_inventory_skew()
                total_exp = self.risk.portfolio.get_total_exposure()

                logger.info(f"♻️  Rebalance: skew={skew:.2f} exposure=${total_exp:.0f}")

                # Jika skew terlalu besar, flag untuk adjustment
                if abs(skew) > self.risk.max_inventory_skew:
                    logger.warning(f"⚠️  Inventory skew high: {skew:.2f}")

                # Reset daily stats tengah malam
                # (simplified — production pakai timezone aware)
                if time.localtime().tm_hour == 0 and time.localtime().tm_min < 5:
                    self.risk.reset_daily()

            except Exception as e:
                logger.error(f"Rebalance loop error: {e}")

            await asyncio.sleep(300)  # 5 menit

    async def _listen_feed(self):
        """WebSocket listener"""
        try:
            await self.feed.listen()
        except Exception as e:
            logger.warning(f"Feed listen error: {e}")

    # ------------------------------------------------------------------
    async def _process_signal(self, signal: dict):
        """Validasi + eksekusi satu signal"""
        is_valid, reason = self.risk.validate_signal(signal)
        if not is_valid:
            logger.debug(f"Signal rejected ({reason}): {signal.get('type')} {signal.get('market_id')}")
            return

        # Kelly sizing
        if signal.get("size_suggestion", 0) <= 0:
            signal["size_suggestion"] = self.risk.calculate_kelly_size(signal)

        # Eksekusi
        results = await self.execution.execute_signals([signal])
        for r in results:
            if r.get("status") in ("OK", "SIMULATED"):
                self.total_trades += 1
                self.risk.portfolio.open_position(
                    signal["market_id"],
                    signal.get("side", "YES"),
                    signal["size_suggestion"],
                )
                logger.info(
                    f"✅ Executed: {signal['type']} {signal.get('side')} "
                    f"{signal['market_id']} ${signal['size_suggestion']:.2f}"
                )

    # ------------------------------------------------------------------
    async def _on_market_update(self, event_type: str, data: dict):
        """Callback dari WebSocket feed"""
        pass  # Data sudah diupdate di orderbook_cache

    async def _shutdown(self):
        """Graceful shutdown"""
        self.running = False
        await self.execution.cancel_all_pending_orders()
        await self.feed.disconnect()
        logger.info(
            f"🏁 PolymarketBot shutdown. "
            f"Trades: {self.total_trades} | PnL: ${self.total_pnl:.2f}"
        )

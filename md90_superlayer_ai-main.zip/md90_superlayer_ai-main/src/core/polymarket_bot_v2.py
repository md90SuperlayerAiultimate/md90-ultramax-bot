"""
MD90 Meridian - PolymarketBot v2 (Full Production)
Upgrade dari artikel @0xFrogify:
- Binance WebSocket wss://stream.binance.com:9443
- SQLite logging (bukan JSONL)
- Terminal dashboard real-time
- Half-Kelly position sizing
- Kill switch 20% daily drawdown
- Paper mode by default (3 flags untuk live)
- BTC/ETH 5-min & 15-min contracts focus
"""

import asyncio
import logging
import os
import time
import threading
from typing import Dict, List, Optional

from src.data.websocket_feed import PolymarketWebSocketFeed
from src.data.binance_ws_feed import BinanceWSFeed
from src.strategies.hft_latency import HFTLatencyStrategy, OracleFeed
from src.strategies.reverse_strategy import ReverseStrategy
from src.strategies.correlation import CorrelationArbitrageStrategy
from src.risk.risk_manager import PolymarketRiskManager
from src.execution.polygon_executor import PolygonExecutionEngine
from src.core.sqlite_logger import SQLiteLogger
from src.core.dashboard import TerminalDashboard

logger = logging.getLogger(__name__)


class PolymarketBotV2:
    """
    Bot Polymarket v2 — Full Production Architecture.

    Latency arb flow:
    1. Binance WebSocket → harga BTC/ETH real-time (<50ms)
    2. Polymarket WebSocket → order book real-time
    3. Deteksi gap > 5% antara keduanya
    4. Validasi: confidence >85%, position <8% portfolio
    5. Half-Kelly sizing → place order via CLOB API
    6. Log ke SQLite → update dashboard
    """

    # BTC/ETH short duration contracts (fokus artikel)
    DEFAULT_MARKETS = [
        "BTC-15MIN", "BTC-5MIN",
        "ETH-15MIN", "ETH-5MIN",
    ]

    def __init__(self, config: dict):
        self.config    = config
        self.dry_run   = config.get("dry_run", True)
        self.running   = False

        # Equity tracking
        cap = config.get("capital", {})
        self.start_equity   = float(cap.get("total_usd", 5000))
        self.current_equity = self.start_equity
        self.daily_pnl      = 0.0
        self.total_trades   = 0

        # Kill switch: 20% daily drawdown (dari artikel)
        self.daily_loss_limit = float(
            config.get("risk", {}).get("circuit_breaker_drawdown", 0.20)
        )

        # Target markets
        self.target_markets = config.get("target_markets", self.DEFAULT_MARKETS)

        # Layer 1a: Binance WebSocket (NEW)
        self.binance_ws = BinanceWSFeed(
            symbols          = ["btcusdt", "ethusdt", "solusdt"],
            on_price_update  = self._on_binance_price,
        )

        # Layer 1b: Polymarket WebSocket
        self.poly_feed = PolymarketWebSocketFeed(
            api_key   = os.getenv("POLYMARKET_API_KEY", ""),
            on_update = self._on_poly_update,
        )

        # Layer 2: Strategies
        oracle       = OracleFeed()
        strat_cfg    = config.get("strategies", {})

        self.hft     = HFTLatencyStrategy(
            strat_cfg.get("hft_latency", {}), oracle, self.poly_feed
        )
        self.reverse = ReverseStrategy(strat_cfg.get("reverse_strategy", {}))
        self.corr    = CorrelationArbitrageStrategy(
            strat_cfg.get("correlation_arb", {}), min_gap=0.05
        )

        # Layer 3: Risk (half-Kelly dari artikel)
        risk_cfg = config.get("risk", {})
        risk_cfg.setdefault("kelly_fraction", 0.125)  # Half-Kelly = 0.25 * 0.5
        risk_cfg.setdefault("total_usd", self.start_equity)
        self.risk = PolymarketRiskManager(risk_cfg)

        # Layer 4: Execution
        self.execution = PolygonExecutionEngine(config)

        # SQLite Logger (NEW)
        self.db = SQLiteLogger(
            os.getenv("SQLITE_DB", "logs/meridian_trades.db")
        )
        self.db.log_system("BOT_START", f"equity={self.start_equity} dry_run={self.dry_run}")

        # Terminal Dashboard (NEW)
        self.dashboard = TerminalDashboard(
            sqlite_logger   = self.db,
            refresh_seconds = 5,
        )
        self.dashboard.start_equity    = self.start_equity
        self.dashboard.current_equity  = self.current_equity

        # Open positions: {market_id: {trade_id, open_time, ...}}
        self._open_positions: Dict[str, dict] = {}

    # ------------------------------------------------------------------
    async def run(self):
        """Main entry point"""
        self.running = True

        mode = "🔴 LIVE" if not self.dry_run else "📋 PAPER"
        print(f"\n{'='*60}")
        print(f"  MD90 MERIDIAN OMEGA v2 — {mode}")
        print(f"  Equity: ${self.start_equity:,.2f}")
        print(f"  Markets: {self.target_markets}")
        print(f"  Kill switch: {self.daily_loss_limit*100:.0f}% daily drawdown")
        print(f"  Kelly: half (0.125x)")
        print(f"{'='*60}\n")

        # Start terminal dashboard di thread terpisah
        dash_thread = threading.Thread(
            target=self.dashboard.run_blocking, daemon=True
        )
        dash_thread.start()

        # Connect feeds
        await self._connect_feeds()

        # Main tasks
        tasks = [
            asyncio.create_task(self._latency_arb_loop()),   # Core: 1 detik
            asyncio.create_task(self._strategy_loop()),      # 30 detik
            asyncio.create_task(self._risk_monitor_loop()),  # 5 detik
            asyncio.create_task(self._listen_poly()),
            asyncio.create_task(self._listen_binance()),
        ]

        try:
            await asyncio.gather(*tasks, return_exceptions=True)
        except KeyboardInterrupt:
            print("\n🛑 Stopped by user")
        finally:
            await self._shutdown()

    # ------------------------------------------------------------------
    async def _connect_feeds(self):
        """Connect ke semua WebSocket feeds"""
        # Binance WS
        try:
            await self.binance_ws.connect()
            self.dashboard.ws_binance_ok = True
            logger.info("✅ Binance WS connected")
        except Exception as e:
            logger.warning(f"Binance WS failed: {e}")
            self.dashboard.ws_binance_ok = False

        # Polymarket WS
        try:
            await self.poly_feed.connect()
            for market_id in self.target_markets:
                await self.poly_feed.subscribe_market(market_id)
            self.dashboard.ws_polymarket_ok = True
            logger.info("✅ Polymarket WS connected")
        except Exception as e:
            logger.warning(f"Polymarket WS failed: {e}")
            self.dashboard.ws_polymarket_ok = False

    async def _listen_poly(self):
        try:
            await self.poly_feed.listen()
        except Exception as e:
            logger.warning(f"Poly listen error: {e}")

    async def _listen_binance(self):
        try:
            await self.binance_ws.listen()
        except Exception as e:
            logger.warning(f"Binance listen error: {e}")

    # ------------------------------------------------------------------
    async def _latency_arb_loop(self):
        """
        CORE LOOP: Latency arbitrage setiap 1 detik.
        Deteksi gap Binance vs Polymarket > 5% → entry.
        """
        while self.running:
            try:
                if self.risk.circuit_breakers.is_triggered():
                    self.dashboard.circuit_active = True
                    self.dashboard.circuit_reason = self.risk.circuit_breakers.reason
                    await asyncio.sleep(1)
                    continue

                self.dashboard.circuit_active = False

                for market_id in self.target_markets:
                    pm_state = self.poly_feed.get_market_state(market_id)
                    if not pm_state:
                        continue

                    pm_price = pm_state.get("mid_price", 0.5)

                    # Deteksi lag Binance vs Polymarket
                    opp = self.binance_ws.detect_lag_opportunity(
                        polymarket_price    = pm_price,
                        polymarket_market_id = market_id,
                        min_edge_pct        = 5.0,  # >5% dari artikel
                    )

                    if not opp:
                        continue

                    # Confidence filter >85% (dari artikel)
                    confidence = min(0.99, 0.7 + opp["edge_pct"] / 50)
                    if confidence < 0.85:
                        continue

                    # Position limit <8% portfolio (dari artikel)
                    max_size = self.current_equity * 0.08

                    signal = {
                        "type":            "HFT_LATENCY_ARB",
                        "market_id":       market_id,
                        "side":            opp["direction"],
                        "confidence":      confidence,
                        "edge_pct":        opp["edge_pct"],
                        "price":           pm_price,
                        "size_suggestion": min(
                            max_size,
                            self.risk.calculate_kelly_size({
                                "confidence": confidence,
                                "expected_payoff": 1.0,
                            })
                        ),
                        "reasoning": (
                            f"Binance lag: edge={opp['edge_pct']:.1f}% "
                            f"implied={opp['implied_prob']:.3f} "
                            f"poly={pm_price:.3f}"
                        ),
                    }

                    await self._process_signal(signal)

            except Exception as e:
                logger.error(f"Latency arb loop error: {e}")

            await asyncio.sleep(1)

    # ------------------------------------------------------------------
    async def _strategy_loop(self):
        """Secondary strategies (Reverse + Correlation) setiap 30 detik"""
        while self.running:
            try:
                all_markets = self.poly_feed.get_all_markets()
                if not all_markets:
                    await asyncio.sleep(30)
                    continue

                signals = []

                for mid, state in all_markets.items():
                    rev = self.reverse.evaluate({**state, "id": mid})
                    signals.extend(rev)

                corr = self.corr.evaluate(all_markets)
                signals.extend(corr)

                for sig in signals:
                    await self._process_signal(sig)

            except Exception as e:
                logger.error(f"Strategy loop error: {e}")

            await asyncio.sleep(30)

    async def _risk_monitor_loop(self):
        """Monitor risiko dan daily drawdown setiap 5 detik"""
        while self.running:
            try:
                # Update dashboard
                self.dashboard.current_equity = self.current_equity
                self.dashboard.daily_pnl      = self.daily_pnl
                self.dashboard.daily_trades   = self.total_trades

                # Kill switch: 20% daily drawdown
                loss_pct = abs(self.daily_pnl) / self.start_equity if self.daily_pnl < 0 else 0
                if loss_pct >= self.daily_loss_limit:
                    self.risk.circuit_breakers.manual_trigger(duration=86400)  # 24 jam
                    msg = f"🛑 KILL SWITCH: {loss_pct*100:.1f}% daily drawdown"
                    logger.critical(msg)
                    self.db.log_system("KILL_SWITCH", msg)
                    self._send_telegram(msg)

                # Daily performance update ke SQLite setiap jam
                if int(time.time()) % 3600 < 5:
                    self.db.update_daily_performance()

            except Exception as e:
                logger.error(f"Risk monitor error: {e}")

            await asyncio.sleep(5)

    # ------------------------------------------------------------------
    async def _process_signal(self, signal: dict):
        """Validasi → sizing → eksekusi → log"""
        is_valid, reason = self.risk.validate_signal(signal)

        # Log signal ke SQLite
        self.db.log_signal(signal, executed=is_valid, reject_reason=reason)

        if not is_valid:
            return

        # Half-Kelly sizing (dari artikel: 0.5 * Kelly)
        if signal.get("size_suggestion", 0) <= 0:
            kelly_size = self.risk.calculate_kelly_size(signal)
            signal["size_suggestion"] = kelly_size * 0.5  # Half-Kelly

        # Cap di 8% equity
        max_size = self.current_equity * 0.08
        signal["size_suggestion"] = min(signal["size_suggestion"], max_size)

        if signal["size_suggestion"] < 1.0:
            return  # Minimum $1

        # Log trade open
        trade_id = self.db.log_trade_open({
            **signal,
            "entry_price": signal.get("price", 0),
            "size_usd":    signal["size_suggestion"],
        })

        # Eksekusi
        results = await self.execution.execute_signals([signal])

        for r in results:
            ok = r.get("status") in ("OK", "SIMULATED")
            if ok:
                self.total_trades += 1
                self._open_positions[signal["market_id"]] = {
                    "trade_id":    trade_id,
                    "open_time":   time.time(),
                    "entry_price": signal.get("price", 0),
                    "side":        signal.get("side", ""),
                    "size_usd":    signal["size_suggestion"],
                }
                self.risk.portfolio.open_position(
                    signal["market_id"],
                    signal.get("side", "YES"),
                    signal["size_suggestion"],
                )
                logger.info(
                    f"✅ {'DRY' if self.dry_run else 'LIVE'} | "
                    f"{signal['type']} | {signal.get('side')} | "
                    f"{signal['market_id']} | ${signal['size_suggestion']:.2f} | "
                    f"edge={signal.get('edge_pct', 0):.1f}% | "
                    f"conf={signal.get('confidence', 0)*100:.0f}%"
                )
                self._send_telegram(
                    f"📈 TRADE: {signal.get('side')} {signal['market_id']} "
                    f"${signal['size_suggestion']:.2f} "
                    f"edge={signal.get('edge_pct', 0):.1f}%"
                )

    # ------------------------------------------------------------------
    async def _on_binance_price(self, symbol: str, data: dict):
        """Callback saat ada update harga dari Binance"""
        pass  # Data sudah di-cache di binance_ws._prices

    async def _on_poly_update(self, event_type: str, data: dict):
        """Callback saat ada update dari Polymarket"""
        pass  # Data sudah di-cache di poly_feed.orderbook_cache

    # ------------------------------------------------------------------
    def _send_telegram(self, msg: str):
        """Kirim alert Telegram (non-blocking)"""
        token   = os.getenv("BOT_TOKEN", "")
        chat_id = os.getenv("TELEGRAM_CHAT_ID", os.getenv("OWNER_ID", ""))
        if not token or not chat_id:
            return
        try:
            import requests
            requests.post(
                f"https://api.telegram.org/bot{token}/sendMessage",
                json={"chat_id": chat_id, "text": f"🤖 MD90 Meridian\n{msg}"},
                timeout=5,
            )
        except Exception:
            pass

    # ------------------------------------------------------------------
    async def _shutdown(self):
        """Graceful shutdown"""
        self.running = False
        self.dashboard.stop()
        await self.execution.cancel_all_pending_orders()
        await self.poly_feed.disconnect()
        await self.binance_ws.disconnect()
        self.db.update_daily_performance()
        self.db.log_system(
            "BOT_STOP",
            f"trades={self.total_trades} pnl={self.daily_pnl:.4f} "
            f"equity={self.current_equity:.2f}"
        )
        stats = self.db.get_stats(days=1)
        print(f"\n{'='*50}")
        print(f"  SESSION SUMMARY")
        print(f"  Trades  : {stats['total_trades']}")
        print(f"  Win Rate: {stats['win_rate']*100:.1f}%")
        print(f"  PnL     : ${stats['total_pnl']:.4f}")
        print(f"  Avg Edge: {stats['avg_edge_pct']:.1f}%")
        print(f"{'='*50}\n")

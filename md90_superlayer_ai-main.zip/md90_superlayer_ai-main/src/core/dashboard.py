"""
MD90 Meridian - Terminal Live Dashboard
P&L, win rate, open positions, last 10 trades — refresh 2 detik
"""

import os, time, asyncio, logging
from datetime import datetime
logger = logging.getLogger(__name__)

def clr(): os.system("cls" if os.name == "nt" else "clear")
def c(text, code):
    codes = {"green":"\033[92m","red":"\033[91m","yellow":"\033[93m",
             "cyan":"\033[96m","bold":"\033[1m","reset":"\033[0m","dim":"\033[2m"}
    return f"{codes.get(code,'')}{text}{codes['reset']}"

class TerminalDashboard:
    def __init__(self, trade_logger, risk_manager=None, binance_feed=None):
        self.db = trade_logger
        self.risk = risk_manager
        self.binance = binance_feed
        self._running = False

    async def start(self, refresh: float = 2.0):
        self._running = True
        while self._running:
            try: self._render()
            except Exception as e: logger.debug(f"Dashboard: {e}")
            await asyncio.sleep(refresh)

    def stop(self): self._running = False

    def _render(self):
        clr()
        now   = datetime.now().strftime("%Y-%m-%d %H:%M:%S WITA")
        stats = self.db.get_stats(days=1)
        opens = self.db.get_open_positions()
        trs   = self.db.get_last_trades(10)

        print(c("═"*70, "cyan"))
        print(c("  🎯 MD90 MERIDIAN OMEGA — LIVE DASHBOARD", "bold"))
        print(c(f"  {now}", "dim"))
        print(c("═"*70, "cyan"))

        pnl = stats.get("pnl", 0)
        wr  = stats.get("win_rate", 0)
        print(f"\n  {'P&L (today)':<22} {c(f'${pnl:+.2f}', 'green' if pnl>=0 else 'red')}")
        print(f"  {'Win Rate':<22} {c(f'{wr:.1f}%', 'green' if wr>=70 else 'yellow' if wr>=50 else 'red')}")
        print(f"  {'Total / W / L':<22} {stats.get('total',0)} / {stats.get('wins',0)} / {stats.get('losses',0)}")
        print(f"  {'Avg Edge':<22} {stats.get('avg_edge',0):.2f}%")

        if self.binance:
            prices = self.binance.get_all_prices()
            if prices:
                print(f"\n  {c('📡 BINANCE', 'cyan')}")
                for sym, d in list(prices.items())[:4]:
                    dp = d.get("delta_pct", 0)
                    ar = "▲" if dp>=0 else "▼"
                    print(f"  {sym:<12} ${d['price']:>12,.2f}  "
                          f"{c(f'{ar}{abs(dp):.3f}%','green' if dp>=0 else 'red')}  "
                          f"{c(f'{d.get(\"latency_ms\",0):.0f}ms','dim')}")

        if self.risk:
            cb = self.risk.circuit_breakers
            st = c("🔴 TRIGGERED","red") if cb.is_triggered() else c("🟢 OK","green")
            dl = getattr(cb, "daily_loss_pct", 0)*100
            print(f"\n  Circuit Breaker: {st}  |  Daily Loss: {c(f'{dl:.1f}%','red' if dl>5 else 'green')} / 20%")

        print(f"\n  {c('OPEN POSITIONS','cyan')}")
        if opens:
            for p in opens[:5]:
                age = int(time.time()-p["timestamp"])
                print(f"  {p['market_id']:<16} {p['side']:<5} ${p['size_usd']:.2f}  {c(f'{age}s','dim')}")
        else:
            print(c("  (none)", "dim"))

        print(f"\n  {c('LAST 10 TRADES','cyan')}")
        if trs:
            print(f"  {'Time':<9}{'Market':<16}{'Side':<5}{'Size':>7}{'Edge':>7}{'Status':<10}{'PnL':>8}")
            for t in trs[:10]:
                ts  = datetime.fromtimestamp(t["timestamp"]).strftime("%H:%M:%S")
                st  = t["status"]
                sc  = "green" if st=="WIN" else "red" if st=="LOSS" else "dim"
                pv  = t.get("pnl") or 0
                print(f"  {ts:<9}{t['market_id']:<16}{t['side']:<5}"
                      f"${t['size_usd']:>6.2f}{t.get('edge_pct',0):>6.1f}%"
                      f"  {c(f'{st:<8}',sc)} {c(f'${pv:+.2f}','green' if pv>=0 else 'red')}")
        else:
            print(c("  (no trades yet)", "dim"))

        print(f"\n{c('═'*70,'cyan')}")
        print(c("  Ctrl+C to stop | DRY RUN mode — no real money", "dim"))

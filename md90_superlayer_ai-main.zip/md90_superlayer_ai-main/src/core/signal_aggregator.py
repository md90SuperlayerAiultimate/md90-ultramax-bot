"""
MD90 Meridian - Signal Aggregator
Priority queue, conflict resolution, conviction scoring untuk semua strategy signals
"""

import time
import logging
from typing import List, Dict, Optional, Tuple
from collections import defaultdict

logger = logging.getLogger(__name__)

# Priority: lebih kecil = lebih prioritas
STRATEGY_PRIORITY = {
    "CORRELATION_ARB": 1,   # Near risk-free — eksekusi pertama
    "HFT":             2,   # Latency sensitive — eksekusi segera
    "REVERSE":         3,   # Contrarian — medium priority
    "MARKET_MAKE":     4,   # Passive income — lowest priority
    "AI_EDGE":         3,   # AI arbitrage
}


class Signal:
    """Representasi satu signal trading"""

    def __init__(self, raw: dict):
        self.type        = raw.get("type",            "UNKNOWN")
        self.market_id   = raw.get("market_id",       "")
        self.side        = raw.get("side",             "YES")
        self.confidence  = float(raw.get("confidence", 0.5))
        self.size_usd    = float(raw.get("size_suggestion", 0.0))
        self.reasoning   = raw.get("reasoning",       "")
        self.urgency     = raw.get("urgency",         "normal")
        self.timestamp   = time.time()
        self.priority    = STRATEGY_PRIORITY.get(self.type, 99)
        self._raw        = raw

    def to_dict(self) -> dict:
        return {
            **self._raw,
            "priority":  self.priority,
            "timestamp": self.timestamp,
        }

    def conviction_score(self) -> float:
        """
        Skor gabungan: confidence × priority weight × urgency bonus.
        Semakin tinggi = semakin kuat sinyal.
        """
        priority_weight = 1.0 / max(self.priority, 1)
        urgency_bonus   = 1.2 if self.urgency == "immediate" else 1.0
        return self.confidence * priority_weight * urgency_bonus

    def __repr__(self):
        return (f"Signal({self.type} | {self.side} | {self.market_id} | "
                f"conf={self.confidence:.2f} | ${self.size_usd:.0f})")


class SignalAggregator:
    """
    Agregasi dan filter signals dari semua strategy.
    Fungsi utama:
    1. Deduplikasi signal yang bertentangan (conflict resolution)
    2. Prioritisasi berdasarkan strategy type + conviction
    3. Rate limiting per market
    4. Ensemble voting untuk signal yang sama
    """

    def __init__(self,
                 max_signals_per_cycle: int = 5,
                 min_conviction:        float = 0.3,
                 conflict_window_sec:   float = 30.0):
        self.max_signals_per_cycle = max_signals_per_cycle
        self.min_conviction        = min_conviction
        self.conflict_window_sec   = conflict_window_sec

        self._recent_signals: Dict[str, List[Signal]] = defaultdict(list)
        self._execution_log:  List[dict]              = []

    # ─────────────────────────────────────────────────────────────────
    def process(self, raw_signals: List[dict]) -> List[dict]:
        """
        Main entry point.
        Input : list raw signal dicts dari semua strategies
        Output: list signal dict yang sudah difilter, diprioritasi, siap eksekusi
        """
        if not raw_signals:
            return []

        # 1. Wrap ke Signal objects
        signals = [Signal(r) for r in raw_signals]

        # 2. Filter conviction minimum
        signals = [s for s in signals if s.conviction_score() >= self.min_conviction]

        # 3. Resolve conflicts per market
        signals = self._resolve_conflicts(signals)

        # 4. Ensemble voting — boost confidence jika banyak strategy setuju
        signals = self._ensemble_boost(signals)

        # 5. Sort by priority + conviction
        signals.sort(key=lambda s: (s.priority, -s.conviction_score()))

        # 6. Limit jumlah signal per cycle
        signals = signals[:self.max_signals_per_cycle]

        # 7. Update recent signals cache
        for sig in signals:
            self._recent_signals[sig.market_id].append(sig)
            # Keep last 20 per market
            self._recent_signals[sig.market_id] = \
                self._recent_signals[sig.market_id][-20:]

        result = [s.to_dict() for s in signals]

        if result:
            logger.info(f"📊 SignalAggregator: {len(raw_signals)} raw → {len(result)} valid")
            for s in signals:
                logger.debug(f"  → {s}")

        return result

    # ─────────────────────────────────────────────────────────────────
    def _resolve_conflicts(self, signals: List[Signal]) -> List[Signal]:
        """
        Jika ada signal YES dan NO untuk market yang sama dalam window singkat,
        ambil yang conviction-nya lebih tinggi. Buang yang lain.
        """
        market_signals: Dict[str, List[Signal]] = defaultdict(list)
        for sig in signals:
            market_signals[sig.market_id].append(sig)

        resolved = []
        for market_id, sigs in market_signals.items():
            if len(sigs) == 1:
                resolved.append(sigs[0])
                continue

            yes_sigs  = [s for s in sigs if s.side == "YES"]
            no_sigs   = [s for s in sigs if s.side == "NO"]

            if yes_sigs and no_sigs:
                # Conflict — pilih sisi dengan total conviction lebih tinggi
                yes_conv = sum(s.conviction_score() for s in yes_sigs)
                no_conv  = sum(s.conviction_score() for s in no_sigs)

                winner = yes_sigs if yes_conv >= no_conv else no_sigs
                # Ambil signal terkuat dari sisi pemenang
                best = max(winner, key=lambda s: s.conviction_score())
                resolved.append(best)
                logger.debug(
                    f"Conflict resolved {market_id}: "
                    f"YES={yes_conv:.2f} vs NO={no_conv:.2f} → {best.side}"
                )
            else:
                # Tidak ada conflict, ambil yang terkuat
                best = max(sigs, key=lambda s: s.conviction_score())
                resolved.append(best)

        return resolved

    def _ensemble_boost(self, signals: List[Signal]) -> List[Signal]:
        """
        Jika lebih dari satu strategy sepakat arah yang sama untuk satu market,
        boost confidence-nya (max cap 0.97).
        """
        market_agreement: Dict[Tuple[str, str], int] = defaultdict(int)
        for sig in signals:
            market_agreement[(sig.market_id, sig.side)] += 1

        for sig in signals:
            agreement = market_agreement[(sig.market_id, sig.side)]
            if agreement >= 2:
                boost = 0.05 * (agreement - 1)
                sig.confidence = min(0.97, sig.confidence + boost)
                sig._raw["confidence"] = sig.confidence
                logger.debug(
                    f"Ensemble boost {sig.market_id} {sig.side}: "
                    f"+{boost:.2f} (agreement={agreement})"
                )

        return signals

    # ─────────────────────────────────────────────────────────────────
    def get_recent_signals(self, market_id: str, limit: int = 10) -> List[dict]:
        sigs = self._recent_signals.get(market_id, [])
        return [s.to_dict() for s in sigs[-limit:]]

    def clear_stale(self, max_age_sec: float = 300.0):
        """Hapus signal lama dari cache"""
        now = time.time()
        for market_id in list(self._recent_signals.keys()):
            self._recent_signals[market_id] = [
                s for s in self._recent_signals[market_id]
                if (now - s.timestamp) < max_age_sec
            ]

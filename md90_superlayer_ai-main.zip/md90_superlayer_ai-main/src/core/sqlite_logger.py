"""
MD90 Meridian - SQLite Trade Logger
Full trade history dengan query support untuk analisis performa
"""

import sqlite3
import json
import time
import logging
import os
from datetime import datetime, timezone
from typing import List, Dict, Optional, Tuple

logger = logging.getLogger(__name__)

DB_PATH = os.getenv("SQLITE_DB", "logs/meridian_trades.db")


class SQLiteLogger:
    """
    Persistent trade logger menggunakan SQLite.
    Lebih powerful dari JSONL untuk analytics.

    Tables:
    - trades      : semua trade dengan hasil
    - signals     : semua signal (executed dan rejected)
    - performance : daily performance summary
    - system_log  : events sistem (connect, error, shutdown)
    """

    def __init__(self, db_path: str = DB_PATH):
        self.db_path = db_path
        os.makedirs(os.path.dirname(db_path) if os.path.dirname(db_path) else "logs", exist_ok=True)
        self._init_db()

    # ------------------------------------------------------------------
    def _init_db(self):
        """Buat tables jika belum ada"""
        with self._conn() as conn:
            conn.executescript("""
                CREATE TABLE IF NOT EXISTS trades (
                    id              INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp       REAL    NOT NULL,
                    datetime_str    TEXT    NOT NULL,
                    market_id       TEXT    NOT NULL,
                    strategy        TEXT    NOT NULL,
                    side            TEXT    NOT NULL,   -- YES / NO / long / short
                    entry_price     REAL,
                    exit_price      REAL,
                    size_usd        REAL    NOT NULL,
                    pnl             REAL    DEFAULT 0,
                    status          TEXT    NOT NULL,   -- OPEN / WIN / LOSS / CANCELLED
                    edge_pct        REAL    DEFAULT 0,
                    confidence      REAL    DEFAULT 0,
                    hold_seconds    REAL    DEFAULT 0,
                    notes           TEXT,
                    raw_signal      TEXT    -- JSON
                );

                CREATE TABLE IF NOT EXISTS signals (
                    id              INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp       REAL    NOT NULL,
                    market_id       TEXT    NOT NULL,
                    strategy        TEXT    NOT NULL,
                    side            TEXT    NOT NULL,
                    confidence      REAL,
                    edge_pct        REAL,
                    executed        INTEGER DEFAULT 0,  -- 0/1
                    reject_reason   TEXT,
                    raw             TEXT    -- JSON
                );

                CREATE TABLE IF NOT EXISTS performance (
                    date            TEXT    PRIMARY KEY,
                    total_trades    INTEGER DEFAULT 0,
                    wins            INTEGER DEFAULT 0,
                    losses          INTEGER DEFAULT 0,
                    win_rate        REAL    DEFAULT 0,
                    total_pnl       REAL    DEFAULT 0,
                    max_drawdown    REAL    DEFAULT 0,
                    avg_edge_pct    REAL    DEFAULT 0,
                    start_equity    REAL    DEFAULT 0,
                    end_equity      REAL    DEFAULT 0
                );

                CREATE TABLE IF NOT EXISTS system_log (
                    id              INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp       REAL    NOT NULL,
                    event           TEXT    NOT NULL,
                    details         TEXT
                );

                CREATE INDEX IF NOT EXISTS idx_trades_market   ON trades(market_id);
                CREATE INDEX IF NOT EXISTS idx_trades_strategy ON trades(strategy);
                CREATE INDEX IF NOT EXISTS idx_trades_status   ON trades(status);
                CREATE INDEX IF NOT EXISTS idx_trades_ts       ON trades(timestamp);
            """)
        logger.info(f"✅ SQLite DB initialized: {self.db_path}")

    def _conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    # ------------------------------------------------------------------
    def log_trade_open(self, trade: dict) -> int:
        """Log trade yang baru dibuka. Return trade_id."""
        now = time.time()
        with self._conn() as conn:
            cursor = conn.execute("""
                INSERT INTO trades
                (timestamp, datetime_str, market_id, strategy, side,
                 entry_price, size_usd, status, edge_pct, confidence, raw_signal)
                VALUES (?, ?, ?, ?, ?, ?, ?, 'OPEN', ?, ?, ?)
            """, (
                now,
                datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S"),
                trade.get("market_id",  ""),
                trade.get("strategy",   "UNKNOWN"),
                trade.get("side",       ""),
                trade.get("entry_price", trade.get("price", 0)),
                trade.get("size_usd",    trade.get("size_suggestion", 0)),
                trade.get("edge_pct",   0),
                trade.get("confidence", 0),
                json.dumps(trade),
            ))
            return cursor.lastrowid

    def log_trade_close(self, trade_id: int, exit_price: float,
                        pnl: float, hold_seconds: float = 0,
                        status: str = "WIN"):
        """Update trade yang sudah ditutup"""
        with self._conn() as conn:
            conn.execute("""
                UPDATE trades
                SET exit_price   = ?,
                    pnl          = ?,
                    hold_seconds = ?,
                    status       = ?
                WHERE id = ?
            """, (exit_price, pnl, hold_seconds, status, trade_id))

    def log_signal(self, signal: dict, executed: bool, reject_reason: str = ""):
        """Log semua signal (executed dan rejected)"""
        with self._conn() as conn:
            conn.execute("""
                INSERT INTO signals
                (timestamp, market_id, strategy, side, confidence,
                 edge_pct, executed, reject_reason, raw)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                time.time(),
                signal.get("market_id",  ""),
                signal.get("type",       signal.get("strategy", "UNKNOWN")),
                signal.get("side",       ""),
                signal.get("confidence", 0),
                signal.get("edge_pct",   0),
                1 if executed else 0,
                reject_reason,
                json.dumps(signal),
            ))

    def log_system(self, event: str, details: str = ""):
        """Log event sistem"""
        with self._conn() as conn:
            conn.execute("""
                INSERT INTO system_log (timestamp, event, details)
                VALUES (?, ?, ?)
            """, (time.time(), event, details))

    # ------------------------------------------------------------------
    def update_daily_performance(self, date: str = None):
        """Hitung dan simpan daily performance summary"""
        date = date or datetime.now().strftime("%Y-%m-%d")
        with self._conn() as conn:
            stats = conn.execute("""
                SELECT
                    COUNT(*)                                          AS total,
                    SUM(CASE WHEN status='WIN'  THEN 1 ELSE 0 END)   AS wins,
                    SUM(CASE WHEN status='LOSS' THEN 1 ELSE 0 END)   AS losses,
                    SUM(pnl)                                          AS total_pnl,
                    AVG(edge_pct)                                     AS avg_edge
                FROM trades
                WHERE datetime_str LIKE ? AND status != 'OPEN'
            """, (f"{date}%",)).fetchone()

            total  = stats["total"]  or 0
            wins   = stats["wins"]   or 0
            losses = stats["losses"] or 0
            pnl    = stats["total_pnl"] or 0
            edge   = stats["avg_edge"]  or 0
            rate   = wins / total if total > 0 else 0

            conn.execute("""
                INSERT OR REPLACE INTO performance
                (date, total_trades, wins, losses, win_rate, total_pnl, avg_edge_pct)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (date, total, wins, losses, rate, pnl, edge))

        return {"date": date, "total": total, "wins": wins,
                "losses": losses, "win_rate": rate, "pnl": pnl}

    # ------------------------------------------------------------------
    def get_stats(self, days: int = 7) -> dict:
        """Summary statistik N hari terakhir"""
        with self._conn() as conn:
            row = conn.execute("""
                SELECT
                    COUNT(*)                                           AS total_trades,
                    SUM(CASE WHEN status='WIN'  THEN 1 ELSE 0 END)    AS wins,
                    SUM(CASE WHEN status='LOSS' THEN 1 ELSE 0 END)    AS losses,
                    ROUND(SUM(pnl), 4)                                 AS total_pnl,
                    ROUND(AVG(edge_pct), 2)                            AS avg_edge,
                    ROUND(AVG(confidence), 2)                          AS avg_confidence,
                    ROUND(AVG(hold_seconds), 1)                        AS avg_hold_s
                FROM trades
                WHERE timestamp > ? AND status != 'OPEN'
            """, (time.time() - days * 86400,)).fetchone()

            total  = row["total_trades"] or 0
            wins   = row["wins"]  or 0
            losses = row["losses"] or 0

            return {
                "total_trades":   total,
                "wins":           wins,
                "losses":         losses,
                "win_rate":       round(wins / total, 4) if total > 0 else 0,
                "total_pnl":      row["total_pnl"] or 0,
                "avg_edge_pct":   row["avg_edge"]  or 0,
                "avg_confidence": row["avg_confidence"] or 0,
                "avg_hold_s":     row["avg_hold_s"] or 0,
            }

    def get_recent_trades(self, limit: int = 10) -> List[dict]:
        """Ambil N trade terbaru"""
        with self._conn() as conn:
            rows = conn.execute("""
                SELECT datetime_str, market_id, strategy, side,
                       size_usd, pnl, status, edge_pct, confidence
                FROM trades
                ORDER BY timestamp DESC
                LIMIT ?
            """, (limit,)).fetchall()
            return [dict(r) for r in rows]

    def get_open_positions(self) -> List[dict]:
        """Ambil semua posisi yang masih terbuka"""
        with self._conn() as conn:
            rows = conn.execute("""
                SELECT id, datetime_str, market_id, strategy, side,
                       entry_price, size_usd, edge_pct
                FROM trades
                WHERE status = 'OPEN'
                ORDER BY timestamp DESC
            """).fetchall()
            return [dict(r) for r in rows]

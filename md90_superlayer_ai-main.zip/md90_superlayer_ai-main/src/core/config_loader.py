"""
MD90 Meridian - Config Loader
Load dan validasi konfigurasi dari settings.yaml + .env
"""

import os
import yaml
import logging
from typing import List, Optional, Dict, Any
from dotenv import load_dotenv

load_dotenv()
logger = logging.getLogger(__name__)

# ── Try pydantic v2, fallback ke v1 ──────────────────────────────────
try:
    from pydantic import BaseModel, Field, field_validator
    PYDANTIC_V2 = True
except ImportError:
    try:
        from pydantic import BaseModel, Field, validator as field_validator
        PYDANTIC_V2 = False
    except ImportError:
        BaseModel = object
        PYDANTIC_V2 = False


class CapitalConfig:
    def __init__(self, d: dict):
        self.total_usd              = float(d.get("total_usd",              5000.0))
        self.max_position_per_trade = float(d.get("max_position_per_trade", 0.005))
        self.daily_loss_limit       = float(d.get("daily_loss_limit",       0.02))
        self.kelly_fraction         = float(d.get("kelly_fraction",         0.1))


class HFTConfig:
    def __init__(self, d: dict):
        self.enabled          = bool(d.get("enabled",          True))
        self.weight           = float(d.get("weight",          0.30))
        self.min_edge_bps     = int(d.get("min_edge_bps",      30))
        self.max_execution_ms = int(d.get("max_execution_ms",  500))
        self.markets          = list(d.get("markets",          ["BTC-15MIN"]))
        self.external_oracles = list(d.get("external_oracles", ["binance"]))


class MarketMakingConfig:
    def __init__(self, d: dict):
        self.enabled              = bool(d.get("enabled",              True))
        self.weight               = float(d.get("weight",              0.40))
        self.target_spread_bps    = int(d.get("target_spread_bps",    50))
        self.inventory_skew_limit = float(d.get("inventory_skew_limit", 0.20))
        self.rebalance_threshold  = float(d.get("rebalance_threshold", 0.05))


class ReverseConfig:
    def __init__(self, d: dict):
        self.enabled           = bool(d.get("enabled",            True))
        self.weight            = float(d.get("weight",            0.20))
        self.trigger_threshold = float(d.get("trigger_threshold", 0.80))
        self.contrarian_check  = bool(d.get("contrarian_check",   True))
        self.max_hold_days     = int(d.get("max_hold_days",        7))


class CorrelationConfig:
    def __init__(self, d: dict):
        self.enabled              = bool(d.get("enabled",              True))
        self.weight               = float(d.get("weight",              0.10))
        self.min_gap_bps          = int(d.get("min_gap_bps",           100))
        self.execution_immediate  = bool(d.get("execution_immediate",  True))


class ExecutionConfig:
    def __init__(self, d: dict):
        self.network              = str(d.get("network",             "polygon"))
        self.rpc_url              = str(d.get("rpc_url",             os.getenv("POLYGON_RPC_URL", "https://polygon-rpc.com")))
        self.flashbots_enabled    = bool(d.get("flashbots_enabled",  False))
        self.gas_limit            = int(d.get("gas_limit",           500000))
        self.max_priority_gwei    = int(d.get("max_priority_gwei",   30))
        self.max_fee_gwei         = int(d.get("max_fee_gwei",        100))
        self.confirmation_blocks  = int(d.get("confirmation_blocks", 1))
        self.pre_signed_tx_cache  = int(d.get("pre_signed_tx_cache", 10))


class RiskConfig:
    def __init__(self, d: dict):
        self.max_position_usd             = float(d.get("max_position_usd",             1000))
        self.max_portfolio_usd            = float(d.get("max_portfolio_usd",            10000))
        self.max_inventory_skew           = float(d.get("max_inventory_skew",           0.30))
        self.kelly_fraction               = float(d.get("kelly_fraction",               0.25))
        self.circuit_breaker_drawdown     = float(d.get("circuit_breaker_drawdown",     0.05))
        self.adverse_selection_threshold  = float(d.get("adverse_selection_threshold",  0.001))
        self.volatility_pause_threshold   = float(d.get("volatility_pause_threshold",   0.80))
        self.max_trades_per_minute        = int(d.get("max_trades_per_minute",          20))
        self.cooldown_after_loss_seconds  = int(d.get("cooldown_after_loss_seconds",    300))
        self.total_usd                    = float(d.get("total_usd",                    5000))


class MonitoringConfig:
    def __init__(self, d: dict):
        self.telegram_enabled              = bool(d.get("telegram_enabled",               True))
        self.log_level                     = str(d.get("log_level",                       "INFO"))
        self.performance_report_interval   = int(d.get("performance_report_interval",     3600))
        self.dashboard_port                = int(d.get("dashboard_port",                  5000))


class BotConfig:
    def __init__(self, d: dict):
        self.name        = str(d.get("name",        "MD90-Meridian-Omega"))
        self.version     = str(d.get("version",     "3.0.0"))
        self.environment = str(d.get("environment", "paper"))


class MeridianConfig:
    """Master config object — akses semua sub-config dari satu tempat"""

    def __init__(self, raw: dict):
        self.bot        = BotConfig(raw.get("bot", {}))
        self.capital    = CapitalConfig(raw.get("capital", {}))
        self.execution  = ExecutionConfig(raw.get("execution", {}))
        self.risk       = RiskConfig(raw.get("risk", {}))
        self.monitoring = MonitoringConfig(raw.get("monitoring", {}))

        strats = raw.get("strategies", {})
        self.hft          = HFTConfig(strats.get("hft_latency", {}))
        self.market_making = MarketMakingConfig(strats.get("market_making", {}))
        self.reverse      = ReverseConfig(strats.get("reverse_strategy", {}))
        self.correlation  = CorrelationConfig(strats.get("correlation_arb", {}))

        # Secrets dari environment (tidak pernah dari YAML)
        self.polymarket_api_key    = os.getenv("POLYMARKET_API_KEY",    "")
        self.polymarket_secret     = os.getenv("POLYMARKET_SECRET",     "")
        self.polymarket_passphrase = os.getenv("POLYMARKET_PASSPHRASE", "")
        self.private_key           = os.getenv("PRIVATE_KEY",           "")
        self.binance_api_key       = os.getenv("BINANCE_API_KEY",       "")
        self.binance_secret        = os.getenv("BINANCE_SECRET_KEY",    "")
        self.telegram_token        = os.getenv("BOT_TOKEN",             "")
        self.telegram_chat_id      = os.getenv("TELEGRAM_CHAT_ID",      "")
        self.owner_id              = int(os.getenv("OWNER_ID",          "0") or "0")
        self.dry_run               = os.getenv("DRY_RUN", "true").lower() != "false"

        self._raw = raw

    def to_dict(self) -> dict:
        return self._raw

    def validate(self) -> list:
        """Return list of missing critical configs"""
        missing = []
        if not self.polymarket_api_key:
            missing.append("POLYMARKET_API_KEY")
        if not self.private_key:
            missing.append("PRIVATE_KEY (Polygon wallet)")
        if not self.binance_api_key:
            missing.append("BINANCE_API_KEY")
        if not self.telegram_token:
            missing.append("BOT_TOKEN (Telegram)")
        return missing


# ── Public loader function ────────────────────────────────────────────
def load_config(config_path: str = "config/settings.yaml") -> MeridianConfig:
    """Load config dari YAML + env vars. Return MeridianConfig object."""
    raw: dict = {}

    if os.path.exists(config_path):
        try:
            with open(config_path, "r") as f:
                raw = yaml.safe_load(f) or {}
            logger.info(f"✅ Config loaded from {config_path}")
        except Exception as e:
            logger.error(f"❌ Config load error: {e}")
    else:
        logger.warning(f"Config file not found: {config_path} — using defaults")

    cfg = MeridianConfig(raw)

    # Log missing keys
    missing = cfg.validate()
    if missing:
        logger.warning(f"⚠️  Missing env vars (set in .env): {missing}")
    else:
        logger.info("✅ All critical env vars present")

    return cfg


def get_secret(key: str, default: str = "") -> str:
    """Helper — ambil secret dari environment"""
    return os.getenv(key, default)

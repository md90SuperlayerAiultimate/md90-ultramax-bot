"""
MD90 Meridian - HFT Latency Strategy
ClawdBot-style latency arbitrage antara Polymarket dan external oracles
"""

import asyncio
import time
import logging
from dataclasses import dataclass, field
from typing import Optional, Dict

logger = logging.getLogger(__name__)


@dataclass
class HFTSignal:
    market_id:  str
    direction:  str        # 'YES' | 'NO'
    edge_bps:   float      # Basis points edge
    confidence: float      # 0.0 - 1.0
    urgency:    str        # 'immediate' | 'normal'
    size_usd:   float      # Diisi oleh Risk Manager
    strategy:   str = "hft_latency"
    reasoning:  str = ""


class OracleFeed:
    """
    Feed harga dari external oracle (Binance/Coinbase).
    Digunakan untuk deteksi latency arb vs Polymarket.
    """

    def __init__(self, binance_client=None):
        self.binance = binance_client
        self._price_cache: Dict[str, dict] = {}

    def update_price(self, symbol: str, price: float):
        self._price_cache[symbol] = {
            "price":     price,
            "timestamp": time.time()
        }

    def get_price(self, symbol: str) -> Optional[float]:
        data = self._price_cache.get(symbol)
        if data and (time.time() - data["timestamp"]) < 5.0:
            return data["price"]
        return None

    def get_latency_arbitrage_opportunity(self,
                                          pm_price: float,
                                          oracle_symbol: str = "BTCUSDT",
                                          pm_market_type: str = "BTC") -> Optional[dict]:
        """
        Deteksi jika ada gap antara Polymarket price dan oracle price.
        Return: {direction, edge} atau None
        """
        oracle_price = self.get_price(oracle_symbol)
        if oracle_price is None:
            return None

        # Normalisasi: Polymarket price adalah probabilitas 0-1
        # Oracle harus dinormalisasi ke konteks yang sama
        # Untuk market binary event (mis. BTC > $X): edge dari oracle lag
        edge = abs(pm_price - self._normalize_oracle(oracle_price, pm_market_type))
        if edge < 0.003:  # < 0.3% threshold minimum
            return None

        direction = "YES" if oracle_price > pm_price else "NO"
        return {"direction": direction, "edge": edge}

    def _normalize_oracle(self, oracle_price: float, market_type: str) -> float:
        """
        Placeholder normalisasi — implementasi disesuaikan dengan market Polymarket.
        Contoh: BTC > $100k → prob berdasarkan oracle price vs threshold.
        """
        return 0.5  # Override per market


class HFTLatencyStrategy:
    """
    ClawdBot-style latency arbitrage.
    Scan setiap tick untuk edge antara Polymarket dan oracle.
    """

    def __init__(self, config: dict, oracle_feed: OracleFeed, orderbook_feed):
        self.config           = config
        self.min_edge_bps     = config.get("min_edge_bps", 30)
        self.oracle           = oracle_feed
        self.orderbook        = orderbook_feed
        self.active           = True
        self.last_trade_time  = 0.0
        self.cooldown_seconds = 3  # Nonce management

        self.trades_today     = 0
        self.wins             = 0
        self.losses           = 0

    # ------------------------------------------------------------------
    async def scan(self, market_id: str) -> Optional[HFTSignal]:
        """Scan untuk HFT opportunity setiap tick"""
        if not self.active:
            return None

        # Rate limit
        if time.time() - self.last_trade_time < self.cooldown_seconds:
            return None

        # Get Polymarket mid price
        pm_price = self.orderbook.get_mid_price(market_id)
        if pm_price is None:
            return None

        # Check arb opportunity vs oracle
        opp = self.oracle.get_latency_arbitrage_opportunity(pm_price)
        if not opp:
            return None

        edge_bps = opp["edge"] * 10000  # Convert ke basis points

        if edge_bps >= self.min_edge_bps:
            confidence = self._calculate_confidence(edge_bps)
            return HFTSignal(
                market_id  = market_id,
                direction  = opp["direction"],
                edge_bps   = edge_bps,
                confidence = confidence,
                urgency    = "immediate" if edge_bps > 50 else "normal",
                size_usd   = 0,  # Diisi Risk Manager
                reasoning  = f"Oracle lag: {edge_bps:.1f}bps edge"
            )

        return None

    def _calculate_confidence(self, edge_bps: float) -> float:
        """
        Edge besar (>1%) bisa berarti news atau illiquidity.
        Turunkan confidence untuk menghindari adverse selection.
        """
        if edge_bps < 50:
            return 0.90
        elif edge_bps < 100:
            return 0.70
        else:
            return 0.50  # High edge = high risk

    def record_result(self, win: bool):
        if win:
            self.wins += 1
        else:
            self.losses += 1
        self.trades_today += 1
        self.last_trade_time = time.time()

    # ------------------------------------------------------------------
    def pause(self, duration_seconds: int = 300):
        """Pause setelah adverse selection terdeteksi"""
        self.active = False
        asyncio.create_task(self._resume_after(duration_seconds))
        logger.warning(f"HFT Strategy paused for {duration_seconds}s")

    async def _resume_after(self, seconds: int):
        await asyncio.sleep(seconds)
        self.active = True
        logger.info("HFT Strategy resumed")

    @property
    def win_rate(self) -> float:
        total = self.wins + self.losses
        return self.wins / total if total > 0 else 0.0

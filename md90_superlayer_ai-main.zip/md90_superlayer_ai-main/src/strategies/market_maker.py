"""
MD90 Meridian - Market Maker Strategy
AMM-style market making di Polymarket — passive income dari spread
"""

import time
import logging
import asyncio
from typing import Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


class SpreadCalculator:
    """
    Hitung spread optimal berdasarkan volatilitas dan inventory skew.
    Spread lebih lebar saat volatil, lebih sempit saat stabil.
    """

    def __init__(self,
                 base_spread_bps:    int   = 50,
                 min_spread_bps:     int   = 20,
                 max_spread_bps:     int   = 200,
                 volatility_scalar:  float = 2.0):
        self.base_spread_bps   = base_spread_bps
        self.min_spread_bps    = min_spread_bps
        self.max_spread_bps    = max_spread_bps
        self.volatility_scalar = volatility_scalar

    def calculate(self,
                  volatility:     float = 0.1,
                  inventory_skew: float = 0.0) -> Tuple[float, float]:
        """
        Return (bid_price, ask_price) untuk market making.
        Mid price diasumsikan 0.5 jika tidak diketahui.
        """
        # Spread melebar saat volatil
        spread_bps = self.base_spread_bps * (1 + volatility * self.volatility_scalar)

        # Skew spread berdasarkan inventory (kurangi eksposur sisi yang sudah besar)
        skew_adj = inventory_skew * 0.1  # ±10% max adjustment

        spread_bps = max(self.min_spread_bps,
                         min(self.max_spread_bps, spread_bps))
        half_spread = (spread_bps / 10000) / 2

        bid = max(0.01, 0.5 - half_spread - skew_adj)
        ask = min(0.99, 0.5 + half_spread - skew_adj)

        return round(bid, 4), round(ask, 4)

    def calculate_from_mid(self,
                           mid_price:      float,
                           volatility:     float = 0.1,
                           inventory_skew: float = 0.0) -> Tuple[float, float]:
        spread_bps = self.base_spread_bps * (1 + volatility * self.volatility_scalar)
        skew_adj   = inventory_skew * 0.05
        spread_bps = max(self.min_spread_bps, min(self.max_spread_bps, spread_bps))
        half_spread = (spread_bps / 10000) / 2

        bid = max(0.01, mid_price - half_spread - skew_adj)
        ask = min(0.99, mid_price + half_spread - skew_adj)
        return round(bid, 4), round(ask, 4)


class InventoryManager:
    """Kelola inventory YES/NO per market untuk menghindari skew berlebihan"""

    def __init__(self, max_skew: float = 0.20):
        self.max_skew  = max_skew
        self._yes_usd: Dict[str, float] = {}
        self._no_usd:  Dict[str, float] = {}

    def add_fill(self, market_id: str, side: str, size_usd: float):
        if side == "YES":
            self._yes_usd[market_id] = self._yes_usd.get(market_id, 0) + size_usd
        else:
            self._no_usd[market_id]  = self._no_usd.get(market_id, 0) + size_usd

    def get_skew(self, market_id: str) -> float:
        """Return skew -1.0 (all NO) to +1.0 (all YES)"""
        yes = self._yes_usd.get(market_id, 0)
        no  = self._no_usd.get(market_id, 0)
        total = yes + no
        return (yes - no) / total if total > 0 else 0.0

    def is_skew_ok(self, market_id: str, side: str) -> bool:
        skew = self.get_skew(market_id)
        if side == "YES" and skew >  self.max_skew: return False
        if side == "NO"  and skew < -self.max_skew: return False
        return True

    def get_total_yes(self) -> float:
        return sum(self._yes_usd.values())

    def get_total_no(self) -> float:
        return sum(self._no_usd.values())


class MarketMakerStrategy:
    """
    Market making pasif di Polymarket.
    Strategi: Quote bid/ask di sekitar mid price, profit dari spread.
    Rebalance inventory jika skew melebihi threshold.
    """

    def __init__(self, config: dict):
        self.config  = config
        self.enabled = config.get("enabled", True)
        self.weight  = config.get("weight",  0.40)

        self.spread_calc = SpreadCalculator(
            base_spread_bps   = config.get("target_spread_bps",    50),
            min_spread_bps    = config.get("min_spread_bps",        20),
            max_spread_bps    = config.get("max_spread_bps",       200),
        )
        self.inventory = InventoryManager(
            max_skew = config.get("inventory_skew_limit", 0.20)
        )

        self.rebalance_threshold = config.get("rebalance_threshold", 0.05)
        self.max_quote_size_usd  = config.get("max_quote_size_usd", 200)
        self.min_quote_size_usd  = config.get("min_quote_size_usd",  10)

        self._active_quotes: Dict[str, dict] = {}
        self._last_quote_time: Dict[str, float] = {}
        self.quote_interval_sec = config.get("quote_interval_sec", 5)

    # ─────────────────────────────────────────────────────────────────
    async def generate_quotes(self,
                              market_id:  str,
                              mid_price:  float,
                              volatility: float = 0.1,
                              orderbook:  Optional[dict] = None) -> List[dict]:
        """
        Generate bid/ask quotes untuk satu market.
        Return list of signal dicts siap dieksekusi.
        """
        if not self.enabled:
            return []

        # Rate limit per market
        last = self._last_quote_time.get(market_id, 0)
        if time.time() - last < self.quote_interval_sec:
            return []
        self._last_quote_time[market_id] = time.time()

        inventory_skew = self.inventory.get_skew(market_id)
        bid, ask = self.spread_calc.calculate_from_mid(mid_price, volatility, inventory_skew)

        spread_pct = (ask - bid) / mid_price if mid_price > 0 else 0
        if spread_pct < 0.002:  # < 0.2% spread tidak worth it
            return []

        quotes = []

        # BID (buy YES jika harga turun ke bid)
        if self.inventory.is_skew_ok(market_id, "YES"):
            bid_size = self._calculate_quote_size(mid_price, volatility, "BID")
            if bid_size >= self.min_quote_size_usd:
                quotes.append({
                    "type":            "MARKET_MAKE",
                    "subtype":         "BID",
                    "market_id":       market_id,
                    "side":            "YES",
                    "price":           bid,
                    "size_suggestion": bid_size,
                    "confidence":      0.65,
                    "urgency":         "normal",
                    "reasoning":       f"MM bid {bid:.4f} | spread={spread_pct*100:.2f}% | skew={inventory_skew:.2f}",
                })

        # ASK (buy NO = sell YES pada ask)
        if self.inventory.is_skew_ok(market_id, "NO"):
            ask_size = self._calculate_quote_size(mid_price, volatility, "ASK")
            if ask_size >= self.min_quote_size_usd:
                quotes.append({
                    "type":            "MARKET_MAKE",
                    "subtype":         "ASK",
                    "market_id":       market_id,
                    "side":            "NO",
                    "price":           ask,
                    "size_suggestion": ask_size,
                    "confidence":      0.65,
                    "urgency":         "normal",
                    "reasoning":       f"MM ask {ask:.4f} | spread={spread_pct*100:.2f}% | skew={inventory_skew:.2f}",
                })

        self._active_quotes[market_id] = {
            "bid": bid, "ask": ask,
            "timestamp": time.time()
        }

        return quotes

    def _calculate_quote_size(self,
                              mid_price:  float,
                              volatility: float,
                              side:       str) -> float:
        """
        Kurangi ukuran quote saat volatilitas tinggi.
        Sisi yang sudah skew besar mendapat ukuran lebih kecil.
        """
        base_size  = self.max_quote_size_usd
        vol_factor = max(0.3, 1.0 - volatility * 2)
        size       = base_size * vol_factor
        return round(max(self.min_quote_size_usd, min(self.max_quote_size_usd, size)), 2)

    # ─────────────────────────────────────────────────────────────────
    def record_fill(self, market_id: str, side: str, size_usd: float, price: float):
        """Catat fill untuk inventory tracking"""
        self.inventory.add_fill(market_id, side, size_usd)
        logger.info(f"MM Fill: {market_id} {side} ${size_usd:.2f} @ {price:.4f} | "
                    f"skew={self.inventory.get_skew(market_id):.2f}")

    def get_active_quote(self, market_id: str) -> Optional[dict]:
        return self._active_quotes.get(market_id)

    def needs_rebalance(self, market_id: str) -> bool:
        skew = abs(self.inventory.get_skew(market_id))
        return skew > self.rebalance_threshold

    def get_inventory_summary(self) -> dict:
        return {
            "total_yes_usd": self.inventory.get_total_yes(),
            "total_no_usd":  self.inventory.get_total_no(),
            "active_markets": list(self._active_quotes.keys()),
        }

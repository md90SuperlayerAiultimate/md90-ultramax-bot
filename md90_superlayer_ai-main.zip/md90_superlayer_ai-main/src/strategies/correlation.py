"""
MD90 Meridian - Correlation Arbitrage Strategy
Deteksi pelanggaran probabilitas logis antar market Polymarket
"""

import logging
from typing import Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


class MarketGraph:
    """
    Graph relasi antar market Polymarket.
    Edge = hubungan logis (A implies B, A + B = 1, dll.)
    """

    def __init__(self):
        # Format: {(market_id_a, market_id_b): relation_type}
        self.edges: Dict[Tuple[str, str], str] = {}

    def add_edge(self, market_a: str, market_b: str, relation: str = "implies"):
        self.edges[(market_a, market_b)] = relation

    def get_edges(self) -> List[Tuple[str, str]]:
        return list(self.edges.keys())

    def get_relation(self, market_a: str, market_b: str) -> Optional[str]:
        return self.edges.get((market_a, market_b))


class CorrelationArbitrageStrategy:
    """
    Deteksi dan eksploitasi pelanggaran probabilitas logis.
    Contoh:
    - P(A wins championship) > P(A wins semifinal) → violation
    - P(BTC > 100k) + P(BTC < 100k) ≠ 1.0 → gap
    - P(A AND B) > P(A) → impossible
    """

    def __init__(self, config: dict, min_gap: float = 0.05):
        self.config   = config
        self.min_gap  = min_gap  # Minimum gap untuk trigger (default 5%)
        self.graph    = MarketGraph()

        # Daftarkan relasi market yang diketahui
        self._register_known_relations()

    def _register_known_relations(self):
        """
        Daftarkan pasangan market dengan relasi logis.
        Override/extend sesuai market Polymarket aktif.
        """
        # Contoh: Bitcoin price tiers (mutually exclusive + exhaustive)
        self.graph.add_edge("BTC-ABOVE-100K-EOY", "BTC-ABOVE-80K-EOY",  "implies")
        self.graph.add_edge("ETH-ABOVE-10K-EOY",  "ETH-ABOVE-5K-EOY",   "implies")

    # ------------------------------------------------------------------
    def evaluate(self, all_markets: Dict[str, dict]) -> List[dict]:
        """
        Scan semua market untuk logical violations.
        Return list of signals.
        """
        signals    = []
        violations = self._find_probability_violations(all_markets)

        for v in violations:
            signals.append({
                "type":             "CORRELATION_ARB",
                "side":             "BUY_UNDERVALUED",
                "market_pair":      v["pair"],
                "undervalued_id":   v["undervalued_id"],
                "overvalued_id":    v["overvalued_id"],
                "confidence":       min(0.95, 0.7 + v["gap"] * 5),  # Higher gap = higher conf
                "expected_profit":  v["gap"],
                "execution_window": "immediate",
                "reasoning":        f"Logical violation: {v['gap']*100:.1f}% gap",
            })

        return signals

    def _find_probability_violations(self, markets: Dict[str, dict]) -> List[dict]:
        """Deteksi semua pelanggaran probabilitas"""
        violations = []

        # Check 1: Implied probability violations (A implies B, P(A) > P(B))
        for (mid_a, mid_b) in self.graph.get_edges():
            if mid_a not in markets or mid_b not in markets:
                continue

            prob_a = markets[mid_a].get("mid_price", 0.5)
            prob_b = markets[mid_b].get("mid_price", 0.5)
            relation = self.graph.get_relation(mid_a, mid_b)

            if relation == "implies":
                # P(A) cannot > P(B) if A implies B
                if prob_a > prob_b + self.min_gap:
                    violations.append({
                        "pair":           (mid_a, mid_b),
                        "undervalued_id": mid_b,
                        "overvalued_id":  mid_a,
                        "gap":            prob_a - prob_b,
                        "type":           "implies_violation",
                    })

        # Check 2: Complementary market violations (P(YES) + P(NO) ≠ 1)
        for market_id, state in markets.items():
            yes_price = state.get("yes_bid", 0)
            no_price  = state.get("no_bid", 0)
            total     = yes_price + no_price

            if total > 0 and abs(total - 1.0) > self.min_gap:
                gap = abs(total - 1.0)
                undervalued = "YES" if yes_price < (1 - no_price) else "NO"
                violations.append({
                    "pair":           (market_id, market_id + "_complement"),
                    "undervalued_id": f"{market_id}_{undervalued}",
                    "overvalued_id":  market_id,
                    "gap":            gap,
                    "type":           "complement_violation",
                })

        # Filter by minimum gap
        return [v for v in violations if v["gap"] >= self.min_gap]

    # ------------------------------------------------------------------
    def add_market_relation(self, market_a: str, market_b: str, relation: str = "implies"):
        """Tambahkan relasi market baru secara dinamis"""
        self.graph.add_edge(market_a, market_b, relation)
        logger.info(f"Added market relation: {market_a} {relation} {market_b}")

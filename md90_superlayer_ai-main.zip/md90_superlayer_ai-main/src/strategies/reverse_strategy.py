"""
MD90 Meridian - Reverse Strategy (Contrarian)
Bet melawan crowd ketika consensus > 80% tanpa fundamental support
"""

import logging
from typing import List, Dict, Optional

logger = logging.getLogger(__name__)


class ReverseStrategy:
    """
    Trigger: Konsensus ekstrem (>80%) + fundamental lemah = bet NO.
    Logic: Pasar sering overbought di level ekstrem pada prediction markets.
    """

    def __init__(self, config: dict):
        self.threshold    = config.get("trigger_threshold", 0.80)  # 80%
        self.max_hold_days = config.get("max_hold_days", 7)

    # ------------------------------------------------------------------
    def evaluate(self, market: dict) -> List[dict]:
        signals   = []
        yes_price = market.get("mid_price", market.get("yes_bid", 0.5))
        prob_yes  = yes_price  # Sudah dalam 0-1 format

        # Trigger: extreme consensus
        if prob_yes > self.threshold:
            contrarian_score = self._analyze_fundamentals(market)

            if contrarian_score < 0.3:  # Fundamental support lemah
                confidence = min(0.90, (prob_yes - self.threshold) / (1 - self.threshold))
                signals.append({
                    "type":           "REVERSE",
                    "side":           "NO",   # Bet against crowd
                    "market_id":      market.get("id", market.get("market_id", "")),
                    "confidence":     confidence,
                    "size_suggestion": self._calculate_size(prob_yes),
                    "hold_period":    f"up to {self.max_hold_days} days",
                    "reasoning":      f"Overbought at {prob_yes*100:.0f}% — fade the crowd",
                })

        elif prob_yes < (1 - self.threshold):  # Extreme NO consensus
            contrarian_score = self._analyze_fundamentals(market)
            if contrarian_score < 0.3:
                confidence = min(0.90, ((1 - self.threshold) - prob_yes) / self.threshold)
                signals.append({
                    "type":           "REVERSE",
                    "side":           "YES",  # Bet against NO crowd
                    "market_id":      market.get("id", market.get("market_id", "")),
                    "confidence":     confidence,
                    "size_suggestion": self._calculate_size(1 - prob_yes),
                    "hold_period":    f"up to {self.max_hold_days} days",
                    "reasoning":      f"Oversold at {prob_yes*100:.0f}% YES — fade the NO crowd",
                })

        return signals

    def _analyze_fundamentals(self, market: dict) -> float:
        """
        Skor fundamental support (0=lemah, 1=kuat).
        Score rendah = safe untuk contrarian.
        Placeholder — extend dengan news NLP, data feed nyata.
        """
        # Proxy sederhana: volume tinggi = lebih informed = lebih berisiko contrarian
        volume   = market.get("volume_24h", 0)
        liquidity = market.get("liquidity", 0)

        if volume > 100000:   return 0.7   # High volume = informed market
        if volume > 10000:    return 0.4
        if liquidity < 1000:  return 0.1   # Low liquidity = easier to fade
        return 0.25  # Default: moderate contrarian opportunity

    def _calculate_size(self, prob_extreme: float) -> float:
        """
        Semakin ekstrem probabilitas, semakin besar ukuran contrarian.
        Dibatasi oleh Risk Manager.
        """
        excess = max(0, prob_extreme - self.threshold)
        return min(500, excess * 2000)  # Max $500 per signal, dikontrol Risk Manager

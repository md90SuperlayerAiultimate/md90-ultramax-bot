#!/usr/bin/env python3
# ============================================
# MD90_SCALPING_SUPREME_FINAL.py
# Versi: v30+ (All-Layer • All-In • Hybrid AI) — ONE FILE
# By: MD90 — Load credentials dari .env (JANGAN hardcode!)
# ============================================

import os
import json
import time
import threading
import math
import random
import traceback
import signal
import sys
from datetime import datetime, timezone

import numpy as np
import pandas as pd
import requests
from dotenv import load_dotenv

load_dotenv()

# =========[ 0) CONFIG — DARI .ENV ]=========
# BUG FIX: Credentials TIDAK boleh hardcode. Semua dari environment.
BINANCE_API_KEY    = os.getenv("BINANCE_API_KEY",    "")
BINANCE_SECRET_KEY = os.getenv("BINANCE_SECRET_KEY", "")

MEXC_API_KEY   = os.getenv("MEXC_API_KEY",   "")
MEXC_SECRET    = os.getenv("MEXC_SECRET",    "")

BOT_TOKEN      = os.getenv("BOT_TOKEN",  "")
OWNER_ID       = int(os.getenv("OWNER_ID", "0"))

# --- PAIRS & MODE ---
PAIRS        = ["BTCUSDT", "ETHUSDT", "SOLUSDT", "XRPUSDT"]
SOLANA_TRACK = ["DUCKAI", "MEOWL", "BONK", "WIF"]
TIMEZONE     = "Asia/Makassar"

# --- LAYER & THRESHOLD ---
ALL_LAYER_REQUIRED   = True
CONF_THRESHOLD       = 0.85
USE_STREAM_DASHBOARD = True
USE_SCALPING         = True
USE_SNIPER           = True
USE_AUTO_RETRAIN     = True
USE_TRAILING_TP      = True

# --- RISK / EXEC ---
USE_BINANCE_FUTURES = True
LEVERAGE            = 10
ALL_IN_MODE         = True
SL_PCT              = 0.15
TP_PCT              = 0.25
DRY_RUN             = os.getenv("DRY_RUN", "true").lower() != "false"

# --- DATA SOURCES ---
DEXSCREENER_TRENDING = "https://api.dexscreener.com/latest/dex/search?q=solana"
DEXSCREENER_BY_CA    = "https://api.dexscreener.com/latest/dex/tokens/{ca}"

# --- RETRAIN ---
RETRAIN_INTERVAL_HOURS = 4

# --- FILES / DIRS ---
DIR_MODEL  = "model"
DIR_LOGS   = "logs"
DIR_DATA   = "data"
DIR_SIGNAL = "signals"

FILE_RF         = f"{DIR_MODEL}/rf_model.pkl"
FILE_SIGNAL_LOG = f"{DIR_LOGS}/signal_log.json"
FILE_RISK_LOG   = f"{DIR_LOGS}/risk_log.json"
FILE_FEED_LOG   = f"{DIR_LOGS}/feed_log.json"
FILE_LIVE_ENTRY = f"{DIR_SIGNAL}/live_entry.json"
FILE_SENTIMENT  = f"{DIR_DATA}/sentiment.json"
FILE_PRICE_SNAP = f"{DIR_DATA}/price_snapshot.json"
FILE_RETRAINSET = f"{DIR_DATA}/retrain_set.json"

# =========[ 1) IMPORTS ]=========
try:
    from binance.client import Client
    from binance.enums import (SIDE_BUY, SIDE_SELL, ORDER_TYPE_MARKET,
                                ORDER_TYPE_STOP_MARKET, ORDER_TYPE_TAKE_PROFIT_MARKET)
    from binance.exceptions import BinanceAPIException
    BINANCE_OK = True
except ImportError:
    BINANCE_OK = False

try:
    from telegram import Bot, Update
    from telegram.ext import Updater, CommandHandler, CallbackContext
    TELEGRAM_OK = True
except ImportError:
    TELEGRAM_OK = False

try:
    from flask import Flask, jsonify
    FLASK_OK = True
except ImportError:
    FLASK_OK = False

try:
    from sklearn.ensemble import RandomForestClassifier
    import joblib
    SKLEARN_OK = True
except ImportError:
    SKLEARN_OK = False

# =========[ 2) UTILS / BOOTSTRAP ]=========
def ensure_dirs():
    for d in [DIR_MODEL, DIR_LOGS, DIR_DATA, DIR_SIGNAL]:
        os.makedirs(d, exist_ok=True)

def now_str():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def append_jsonl(path, obj):
    try:
        if os.path.exists(path):
            with open(path, "r") as f:
                cur = json.load(f)
        else:
            cur = []
    except Exception:
        cur = []
    cur.append(obj)
    with open(path, "w") as f:
        json.dump(cur, f, indent=2)

def safe_load_json(path, default=None):
    try:
        with open(path, "r") as f:
            return json.load(f)
    except Exception:
        return default

def ts_print(*a):
    print(f"[{now_str()}]", *a, flush=True)

ensure_dirs()

# =========[ 3) DATA SOURCES ]=========
_binance_client_cache = None

def binance_client():
    global _binance_client_cache
    if not BINANCE_OK:
        raise ImportError("python-binance tidak terinstall")
    if _binance_client_cache is None:
        c = Client(api_key=BINANCE_API_KEY, api_secret=BINANCE_SECRET_KEY)
        if USE_BINANCE_FUTURES:
            try:
                c.futures_change_margin_type(symbol="BTCUSDT", marginType="CROSS")
            except Exception:
                pass
        _binance_client_cache = c
    return _binance_client_cache

def get_klines(symbol: str, interval: str = "15m", limit: int = 500) -> pd.DataFrame:
    c   = binance_client()
    raw = c.get_klines(symbol=symbol, interval=interval, limit=limit)
    cols = ["open_time","open","high","low","close","volume",
            "close_time","qav","trades","tb_base","tb_quote","ignore"]
    df = pd.DataFrame(raw, columns=cols)
    for col in ["open","high","low","close","volume"]:
        df[col] = df[col].astype(float)
    df["open_time"] = pd.to_datetime(df["open_time"], unit="ms")
    return df[["open_time","open","high","low","close","volume"]]

def get_price(symbol: str) -> float:
    c = binance_client()
    if USE_BINANCE_FUTURES:
        p = c.futures_symbol_ticker(symbol=symbol)["price"]
    else:
        p = c.get_symbol_ticker(symbol=symbol)["price"]
    return float(p)

def dex_trending():
    r = requests.get(DEXSCREENER_TRENDING, timeout=10)
    r.raise_for_status()
    return r.json()

def dex_by_ca(contract_addr: str):
    url = DEXSCREENER_BY_CA.format(ca=contract_addr)
    r   = requests.get(url, timeout=10)
    r.raise_for_status()
    return r.json()

# =========[ 4) INDIKATOR ]=========
def rsi(close: pd.Series, period: int = 14) -> pd.Series:
    delta = close.diff()
    gain  = (delta.clip(lower=0)).ewm(alpha=1/period, adjust=False).mean()
    loss  = (-delta.clip(upper=0)).ewm(alpha=1/period, adjust=False).mean()
    rs    = gain / (loss + 1e-12)
    return 100 - (100 / (1 + rs))

def ema(close: pd.Series, n: int = 21) -> pd.Series:
    return close.ewm(span=n, adjust=False).mean()

def ma(close: pd.Series, n: int = 50) -> pd.Series:
    return close.rolling(n).mean()

def atr(df: pd.DataFrame, period: int = 14) -> pd.Series:
    h, l, c = df["high"], df["low"], df["close"]
    pc = c.shift(1)
    tr = pd.concat([(h-l), (h-pc).abs(), (l-pc).abs()], axis=1).max(axis=1)
    return tr.rolling(period).mean()

# =========[ 5) LAYER CONFIRM (9-LAYER) ]=========
def layer_ultrascalper(df15):
    c, v   = df15["close"], df15["volume"]
    e21    = ema(c, 21)
    vol_ok = v.tail(5).mean() > v.tail(20).mean() * 1.15
    return bool(c.iloc[-1] > e21.iloc[-1] and vol_ok)

def layer_primeswing(df15):
    m50, m200 = ma(df15["close"], 50), ma(df15["close"], 200)
    return bool(m50.iloc[-1] > m200.iloc[-1])

def layer_macroflow(df1d):
    e21, e50 = ema(df1d["close"], 21), ema(df1d["close"], 50)
    return bool(e21.iloc[-1] > e50.iloc[-1])

def layer_atr_ok(df15):
    a   = atr(df15, 14).iloc[-1]
    rng = df15["high"].iloc[-1] - df15["low"].iloc[-1]
    return bool(a > 0 and (rng / (a + 1e-9)) < 2.5)

def layer_rsi_ok(df15):
    val = rsi(df15["close"], 14).iloc[-1]
    return bool(45 <= val <= 70)

def layer_volume_spike(df15):
    v = df15["volume"]
    return bool(v.iloc[-1] > v.tail(30).mean() * 1.5)

def layer_trend_align(df15, df1h):
    return bool(df15["close"].iloc[-1] > ema(df15["close"], 50).iloc[-1] and
                df1h["close"].iloc[-1] > ema(df1h["close"], 50).iloc[-1])

def layer_momentum(df15):
    c = df15["close"]
    return bool(c.iloc[-1] > c.tail(20).mean())

def confirm_all_layers(symbol: str):
    df15 = get_klines(symbol, "15m", 500)
    df1h = get_klines(symbol, "1h",  500)
    df1d = get_klines(symbol, "1d",  300)
    layers = {
        "ultrascalper": layer_ultrascalper(df15),
        "primeswing":   layer_primeswing(df15),
        "macroflow":    layer_macroflow(df1d),
        "atr":          layer_atr_ok(df15),
        "rsi":          layer_rsi_ok(df15),
        "vol_spike":    layer_volume_spike(df15),
        "trend_align":  layer_trend_align(df15, df1h),
        "momentum":     layer_momentum(df15),
    }
    return layers, df15, df1d

# =========[ 6) AI ENSEMBLE ]=========
class SimpleAI:
    def __init__(self):
        self.ready = False
        self.clf   = None
        if SKLEARN_OK:
            try:
                if os.path.exists(FILE_RF):
                    self.clf   = joblib.load(FILE_RF)
                    self.ready = True
                else:
                    X = np.array([[0.6,1.02,1.1,1.05],[0.4,0.98,0.8,0.95],[0.7,1.05,1.3,1.10]])
                    y = np.array([1,0,1])
                    self.clf = RandomForestClassifier(n_estimators=100, random_state=42).fit(X, y)
                    joblib.dump(self.clf, FILE_RF)
                    self.ready = True
            except Exception:
                self.ready = False

    def features(self, df15: pd.DataFrame, df1d: pd.DataFrame):
        c = df15["close"]
        v = df15["volume"]
        return np.array([
            float(rsi(c, 14).iloc[-1] / 100.0),
            float(ema(c, 21).iloc[-1] / (ema(c, 50).iloc[-1] + 1e-9)),
            float(v.iloc[-1] / (v.tail(30).mean() + 1e-9)),
            float(c.iloc[-1] / (ma(c, 200).iloc[-1] + 1e-9)),
        ])

    def confidence(self, df15: pd.DataFrame, df1d: pd.DataFrame) -> float:
        f = self.features(df15, df1d)
        x = float(np.clip(np.mean([min(1, max(0, val/1.2)) for val in f]), 0, 1))
        if self.ready:
            try:
                proba1 = float(self.clf.predict_proba([f])[0][1])
                return x * 0.3 + proba1 * 0.7
            except Exception:
                return x
        return x

AI = SimpleAI()

# =========[ 7) RISK & EXECUTOR ]=========
def _futures_balance_usdt() -> float:
    if not BINANCE_OK: return 0.0
    try:
        bals = binance_client().futures_account_balance()
        for b in bals:
            if b.get("asset") == "USDT":
                return float(b.get("balance", 0))
    except Exception:
        pass
    return 0.0

def _qty_all_in(symbol: str, price: float) -> float:
    usdt     = _futures_balance_usdt()
    notional = usdt * LEVERAGE
    return max(0.001, round(notional / price, 3))

def decide_side(df1d: pd.DataFrame) -> str:
    above = df1d["close"].iloc[-1] > ema(df1d["close"], 50).iloc[-1]
    return "LONG" if above else "SHORT"

def calc_sl_tp(entry: float, side: str):
    sl = entry * (1 - SL_PCT) if side == "LONG" else entry * (1 + SL_PCT)
    tp = entry * (1 + TP_PCT) if side == "LONG" else entry * (1 - TP_PCT)
    return round(sl, 4), round(tp, 4)

def place_all_in(symbol: str, side: str, price: float) -> dict:
    if DRY_RUN:
        qty    = _qty_all_in(symbol, price)
        sl, tp = calc_sl_tp(price, side)
        return {"dry_run": True, "symbol": symbol, "side": side,
                "qty": qty, "sl": sl, "tp": tp}

    if not BINANCE_OK:
        raise RuntimeError("python-binance tidak terinstall")

    bc = binance_client()
    try:
        bc.futures_change_leverage(symbol=symbol, leverage=LEVERAGE)
    except Exception:
        pass

    qty        = _qty_all_in(symbol, price)
    sl, tp     = calc_sl_tp(price, side)
    order_side = SIDE_BUY if side == "LONG" else SIDE_SELL
    opp_side   = SIDE_SELL if order_side == SIDE_BUY else SIDE_BUY

    bc.futures_create_order(symbol=symbol, side=order_side,
                            type=ORDER_TYPE_MARKET, quantity=qty)
    bc.futures_create_order(symbol=symbol, side=opp_side,
                            type=ORDER_TYPE_STOP_MARKET,
                            stopPrice=str(sl), closePosition=True)
    bc.futures_create_order(symbol=symbol, side=opp_side,
                            type=ORDER_TYPE_TAKE_PROFIT_MARKET,
                            stopPrice=str(tp), closePosition=True)
    return {"ok": True, "symbol": symbol, "side": side, "qty": qty, "sl": sl, "tp": tp}

# =========[ 8) LOGIC DECISION ]=========
def decide_and_execute(symbol: str) -> dict:
    try:
        layers, df15, df1d = confirm_all_layers(symbol)
        conf       = AI.confidence(df15, df1d)
        layers_ok  = all(layers.values()) if ALL_LAYER_REQUIRED else True
        mastercall = (conf >= CONF_THRESHOLD)
        final_ok   = (layers_ok and mastercall)

        entry = None
        if ALL_IN_MODE and final_ok:
            side  = decide_side(df1d)
            price = get_price(symbol)
            entry = place_all_in(symbol, side, price)

        log = {
            "t":          now_str(),
            "symbol":     symbol,
            "layers":     layers,
            "confidence": round(conf, 4),
            "executed":   bool(entry is not None),
            "entry":      entry,
        }
        append_jsonl(FILE_SIGNAL_LOG, log)
        return log
    except Exception as e:
        err = {"t": now_str(), "symbol": symbol,
               "error": str(e), "trace": traceback.format_exc()[:500]}
        append_jsonl(FILE_SIGNAL_LOG, err)
        return err

# =========[ 9) SCALPING ENGINE ]=========
def run_scalping():
    ts_print("🔁 Scalping engine RUN")
    while True:
        for sym in PAIRS:
            try:
                res = decide_and_execute(sym)
                ts_print("SCALP", sym, res.get("confidence"), "exec=", res.get("executed"))
                time.sleep(1)
            except Exception as e:
                ts_print("ERR SCALP", sym, e)
        time.sleep(10)

# =========[ 10) SNIPER ENGINE ]=========
def run_sniper():
    ts_print("🔫 Sniper engine RUN")
    while True:
        for sym in PAIRS:
            try:
                layers, df15, df1d = confirm_all_layers(sym)
                conf = AI.confidence(df15, df1d)
                if conf >= 0.94 and all(layers.values()):
                    side  = decide_side(df1d)
                    price = get_price(sym)
                    entry = place_all_in(sym, side, price)
                    append_jsonl(FILE_SIGNAL_LOG, {
                        "t": now_str(), "symbol": sym, "mode": "SNIPER",
                        "confidence": round(conf, 4), "entry": entry,
                    })
                    ts_print("SNIPER🔥", sym, conf, entry)
                time.sleep(1)
            except Exception as e:
                ts_print("ERR SNIPER", sym, e)
        time.sleep(8)

# =========[ 11) FEED LISTENER (DexScreener) ]=========
def update_feed_signals():
    ts_print("📡 Dex feed RUN")
    while True:
        try:
            data = dex_trending()
            append_jsonl(FILE_FEED_LOG, {"t": now_str(),
                                         "dex_trending": True,
                                         "size": len(str(data))})
        except Exception as e:
            append_jsonl(FILE_FEED_LOG, {"t": now_str(), "error": str(e)})
        time.sleep(60)

# =========[ 12) SENTIMENT MINER ]=========
def mine_sentiment():
    ts_print("💬 Sentiment miner RUN")
    while True:
        try:
            score = round(random.uniform(0.3, 0.8), 3)
            with open(FILE_SENTIMENT, "w") as f:
                f.write(str(score))
            append_jsonl(FILE_FEED_LOG, {"t": now_str(), "sentiment": score})
        except Exception as e:
            append_jsonl(FILE_FEED_LOG, {"t": now_str(), "sentiment_err": str(e)})
        time.sleep(45)

# =========[ 13) TELEGRAM BOT ]=========
def start_bot():
    if not TELEGRAM_OK or not BOT_TOKEN:
        ts_print("⚠️  Telegram bot tidak aktif (library/token tidak tersedia)")
        return

    ts_print("🤖 Telegram bot RUN")
    _tele_bot = Bot(token=BOT_TOKEN)

    def tg_send(msg: str):
        try:
            _tele_bot.send_message(chat_id=OWNER_ID, text=msg)
        except Exception:
            pass

    def cmd_start(update: Update, ctx: CallbackContext):
        if update.effective_user.id != OWNER_ID: return
        ctx.bot.send_message(chat_id=OWNER_ID,
            text="🤖 MD90 Supreme aktif.\n/status /manual_buy SYM /manual_sell SYM /kill")

    def cmd_status(update: Update, ctx: CallbackContext):
        if update.effective_user.id != OWNER_ID: return
        last  = safe_load_json(FILE_SIGNAL_LOG, [])
        lastn = last[-3:] if last else []
        ctx.bot.send_message(chat_id=OWNER_ID,
            text=f"✅ Running.\nPairs: {PAIRS}\nLast: {json.dumps(lastn, indent=2)[:1200]}")

    def cmd_manual_buy(update: Update, ctx: CallbackContext):
        if update.effective_user.id != OWNER_ID: return
        try:
            sym   = str(ctx.args[0]).upper()
            price = get_price(sym)
            entry = place_all_in(sym, "LONG", price)
            tg_send(f"BUY {sym} → {entry}")
        except Exception as e:
            tg_send(f"Manual BUY error: {e}")

    def cmd_manual_sell(update: Update, ctx: CallbackContext):
        if update.effective_user.id != OWNER_ID: return
        try:
            sym   = str(ctx.args[0]).upper()
            price = get_price(sym)
            entry = place_all_in(sym, "SHORT", price)
            tg_send(f"SELL {sym} → {entry}")
        except Exception as e:
            tg_send(f"Manual SELL error: {e}")

    def cmd_kill(update: Update, ctx: CallbackContext):
        if update.effective_user.id != OWNER_ID: return
        tg_send("🔥 Kill requested. Stopping...")
        os._exit(0)

    up = Updater(token=BOT_TOKEN, use_context=True)
    dp = up.dispatcher
    dp.add_handler(CommandHandler("start",       cmd_start))
    dp.add_handler(CommandHandler("status",      cmd_status))
    dp.add_handler(CommandHandler("manual_buy",  cmd_manual_buy))
    dp.add_handler(CommandHandler("manual_sell", cmd_manual_sell))
    dp.add_handler(CommandHandler("kill",        cmd_kill))
    up.start_polling()
    up.idle()

# =========[ 14) DASHBOARD (Flask) ]=========
def start_dashboard():
    if not FLASK_OK:
        ts_print("⚠️  Flask tidak terinstall — dashboard nonaktif")
        return
    ts_print("📊 Dashboard http://0.0.0.0:5000")
    app = Flask(__name__)

    @app.route("/")
    def home():
        return jsonify({
            "status":      "MD90 Supreme RUN",
            "pairs":       PAIRS,
            "dry_run":     DRY_RUN,
            "last_signal": (safe_load_json(FILE_SIGNAL_LOG, []) or [])[-5:],
            "last_risk":   (safe_load_json(FILE_RISK_LOG,   []) or [])[-5:],
            "last_feed":   (safe_load_json(FILE_FEED_LOG,   []) or [])[-5:],
        })

    app.run(host="0.0.0.0", port=5000, debug=False, use_reloader=False)

# =========[ 15) RETRAIN LOOP ]=========
def retrain_loop():
    if not SKLEARN_OK:
        ts_print("Retrain skipped (sklearn not available).")
        return
    ts_print("🔁 Retrain loop RUN")
    while True:
        try:
            data = safe_load_json(FILE_RETRAINSET, [])
            if data and len(data) >= 10:
                X   = np.array([d["features"] for d in data], dtype=float)
                y   = np.array([d["label"]    for d in data], dtype=int)
                clf = RandomForestClassifier(n_estimators=200, random_state=42).fit(X, y)
                joblib.dump(clf, FILE_RF)
                ts_print(f"✅ Model retrained: {len(data)} rows")
                append_jsonl(FILE_RISK_LOG,
                             {"t": now_str(), "retrain": "ok", "rows": len(data)})
            else:
                ts_print("Retrain: data < 10, skip.")
        except Exception as e:
            append_jsonl(FILE_RISK_LOG, {"t": now_str(), "retrain_err": str(e)})
        time.sleep(RETRAIN_INTERVAL_HOURS * 3600)

# =========[ 16) PRICE SNAPSHOT ]=========
def run_price_listener():
    ts_print("🔄 Price snapshot RUN")
    while True:
        try:
            snap = {}
            for sym in PAIRS:
                try:
                    snap[sym] = get_price(sym)
                except Exception:
                    pass
            with open(FILE_PRICE_SNAP, "w") as f:
                json.dump(snap, f)
        except Exception as e:
            append_jsonl(FILE_RISK_LOG, {"t": now_str(), "price_err": str(e)})
        time.sleep(20)

# =========[ 17) ORCHESTRATOR (MAIN) ]=========
def handle_sigterm(sig, frame):
    ts_print("SIGTERM received. Exiting...")
    sys.exit(0)

signal.signal(signal.SIGTERM, handle_sigterm)

if __name__ == "__main__":
    ts_print("🚀 MD90 SCALPING SUPREME — START")
    ts_print(f"   DRY_RUN={DRY_RUN} | PAIRS={PAIRS}")

    threads = []

    if USE_SCALPING:
        threads.append(threading.Thread(target=run_scalping,       daemon=True))
    if USE_SNIPER:
        threads.append(threading.Thread(target=run_sniper,         daemon=True))

    threads += [
        threading.Thread(target=update_feed_signals,               daemon=True),
        threading.Thread(target=mine_sentiment,                     daemon=True),
        threading.Thread(target=run_price_listener,                 daemon=True),
    ]

    if USE_STREAM_DASHBOARD:
        threads.append(threading.Thread(target=start_dashboard,    daemon=True))
    if USE_AUTO_RETRAIN:
        threads.append(threading.Thread(target=retrain_loop,       daemon=True))

    threads.append(threading.Thread(target=start_bot,              daemon=True))

    for t in threads:
        t.start()

    # Keep-alive
    while True:
        time.sleep(60)

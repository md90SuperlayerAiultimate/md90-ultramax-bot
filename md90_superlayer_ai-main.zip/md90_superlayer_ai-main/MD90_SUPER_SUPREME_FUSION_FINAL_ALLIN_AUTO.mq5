//+------------------------------------------------------------------+
//| MD90_SUPER_SUPREME_FUSION_FINAL_ALLIN_AUTO.mq5                   |
//| MTR-V7 HYBRID CORE: MTF Trend + Momentum + VWAP + ATR SL         |
//| Multi-TP, BE, Trailing, Daily-Loss-Guard, Time-Filter             |
//| External JSON Signal (CHRONOS-AI Engine)                          |
//| NEURAL NETWORK OCL FRAMEWORK (CNeuronFinMem) — Dummy Stubs        |
//+------------------------------------------------------------------+
#property copyright "MD90"
#property version   "2.00"
#property strict

#include <Trade/Trade.mqh>
#include <Trade/PositionInfo.mqh>
#include <Files/File.mqh>

//=== Dummy OCL stubs (agar CNeuronFinMem bisa compile) ===============
#define ENUM_OPTIMIZATION int
#define ENUM_ACTIVATION   int

class CBufferFloat
{
public:
    bool BufferWrite(CBufferFloat *b = NULL) { return true; }
};

class COpenCLMy {};

class CNeuronBaseOCL
{
public:
    bool          SetGradient(CBufferFloat *b, bool clear) { return true; }
    CBufferFloat *getGradient()     { return NULL; }
    bool          calcHiddenGradients(CNeuronBaseOCL *n) { return true; }
    CNeuronBaseOCL *AsObject()      { return this; }
    CBufferFloat *getPrevOutput()   { return NULL; }
};

class CNeuronTransposeOCL : public CNeuronBaseOCL
{
public:
    bool Init(uint num, uint my, COpenCLMy *ocl, uint w, uint wk,
              ENUM_OPTIMIZATION op, uint b)  { return true; }
    bool FeedForward(CNeuronBaseOCL *n)      { return true; }
    CNeuronBaseOCL *AsObject()               { return this; }
    bool calcHiddenGradients(CNeuronBaseOCL *n) { return true; }
    CBufferFloat *getPrevOutput()            { return NULL; }
};

class CNeuronMemory : public CNeuronBaseOCL
{
public:
    bool Init(uint num, uint my, COpenCLMy *ocl, uint w, uint wk,
              ENUM_OPTIMIZATION op, uint b)  { return true; }
    bool FeedForward(CNeuronBaseOCL *n)      { return true; }
    bool calcHiddenGradients(CNeuronBaseOCL *n) { return true; }
    CBufferFloat *getOutput()  { return NULL; }
    CBufferFloat *getGradient(){ return NULL; }
};

class CNeuronRelativeCrossAttention : public CNeuronBaseOCL
{
public:
    virtual bool Init(uint numOutputs, uint myIndex, COpenCLMy *ocl,
                      ENUM_OPTIMIZATION optimization_type, uint batch) { return true; }
    virtual bool Init(uint numOutputs, uint myIndex, COpenCLMy *ocl,
                      uint window, uint window_key, uint heads,
                      ENUM_OPTIMIZATION optimization_type, uint batch) { return true; }
    bool FeedForward(CNeuronBaseOCL *n, CBufferFloat *b)   { return true; }
    bool feedForward(CNeuronBaseOCL *n, CBufferFloat *b)   { return true; }
    virtual bool FeedForward(CNeuronBaseOCL *n)            { return true; }
    CBufferFloat *getOutput()   { return NULL; }
    CBufferFloat *getGradient() { return NULL; }
    int  Activation()           { return 0; }
    bool calcHiddenGradients(CNeuronBaseOCL *n) { return true; }
    CBufferFloat *getPrevOutput()               { return NULL; }
    virtual bool calcInputGradients(CNeuronBaseOCL *NeuronOCL)   { return false; }
    virtual bool updateInputWeights(CNeuronBaseOCL *NeuronOCL)   { return false; }
};

//=== Konstan NN =======================================================
#define defNeuronFinMem        900
#define defNeuronBaseOCL       901
#define defNeuronBatchNormOCL  902
#define defNeuronVAEOCL        903
#define defNeuronConvSAMOCL    904
#define ADAM                   1
#define None                   0
#define SIGMOID                10

//=== Parameter eksternal NN ===========================================
extern int   HistoryBars  = 128;
extern int   BarDescr     = 8;
extern int   AccountDescr = 10;
extern int   NActions     = 9;
extern float Rho          = 0.5;

//+------------------------------------------------------------------+
//| CNeuronFinMem — Implementasi Penuh                               |
//+------------------------------------------------------------------+
class CNeuronFinMem : public CNeuronRelativeCrossAttention
{
protected:
    CNeuronTransposeOCL          cTransposeState;
    CNeuronMemory                cMemory[2];
    CNeuronRelativeCrossAttention cCrossMemory;
    CNeuronRelativeCrossAttention cMemoryToAccount;
    CNeuronRelativeCrossAttention cActionToAccount;

    virtual bool feedForward(CNeuronBaseOCL *NeuronOCL)                      { return false; }
    virtual bool feedForward(CNeuronBaseOCL *NeuronOCL, CBufferFloat *SecondInput) { return true; }

    virtual bool calcInputGradients(CNeuronBaseOCL *NeuronOCL)               { return false; }
    virtual bool calcInputGradients(CNeuronBaseOCL *NeuronOCL,
                                    CBufferFloat *SecondInput,
                                    CBufferFloat *SecondGradient,
                                    ENUM_ACTIVATION SecondActivation = None)  { return true; }

    virtual bool updateInputWeights(CNeuronBaseOCL *NeuronOCL)               { return false; }
    virtual bool updateInputWeights(CNeuronBaseOCL *NeuronOCL,
                                    CBufferFloat *SecondInput)               { return true; }

public:
    CNeuronFinMem(void)  {}
    ~CNeuronFinMem(void) {}

    // BUG FIX: hapus "const" — MQL5 tidak support "virtual bool ... override const"
    virtual bool Init(uint numOutputs, uint myIndex, COpenCLMy *open_cl,
                      uint window, uint window_key, uint units_count, uint heads,
                      uint account_descr, uint nactions,
                      ENUM_OPTIMIZATION optimization_type, uint batch)
    {
        if (!CNeuronRelativeCrossAttention::Init(numOutputs, myIndex, open_cl,
                                                  optimization_type, batch))
            return false;

        uint mem_units = units_count;

        if (!cTransposeState.Init(mem_units, myIndex, open_cl,
                                  window * window_key, 1, optimization_type, batch))
            return false;

        for (int i = 0; i < 2; i++)
            if (!cMemory[i].Init(mem_units, myIndex, open_cl,
                                 mem_units, 1, optimization_type, batch))
                return false;

        if (!cCrossMemory.Init(mem_units, myIndex, open_cl,
                               mem_units, units_count, heads, optimization_type, batch))
            return false;

        if (!cMemoryToAccount.Init(mem_units, myIndex, open_cl,
                                   mem_units, account_descr, heads, optimization_type, batch))
            return false;

        if (!cActionToAccount.Init(nactions, myIndex, open_cl,
                                   mem_units, nactions, heads, optimization_type, batch))
            return false;

        return true;
    }

    virtual bool FeedForward(CNeuronBaseOCL *NeuronOCL)
    {
        if (!cTransposeState.FeedForward(NeuronOCL))                              return false;
        if (!cMemory[0].FeedForward(cMemory[1].AsObject()))                       return false;
        if (!cCrossMemory.FeedForward(cTransposeState.AsObject(),
                                      cMemory[0].getOutput()))                    return false;
        if (!cMemory[1].FeedForward(cCrossMemory.AsObject()))                     return false;
        if (!cMemoryToAccount.FeedForward(cCrossMemory.AsObject(),
                                          NeuronOCL.getPrevOutput()))             return false;
        if (!cActionToAccount.FeedForward(cMemoryToAccount.AsObject(),
                                          NeuronOCL.getPrevOutput()))             return false;

        CBufferFloat *output = cActionToAccount.getOutput();
        if (output == NULL) return false;
        if (!getOutput().BufferWrite(output)) return false;

        return true;
    }

    virtual int Type(void) { return defNeuronFinMem; }   // BUG FIX: hapus "override const"
};

//===================================================================
//                   EXPERT ADVISOR MAIN CODE
//===================================================================

#define EA_MAGIC  909000
#define PNL_FILE  "MD90_Daily_PNL.csv"

CTrade        m_trade;
CPositionInfo m_pos;

//=== Inputs: Risk & Session =========================================
input double RiskPercent       = 1.0;
input double MaxDailyLossPct   = 3.0;
input int    CooldownMinutes   = 60;
input bool   UseTimeFilter     = true;
input int    Sess1StartUTC     = 8;
input int    Sess1EndUTC       = 11;
input int    Sess2StartUTC     = 15;
input int    Sess2EndUTC       = 18;

//=== Inputs: Signals ================================================
input int    EMAfast           = 50;
input int    EMAslow           = 200;
input int    StochK            = 14;
input int    StochD            = 5;
input int    StochSlowing      = 5;
input int    StochBuyLv        = 20;
input int    StochSellLv       = 80;
input int    RSIperiod         = 8;
input double RSIEntryLevel     = 55.0;
input bool   UseVWAPFilter     = true;
input double VWAP_ATR_Factor   = 0.5;
input ENUM_TIMEFRAMES TrendTF_A = PERIOD_M15;
input ENUM_TIMEFRAMES TrendTF_B = PERIOD_H1;

//=== Inputs: SL/TP ==================================================
input int    ATR_Period        = 14;
input double ATR_SL_Mult       = 1.5;
input double RR_TP1            = 1.0;
input double RR_TP2            = 2.0;
input double RR_TP3            = 3.0;
input double Qty_TP1_Pct       = 40.0;
input double Qty_TP2_Pct       = 35.0;
input double Qty_TP3_Pct       = 25.0;

//=== Inputs: Position Management ====================================
input double Trailing_ATR_Mult = 1.2;
input int    PipsToBE          = 10;
input int    UpdateSLEverySec  = 10;

//=== Inputs: External JSON ==========================================
input bool   UseExternalJSON   = true;
input string ExtJSON_File      = "fusion_signal.json";
input double ExtJSON_MinScore  = 70.0;

//=== State ==========================================================
double   g_daily_pnl        = 0.0;
datetime g_cooldown_until   = 0;
datetime g_last_sl_update   = 0;
datetime g_last_bar_time    = 0;
long     g_last_deal_scanned = 0;

//=== Handles ========================================================
int hATR     = INVALID_HANDLE;
int hRSI     = INVALID_HANDLE;
int hStoch   = INVALID_HANDLE;
int hEMA_F_cur = INVALID_HANDLE;
int hEMA_S_cur = INVALID_HANDLE;
int hEMA200    = INVALID_HANDLE;
int hEMA_F_A   = INVALID_HANDLE;
int hEMA_S_B   = INVALID_HANDLE;

//+------------------------------------------------------------------+
//| Helpers                                                          |
//+------------------------------------------------------------------+
bool GetBuf(const int h, int buf, int shift, double &v)
{
    double t[1];
    if (h == INVALID_HANDLE) return false;
    if (CopyBuffer(h, buf, shift, 1, t) < 1) return false;
    v = t[0];
    return true;
}

double NormalizeLot(double lot)
{
    double mn = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN);
    double mx = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MAX);
    double st = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_STEP);
    if (lot < mn) return 0.0;
    if (lot > mx)  lot = mx;
    lot = MathFloor(lot / st) * st;
    int dg = (int)MathMax(0.0, -MathLog10(st));
    return NormalizeDouble(lot, dg);
}

double LotsByRisk(double sl_points)
{
    if (sl_points <= 0) return 0.0;
    double risk$  = AccountInfoDouble(ACCOUNT_BALANCE) * RiskPercent / 100.0;
    double tick$  = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE);
    double ticksz = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_SIZE);
    double perpt  = tick$ / ticksz;
    return NormalizeLot(risk$ / (sl_points * perpt));
}

bool TradingHours()
{
    if (!UseTimeFilter) return true;
    // BUG FIX: TimeHour() adalah MQL4 — gunakan MqlDateTime di MQL5
    MqlDateTime dt;
    TimeToStruct(TimeCurrent(), dt);
    int h = dt.hour;
    if (h >= Sess1StartUTC && h < Sess1EndUTC) return true;
    if (h >= Sess2StartUTC && h < Sess2EndUTC) return true;
    return false;
}

double DayVWAP()
{
    MqlRates r[];
    datetime t0 = iTime(_Symbol, PERIOD_D1, 0);
    int n = CopyRates(_Symbol, PERIOD_M1, 0, 3000, r);
    double sumPV = 0, sumV = 0;
    for (int i = 0; i < n; i++)
    {
        if (r[i].time < t0) break;
        double tp = (r[i].high + r[i].low + r[i].close) / 3.0;
        double v  = (double)r[i].tick_volume;
        sumPV += tp * v;
        sumV  += v;
    }
    if (sumV <= 0)
    {
        double a = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
        double b = SymbolInfoDouble(_Symbol, SYMBOL_BID);
        return (a + b) / 2.0;
    }
    return sumPV / sumV;
}

double CalcSL_ATR(ENUM_ORDER_TYPE t)
{
    double atr;
    if (!GetBuf(hATR, 0, 1, atr)) return 0.0;
    double d = atr * ATR_SL_Mult;
    if (d <= 0) return 0.0;
    double ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
    double bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);
    return (t == ORDER_TYPE_BUY) ? ask - d : bid + d;
}

bool IsNewBar()
{
    datetime t = iTime(_Symbol, _Period, 0);
    if (t == 0) return false;
    if (t > g_last_bar_time) { g_last_bar_time = t; return true; }
    return false;
}

void WriteDailyPnL()
{
    int f = FileOpen(PNL_FILE, FILE_READ | FILE_WRITE | FILE_CSV |
                     FILE_SHARE_WRITE | FILE_ANSI, ',');
    if (f == INVALID_HANDLE)
    {
        Print("PNL file open error: ", GetLastError());
        return;
    }
    if (FileSize(f) == 0) FileWrite(f, "Date", "PNL", "Balance");
    MqlDateTime dt;
    TimeToStruct(TimeCurrent(), dt);
    dt.hour = 0; dt.min = 0; dt.sec = 0;
    string d = TimeToString(StructToTime(dt), TIME_DATE);
    FileSeek(f, 0, SEEK_END);
    FileWrite(f, d,
              DoubleToString(g_daily_pnl, 2),
              DoubleToString(AccountInfoDouble(ACCOUNT_BALANCE), 2));
    FileClose(f);
}

void DailyRiskGuard()
{
    double max_loss = AccountInfoDouble(ACCOUNT_BALANCE) * MaxDailyLossPct / 100.0;
    if (g_daily_pnl >= -max_loss) return;

    MqlDateTime dt;
    TimeToStruct(TimeCurrent(), dt);
    dt.hour = 0; dt.min = 0; dt.sec = 0; dt.day++;
    datetime tMid  = StructToTime(dt);
    datetime tCool = TimeCurrent() + CooldownMinutes * 60;
    g_cooldown_until = (tCool > tMid ? tCool : tMid);

    for (int i = PositionsTotal() - 1; i >= 0; i--)
        if (m_pos.SelectByIndex(i) && m_pos.Magic() == EA_MAGIC)
            m_trade.PositionClose(m_pos.Ticket());

    Print("Daily Loss Limit hit. Cooldown until ",
          TimeToString(g_cooldown_until, TIME_DATE | TIME_MINUTES));
}

//+------------------------------------------------------------------+
//| Position Management: BE + Trailing + EMA200 Flip                |
//+------------------------------------------------------------------+
void ManagePositions()
{
    for (int i = PositionsTotal() - 1; i >= 0; i--)
    {
        if (!m_pos.SelectByIndex(i)) continue;
        if (m_pos.Magic() != EA_MAGIC || m_pos.Symbol() != _Symbol) continue;

        ENUM_POSITION_TYPE typ = m_pos.PositionType();
        double price  = (typ == POSITION_TYPE_BUY)
                        ? SymbolInfoDouble(_Symbol, SYMBOL_BID)
                        : SymbolInfoDouble(_Symbol, SYMBOL_ASK);
        double sl     = m_pos.StopLoss();
        double tp     = m_pos.TakeProfit();
        double entry  = m_pos.PriceOpen();

        double atr;
        if (!GetBuf(hATR, 0, 1, atr)) return;
        double trail = atr * Trailing_ATR_Mult;

        double sl0      = CalcSL_ATR((typ == POSITION_TYPE_BUY) ? ORDER_TYPE_BUY : ORDER_TYPE_SELL);
        double risk_pts = MathAbs(entry - sl0) / _Point;

        // 1) Break-Even setelah TP1
        double tp1_level = entry + risk_pts * RR_TP1 * _Point * (typ == POSITION_TYPE_BUY ? 1 : -1);
        double be_level  = entry + PipsToBE  * _Point * (typ == POSITION_TYPE_BUY ? 1 : -1);
        bool tp1_hit     = (typ == POSITION_TYPE_BUY) ? (price >= tp1_level) : (price <= tp1_level);
        bool not_be      = (typ == POSITION_TYPE_BUY) ? (sl < be_level)      : (sl > be_level);

        if (tp1_hit && not_be)
        {
            double newSL = NormalizeDouble(be_level, _Digits);
            if (m_trade.PositionModify(m_pos.Ticket(), newSL, tp))
                PrintFormat("BE set #%I64d → %.5f", m_pos.Ticket(), newSL);
            g_last_sl_update = TimeCurrent();
        }

        // 2) Trailing setiap interval
        if (sl != 0.0 && (TimeCurrent() - g_last_sl_update) >= UpdateSLEverySec)
        {
            double newSL = sl;
            bool   mod   = false;
            if (typ == POSITION_TYPE_BUY)
            {
                newSL = price - trail;
                if (newSL > sl)
                {
                    newSL = NormalizeDouble(newSL, _Digits);
                    mod   = m_trade.PositionModify(m_pos.Ticket(), newSL, tp);
                }
            }
            else
            {
                newSL = price + trail;
                if (newSL < sl)
                {
                    newSL = NormalizeDouble(newSL, _Digits);
                    mod   = m_trade.PositionModify(m_pos.Ticket(), newSL, tp);
                }
            }
            if (mod) PrintFormat("Trail #%I64d → %.5f", m_pos.Ticket(), newSL);
            g_last_sl_update = TimeCurrent();
        }

        // 3) Emergency close saat EMA200 flip
        double e0, e1;
        if (!GetBuf(hEMA200, 0, 0, e0) || !GetBuf(hEMA200, 0, 1, e1)) return;
        bool flip = false;
        if (typ == POSITION_TYPE_BUY)  { if (price < e0 && e0 < e1) flip = true; }
        else                           { if (price > e0 && e0 > e1) flip = true; }
        if (flip)
        {
            if (m_trade.PositionClose(m_pos.Ticket()))
                PrintFormat("Emergency Close (EMA200 flip) #%I64d", m_pos.Ticket());
        }
    }
}

//+------------------------------------------------------------------+
//| External JSON Signal Reader (CHRONOS-AI / Python Bridge)         |
//+------------------------------------------------------------------+
void CheckExternalSignal()
{
    if (!UseExternalJSON) return;

    int f = FileOpen(ExtJSON_File, FILE_READ | FILE_SHARE_READ | FILE_ANSI);
    if (f == INVALID_HANDLE) return;

    string js = FileReadString(f);
    FileClose(f);

    bool   isBuy        = (StringFind(js, "\"action\":\"BUY\"")  >= 0);
    bool   isSell       = (StringFind(js, "\"action\":\"SELL\"") >= 0);
    double risk_pct_json = 0.0;
    double score         = 0.0;

    // Parse score
    int i_score = StringFind(js, "\"score\":");
    if (i_score >= 0)
    {
        string sub = StringSubstr(js, i_score + 8);
        int    j   = StringFind(sub, ",");
        if (j < 0) j = StringFind(sub, "}");
        if (j > 0) score = StringToDouble(StringSubstr(sub, 0, j));
    }

    // Parse risk
    int i_risk = StringFind(js, "\"risk\":");
    if (i_risk >= 0)
    {
        string sub = StringSubstr(js, i_risk + 7);
        int    j   = StringFind(sub, ",");
        if (j < 0) j = StringFind(sub, "}");
        if (j > 0) risk_pct_json = StringToDouble(StringSubstr(sub, 0, j));
    }

    if ((score * 100.0) < ExtJSON_MinScore) return;

    double lot_risk_pct = (risk_pct_json > 0.0) ? risk_pct_json : RiskPercent;
    double ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
    double bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);

    if (isBuy)
    {
        double sl      = CalcSL_ATR(ORDER_TYPE_BUY);
        double sl_pts  = MathAbs(ask - sl) / _Point;
        double tick$   = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE);
        double ticksz  = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_SIZE);
        double lot     = NormalizeLot(AccountInfoDouble(ACCOUNT_BALANCE) * lot_risk_pct / 100.0
                                      / (sl_pts * tick$ / ticksz));
        if (lot <= 0) return;
        double r  = sl_pts * RR_TP3 * _Point;
        double tp = NormalizeDouble(ask + r, _Digits);
        m_trade.Buy(lot, _Symbol, 0, NormalizeDouble(sl, _Digits), tp, "EXT JSON BUY");
    }
    else if (isSell)
    {
        double sl      = CalcSL_ATR(ORDER_TYPE_SELL);
        double sl_pts  = MathAbs(sl - bid) / _Point;
        double tick$   = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE);
        double ticksz  = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_SIZE);
        double lot     = NormalizeLot(AccountInfoDouble(ACCOUNT_BALANCE) * lot_risk_pct / 100.0
                                      / (sl_pts * tick$ / ticksz));
        if (lot <= 0) return;
        double r  = sl_pts * RR_TP3 * _Point;
        double tp = NormalizeDouble(bid - r, _Digits);
        m_trade.Sell(lot, _Symbol, 0, NormalizeDouble(sl, _Digits), tp, "EXT JSON SELL");
    }
}

//+------------------------------------------------------------------+
//| OnInit                                                           |
//+------------------------------------------------------------------+
int OnInit()
{
    m_trade.SetExpertMagic(EA_MAGIC);
    m_trade.SetDeviation(10);

    hATR      = iATR(_Symbol, _Period, ATR_Period);
    hRSI      = iRSI(_Symbol, _Period, RSIperiod, PRICE_CLOSE);
    hStoch    = iStochastic(_Symbol, _Period, StochK, StochSlowing, StochD,
                             MODE_SMA, STO_LOWHIGH);
    hEMA_F_cur = iMA(_Symbol, _Period,  EMAfast, 0, MODE_EMA, PRICE_CLOSE);
    hEMA_S_cur = iMA(_Symbol, _Period,  EMAslow, 0, MODE_EMA, PRICE_CLOSE);
    // BUG FIX: hEMA200 harus menggunakan EMAslow (200), bukan duplikat hEMA_S_cur
    hEMA200    = iMA(_Symbol, _Period,  200,     0, MODE_EMA, PRICE_CLOSE);
    hEMA_F_A   = iMA(_Symbol, TrendTF_A, EMAfast, 0, MODE_EMA, PRICE_CLOSE);
    hEMA_S_B   = iMA(_Symbol, TrendTF_B, EMAslow, 0, MODE_EMA, PRICE_CLOSE);

    if (hATR     == INVALID_HANDLE || hRSI     == INVALID_HANDLE ||
        hStoch   == INVALID_HANDLE || hEMA_F_cur == INVALID_HANDLE ||
        hEMA_S_cur == INVALID_HANDLE || hEMA200  == INVALID_HANDLE ||
        hEMA_F_A == INVALID_HANDLE || hEMA_S_B  == INVALID_HANDLE)
    {
        Print("Indicator init failed");
        return INIT_FAILED;
    }

    if ((int)NormalizeDouble(Qty_TP1_Pct + Qty_TP2_Pct + Qty_TP3_Pct, 0) != 100)
    {
        Print("Qty TP total harus 100%");
        return INIT_FAILED;
    }

    HistorySelect(0, TimeCurrent());
    long n = HistoryDealsTotal();
    if (n > 0)
    {
        long last = HistoryDealGetTicket(n - 1);
        if (last > 0) g_last_deal_scanned = last;
    }

    Print("MD90 SUPER SUPREME FUSION v2.00 ready");
    return INIT_SUCCEEDED;
}

//+------------------------------------------------------------------+
//| OnDeinit                                                         |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
    IndicatorRelease(hATR);
    IndicatorRelease(hRSI);
    IndicatorRelease(hStoch);
    IndicatorRelease(hEMA_F_cur);
    IndicatorRelease(hEMA_S_cur);
    IndicatorRelease(hEMA200);
    IndicatorRelease(hEMA_F_A);
    IndicatorRelease(hEMA_S_B);
}

//+------------------------------------------------------------------+
//| OnTick                                                           |
//+------------------------------------------------------------------+
void OnTick()
{
    if (!IsNewBar()) return;

    DailyRiskGuard();
    if (TimeCurrent() < g_cooldown_until) return;

    ManagePositions();

    // Jika ada posisi EA, skip entry baru
    for (int i = PositionsTotal() - 1; i >= 0; i--)
        if (m_pos.SelectByIndex(i) && m_pos.Magic() == EA_MAGIC) return;

    if (!TradingHours())
    {
        CheckExternalSignal();
        return;
    }

    //=== Indikator (shift 1 & 2 = bar closed) ========================
    double emaF1, emaS1, emaF2, emaS2;
    if (!GetBuf(hEMA_F_cur, 0, 1, emaF1) || !GetBuf(hEMA_S_cur, 0, 1, emaS1) ||
        !GetBuf(hEMA_F_cur, 0, 2, emaF2) || !GetBuf(hEMA_S_cur, 0, 2, emaS2)) return;

    double K1, D1;
    if (!GetBuf(hStoch, 0, 1, K1) || !GetBuf(hStoch, 1, 1, D1)) return;

    double rsi_val;
    if (!GetBuf(hRSI, 0, 1, rsi_val)) return;

    double vwap = DayVWAP();
    double atr;
    if (!GetBuf(hATR, 0, 1, atr)) return;

    double bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);
    double ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
    double mid = (bid + ask) / 2.0;

    bool nearVWAP = (MathAbs(mid - vwap) <= VWAP_ATR_Factor * atr);
    if (!UseVWAPFilter) nearVWAP = true;

    double emaA, emaB;
    if (!GetBuf(hEMA_F_A, 0, 1, emaA) || !GetBuf(hEMA_S_B, 0, 1, emaB)) return;

    bool upMTF = (emaA > emaB);
    bool dnMTF = (emaA < emaB);

    bool stBuy  = (K1 < StochBuyLv)  && (K1 > D1);
    bool stSel  = (K1 > StochSellLv) && (K1 < D1);
    bool emaBuy = (emaF1 > emaS1) && (emaF2 <= emaS2);
    bool emaSel = (emaF1 < emaS1) && (emaF2 >= emaS2);
    bool rsiBuy = (rsi_val >= RSIEntryLevel);
    bool rsiSel = (rsi_val <= (100.0 - RSIEntryLevel));

    bool buyCond  = upMTF && emaBuy && stBuy && rsiBuy && nearVWAP;
    bool sellCond = dnMTF && emaSel && stSel && rsiSel && nearVWAP;

    //=== Eksekusi internal ===========================================
    double sl_buy    = CalcSL_ATR(ORDER_TYPE_BUY);
    double sl_sel    = CalcSL_ATR(ORDER_TYPE_SELL);
    double slpts_buy = MathAbs(ask - sl_buy) / _Point;
    double slpts_sel = MathAbs(sl_sel - bid) / _Point;

    if (buyCond)
    {
        double lot = LotsByRisk(slpts_buy);
        if (lot > 0)
        {
            double l1  = NormalizeLot(lot * (Qty_TP1_Pct / 100.0));
            double l2  = NormalizeLot(lot * (Qty_TP2_Pct / 100.0));
            double l3  = NormalizeLot(lot * (Qty_TP3_Pct / 100.0));
            double tp1 = NormalizeDouble(ask + slpts_buy * RR_TP1 * _Point, _Digits);
            double tp2 = NormalizeDouble(ask + slpts_buy * RR_TP2 * _Point, _Digits);
            double tp3 = NormalizeDouble(ask + slpts_buy * RR_TP3 * _Point, _Digits);
            double sl  = NormalizeDouble(sl_buy, _Digits);
            if (l1 > 0) m_trade.Buy(l1, _Symbol, 0, sl, tp1, "BUY TP1");
            if (l2 > 0) m_trade.Buy(l2, _Symbol, 0, sl, tp2, "BUY TP2");
            if (l3 > 0) m_trade.Buy(l3, _Symbol, 0, sl, tp3, "BUY TP3");
        }
    }

    if (sellCond)
    {
        double lot = LotsByRisk(slpts_sel);
        if (lot > 0)
        {
            double l1  = NormalizeLot(lot * (Qty_TP1_Pct / 100.0));
            double l2  = NormalizeLot(lot * (Qty_TP2_Pct / 100.0));
            double l3  = NormalizeLot(lot * (Qty_TP3_Pct / 100.0));
            double tp1 = NormalizeDouble(bid - slpts_sel * RR_TP1 * _Point, _Digits);
            double tp2 = NormalizeDouble(bid - slpts_sel * RR_TP2 * _Point, _Digits);
            double tp3 = NormalizeDouble(bid - slpts_sel * RR_TP3 * _Point, _Digits);
            double sl  = NormalizeDouble(sl_sel, _Digits);
            if (l1 > 0) m_trade.Sell(l1, _Symbol, 0, sl, tp1, "SELL TP1");
            if (l2 > 0) m_trade.Sell(l2, _Symbol, 0, sl, tp2, "SELL TP2");
            if (l3 > 0) m_trade.Sell(l3, _Symbol, 0, sl, tp3, "SELL TP3");
        }
    }

    // Sinyal eksternal jika internal tidak terpenuhi
    if (!buyCond && !sellCond) CheckExternalSignal();
}

//+------------------------------------------------------------------+
//| OnTrade — update PnL harian                                     |
//+------------------------------------------------------------------+
void OnTrade()
{
    HistorySelect(0, TimeCurrent());
    long n = HistoryDealsTotal();

    static datetime last_mid = 0;
    MqlDateTime dt;
    TimeToStruct(TimeCurrent(), dt);
    dt.hour = 0; dt.min = 0; dt.sec = 0;
    datetime cur_mid = StructToTime(dt);

    if (cur_mid != last_mid)
    {
        if (last_mid != 0) { WriteDailyPnL(); g_daily_pnl = 0.0; }
        last_mid = cur_mid;
    }

    for (long i = n - 1; i >= 0; i--)
    {
        long tk = HistoryDealGetTicket(i);
        if (tk <= g_last_deal_scanned) break;

        if (HistoryDealGetInteger(tk, DEAL_MAGIC)  == EA_MAGIC &&
            HistoryDealGetInteger(tk, DEAL_ENTRY)  == DEAL_ENTRY_OUT &&
            HistoryDealGetString(tk,  DEAL_SYMBOL) == _Symbol)
        {
            g_daily_pnl += HistoryDealGetDouble(tk, DEAL_PROFIT);
        }
        g_last_deal_scanned = tk;
    }

    DailyRiskGuard();
}
//+------------------------------------------------------------------+

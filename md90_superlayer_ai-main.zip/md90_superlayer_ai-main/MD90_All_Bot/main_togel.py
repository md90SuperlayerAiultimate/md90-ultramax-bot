# main_togel.py — dummy script
print('main_togel.py aktif')
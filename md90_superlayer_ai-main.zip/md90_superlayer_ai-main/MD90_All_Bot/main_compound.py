# main_compound.py — dummy script
print('main_compound.py aktif')
# main_scalping.py — dummy script
print('main_scalping.py aktif')

from compound_engine import execute_compound_strategy
from telegram_bot import start_bot

if __name__ == "__main__":
    execute_compound_strategy()
    start_bot()
from ml_model import predict_entry
from logic_scoring_v4 import score_signal
from feed_listener import get_live_signals
from risk_allocator import allocate_risk
from json_logger import log_compound_result

def execute_compound_strategy():
    signals = get_live_signals()
    for signal in signals:
        score = score_signal(signal)
        if score > 0.75:
            prediction = predict_entry(signal)
            risk = allocate_risk(signal, score)
            log_compound_result(signal, prediction, score, risk)
def score_signal(signal):
    score = 0
    if signal.get("pump") or signal.get("whale_entry"):
        score += 0.5
    if signal.get("volume_spike"):
        score += 0.3
    if signal.get("mint_suspicious") or signal.get("honeypot_detected"):
        score -= 0.4
    return round(score, 2)
import pickle

MODEL_PATH = "model/rf_compound_model.pkl"

def predict_entry(signal_features):
    with open(MODEL_PATH, "rb") as f:
        model = pickle.load(f)
    features = [
        signal_features.get("volume", 0),
        signal_features.get("liquidity", 0),
        signal_features.get("score", 0)
    ]
    return model.predict([features])[0]
import telebot
from json_logger import fetch_latest_output

API_TOKEN = "YOUR_TELEGRAM_BOT_TOKEN"
bot = telebot.TeleBot(API_TOKEN)

@bot.message_handler(commands=['status'])
def send_status(message):
    report = fetch_latest_output()
    bot.reply_to(message, f"📊 Status Compound:\n{report}")

def start_bot():
    bot.polling()
import json
import os

FEED_PATH = "data/feed_snapshots.json"

def get_live_signals():
    if os.path.exists(FEED_PATH):
        with open(FEED_PATH, "r") as f:
            data = json.load(f)
            return data.get("signals", [])
    return []
def allocate_risk(signal, score):
    base_risk = 1.0  # default 1%
    if score > 0.85:
        return min(2.0, base_risk + 0.5)
    elif score < 0.6:
        return 0.25
    return base_risk
import json
from datetime import datetime

LOG_FILE = "logs/compound_logs.json"

def log_compound_result(signal, prediction, score, risk):
    entry = {
        "timestamp": datetime.utcnow().isoformat(),
        "signal": signal,
        "prediction": prediction,
        "score": score,
        "risk": risk
    }
    try:
        with open(LOG_FILE, "r") as f:
            data = json.load(f)
    except:
        data = {"logs": []}
    data["logs"].append(entry)
    with open(LOG_FILE, "w") as f:
        json.dump(data, f, indent=2)

def fetch_latest_output():
    try:
        with open(LOG_FILE, "r") as f:
            data = json.load(f)
            if data["logs"]:
                return json.dumps(data["logs"][-1], indent=2)
    except:
        return "Belum ada data."
from datetime import datetime, timedelta
import pytz

def now_wita():
    return datetime.utcnow().replace(tzinfo=pytz.utc).astimezone(pytz.timezone("Asia/Makassar"))
{
  "max_risk_percent": 2.0,
  "default_risk_percent": 1.0,
  "min_risk_percent": 0.25,
  "model_threshold": 0.6,
  "feed_check_interval_sec": 180,
  "retrain_interval_hours": 24
}
def parse_chronyx(data):
    if "buy" in data["type"]:
        return {"signal": data["token"], "type": "snipe"}
    return None
def parse_crytoshix(data):
    if data.get("pump_score", 0) > 7:
        return {"signal": data["token"], "type": "pump_alert"}
    return None
def parse_solinsider(data):
    if "CA_pump" in data.get("tags", []):
        return {"signal": data["token"], "type": "ca_pump"}
    return None
def parse_listingbot(data):
    if data.get("platform") in ["Raydium", "OpenBook"]:
        return {"signal": data["token"], "type": "listing_detected"}
    return None
def parse_pumpfun(data):
    if data.get("viral_score", 0) > 8:
        return {"signal": data["token"], "type": "viral_token"}
    return None
def parse_solradar(data):
    if data.get("mint_flag", False):
        return {"signal": data["token"], "type": "mint_detected"}
    return None
def parse_mevx(data):
    if "new_pair" in data:
        return {"signal": data["token"], "type": "new_pair"}
    return None
def parse_birdeye(data):
    if data.get("lp_locked_ratio", 0) < 0.1:
        return {"signal": data["token"], "type": "low_lp_risk"}
    return None
def parse_rugcheck(data):
    if data.get("freeze_detected", False):
        return {"signal": data["token"], "type": "freeze_alert"}
    return None
def parse_tokensniffer(data):
    if data.get("reputation", "") == "honeypot":
        return {"signal": data["token"], "type": "honeypot_alert"}
    return None
def parse_sniperhub(data):
    if data.get("dump_detected", False):
        return {"signal": data["token"], "type": "dump_warning"}
    return None
def parse_pumpwhalex(data):
    if data.get("whale_count", 0) >= 3:
        return {"signal": data["token"], "type": "whale_spotted"}
    return None
[]
import time
from ml_model import train_model

def retrain_loop(interval_hours=24):
    while True:
        train_model()
        time.sleep(interval_hours * 3600)
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
import joblib

def train_model():
    df = pd.read_csv("data/compound_dataset.csv")
    X = df.drop("label", axis=1)
    y = df["label"]
    model = RandomForestClassifier(n_estimators=200, random_state=42)
    model.fit(X, y)
    joblib.dump(model, "model/rf_compound_model.pkl")

def predict(model, features):
    return model.predict([features])[0]
def calculate_dynamic_risk(signal, sentiment_score):
    base_risk = 1.0
    if signal == "whale_spotted":
        base_risk *= 2.0
    if sentiment_score < 0.3:
        base_risk *= 0.5
    return min(max(base_risk, 0.25), 3.0)
import json
from datetime import datetime

def log_json(data, path="logs/json_output_history.json"):
    timestamp = datetime.now().isoformat()
    entry = {"timestamp": timestamp, **data}
    try:
        with open(path, "r+") as f:
            logs = json.load(f)
            logs.append(entry)
            f.seek(0)
            json.dump(logs, f, indent=2)
    except FileNotFoundError:
        with open(path, "w") as f:
            json.dump([entry], f, indent=2)
import hashlib

def hash_file(file_path):
    sha = hashlib.sha256()
    with open(file_path, "rb") as f:
        while chunk := f.read(8192):
            sha.update(chunk)
    return sha.hexdigest()

def validate_model_hash(model_path, expected_hash):
    return hash_file(model_path) == expected_hash
from datetime import datetime
import pytz

def now_wita():
    tz = pytz.timezone("Asia/Makassar")
    return datetime.now(tz).strftime("%Y-%m-%d %H:%M:%S WITA")

def format_currency(val):
    return f"${val:,.2f}"
import streamlit as st
import pandas as pd
from utils import now_wita

def show_dashboard():
    st.set_page_config(page_title="MD90 Compound Dashboard", layout="wide")
    st.title("📊 MD90 Compound V7 – Ultimax Dashboard")
    st.write(f"🕒 Waktu Sekarang (WITA): {now_wita()}")

    logs = pd.read_json("logs/compound_logs.json")
    st.subheader("📈 Riwayat Compound")
    st.dataframe(logs.tail(20))

    if st.button("🔁 Refresh"):
        st.experimental_rerun()
import joblib
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier

def train_ensemble_model():
    df = pd.read_csv("data/compound_dataset.csv")
    X = df.drop("label", axis=1)
    y = df["label"]

    rf = RandomForestClassifier(n_estimators=200)
    xgb = XGBClassifier(eval_metric='mlogloss')

    rf.fit(X, y)
    xgb.fit(X, y)

    joblib.dump(rf, "model/rf_model.pkl")
    joblib.dump(xgb, "model/xgb_model.pkl")

def predict_ensemble(features):
    rf = joblib.load("model/rf_model.pkl")
    xgb = joblib.load("model/xgb_model.pkl")
    rf_pred = rf.predict_proba([features])[0][1]
    xgb_pred = xgb.predict_proba([features])[0][1]
    return (rf_pred + xgb_pred) / 2
import random

def mine_sentiment():
    # Placeholder untuk scraping Telegram/Reddit
    sentiments = ["bullish", "neutral", "bearish"]
    weights = [0.4, 0.3, 0.3]
    result = random.choices(sentiments, weights)[0]
    return result

def sentiment_score(sentiment):
    return {"bullish": 0.9, "neutral": 0.5, "bearish": 0.2}[sentiment]
import time
from ml_model import train_model
from utils import now_wita

def loop_retrain(interval_minutes=60):
    print(f"[{now_wita()}] Auto-Retrain Aktif Tiap {interval_minutes} Menit")
    while True:
        train_model()
        print(f"[{now_wita()}] Model retrained.")
        time.sleep(interval_minutes * 60)
def parse_chronyx(raw_data):
    return {
        "token": raw_data.get("token"),
        "buy_signal": "chronyx" in raw_data.get("source", ""),
        "volume": raw_data.get("volume", 0)
    }
def parse_crytoshix(data):
    return {
        "pump_alert": "pump" in data.get("text", "").lower(),
        "contract": data.get("ca", ""),
        "timestamp": data.get("time")
    }
def parse_crytoshix(data):
    return {
        "pump_alert": "pump" in data.get("text", "").lower(),
        "contract": data.get("ca", ""),
        "timestamp": data.get("time")
    }
def parse_listing(data):
    return {
        "token": data.get("symbol"),
        "platform": data.get("dex", "unknown"),
        "is_new": "listing" in data.get("type", "")
    }
def parse_pumpfun(data):
    return {
        "viral_score": int(data.get("score", 0)),
        "new_launch": data.get("is_new", False),
        "project": data.get("project_name")
    }
def parse_solradar(entry):
    return {
        "mint_detected": entry.get("mint", False),
        "suspicious_flag": "yes" if entry.get("flag") == "red" else "no"
    }
def parse_mevx(data):
    return {
        "pair": data.get("pair"),
        "listing_time": data.get("timestamp"),
        "is_new": data.get("status") == "new"
    }
def parse_birdeye(data):
    return {
        "token_distribution": data.get("distribution", {}),
        "lp_lock": data.get("lp_locked", False)
    }
def parse_rugcheck(data):
    return {
        "freeze_detected": data.get("freeze", False),
        "renounced": data.get("renounced", False),
        "verified": data.get("audit_score", 0) > 75
    }
def parse_tokensniffer(data):
    return {
        "honeypot": data.get("honeypot", False),
        "rug_risk": data.get("score", 0) < 30,
        "verdict": data.get("verdict", "Unknown")
    }
def parse_sniperhub(data):
    return {
        "dump_alert": data.get("dump", False),
        "wallet": data.get("wallet_address"),
        "volume": data.get("dump_volume", 0)
    }
def parse_pumpwhale(data):
    return {
        "wallet": data.get("wallet"),
        "hidden_activity": True if data.get("activity") == "whale_trigger" else False,
        "entry_time": data.get("timestamp")
    }
# Buat virtual environment (opsional tapi direkomendasikan)
python -m venv md90env
source md90env/bin/activate  # Windows: md90env\Scripts\activate

# Install semua dependency
pip install -r requirements.txt
# Start entry utama
python main.py
bash start.sh
streamlit run web_dashboard.py
http://localhost:8501
python ensemble_model.py --benchmark
python auto_retrain_loop.py
# === MD90_V7_UltimaxHybrid Core ===

from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
import pandas as pd
import joblib
import json

class CompoundV7Ensemble:
    def __init__(self, rf_model_path, gb_model_path, feed_snapshot_path):
        self.rf_model = joblib.load(rf_model_path)
        self.gb_model = joblib.load(gb_model_path)
        self.feed_snapshot_path = feed_snapshot_path

    def load_features(self):
        with open(self.feed_snapshot_path, 'r') as f:
            snapshot = json.load(f)
        return pd.DataFrame([snapshot])

    def predict_ensemble(self):
        X = self.load_features()
        rf_pred = self.rf_model.predict_proba(X)[0][1]
        gb_pred = self.gb_model.predict_proba(X)[0][1]
        final_score = (rf_pred + gb_pred) / 2
        return final_score

if __name__ == '__main__':
    engine = CompoundV7Ensemble(
        rf_model_path='model/rf_compound_model.pkl',
        gb_model_path='model/gb_compound_model.pkl',
        feed_snapshot_path='data/feed_snapshots.json'
    )
    score = engine.predict_ensemble()
    print("🧠 Final Confidence Score (V7 Ensemble):", round(score, 4))

#!/usr/bin/env python3
import os
import sys
import py_compile
from pathlib import Path
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')
logger = logging.getLogger(__name__)

def validate_all_files(base_dir: str = '/app') -> bool:
    logger.info("🔍 Starting Quantum Syntax Validation")
    base_path = Path(base_dir)
    errors = []
    files_checked = 0
    
    for py_file in base_path.rglob('*.py'):
        if any(part.startswith('_') or part.startswith('.') for part in py_file.parts):
            continue
        files_checked += 1
        try:
            py_compile.compile(str(py_file), doraise=True)
            logger.info(f"✅ {py_file.relative_to(base_path)}")
        except py_compile.PyCompileError as e:
            logger.error(f"❌ {py_file.relative_to(base_path)}: {e}")
            errors.append((str(py_file), str(e)))
    
    logger.info(f"\n📊 Files checked: {files_checked}, Errors: {len(errors)}")
    
    if errors:
        logger.error("❌ Validation FAILED")
        return False
    
    logger.info("✅ Validation PASSED")
    return True

if __name__ == '__main__':
    success = validate_all_files()
    sys.exit(0 if success else 1)

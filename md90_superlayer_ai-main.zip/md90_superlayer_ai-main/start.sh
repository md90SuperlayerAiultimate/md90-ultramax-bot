#!/usr/bin/env bash
set -e
echo "[start] Boot MD90 Ultimax — WITA time:"
python3 - <<'PY'
import datetime, pytz
print(datetime.datetime.now(pytz.timezone("Asia/Makassar")).strftime("%Y-%m-%d %H:%M:%S %Z"))
PY

echo "[start] Collectors up"
python3 scripts/collector_binance.py &
python3 scripts/collector_mexc.py &

echo "[start] Bots up (paper/live mengikuti config)"
python3 runners/run_all_bots.py &

echo "[start] Weekly reporter up"
python3 scripts/weekly_report.py &

echo "[start] Supervisor loop (auto-restart minimal)"
python3 runners/supervisor.py

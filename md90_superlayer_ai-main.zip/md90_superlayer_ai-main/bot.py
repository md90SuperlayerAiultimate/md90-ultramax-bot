#!/usr/bin/env python3
"""
MD90 ALLIN FUSION - Bot Utama (MeridianBot)
Mengintegrasikan semua modul: multi-market feed, copy trade,
fusion engine, soccer analyzer, ML tuning

Versi: Railway-Ready (Anti-Crash)
"""

import asyncio
import json
import os
import time
from datetime import datetime, timezone
from typing import Dict, Optional, List

from dotenv import load_dotenv

from utils.logger import setup_logger, log_event
from utils.multi_market_feed import MultiMarketFeed
from utils.indicators import Indicators
from utils.risk import RiskManager
from utils.fusion_engine import FusionEngine
from utils.kimi_soccer import KimiSoccerAnalyzer
from utils.copy_trade import CopyTradeLeaderboard
from utils.ml_tuning import MLTuning


class MeridianBot:
    """
    Bot utama dengan arsitektur Meridian:
    - Radar       : multi-market feed (CCXT/DexScreener)
    - Analisis    : fusion engine (17 layer) + copy trade consensus
    - Eksekusi    : risk management + trailing stop
    - Pembelajaran: ML tuning adaptif
    """

    def __init__(self, cfg: Dict):
        """
        Inisialisasi bot dengan penanganan konfigurasi yang aman.
        Tidak akan terjadi KeyError karena semua key diakses dengan .get().
        """
        # Fallback jika cfg None
        self.cfg = cfg if cfg is not None else {}

        # ------------------------------------------------------------------
        # 1. PARSING VARIABEL BOOLEAN (ANTI KEYERROR)
        # ------------------------------------------------------------------
        self.live_mode = str(self.cfg.get('live_mode', 'false')).lower() == 'true'
        self.dry_run   = str(self.cfg.get('dry_run', 'true')).lower() == 'true'

        # Safety: jika live_mode true tapi dry_run juga true, paksa dry_run
        if self.live_mode and self.dry_run:
            print("⚠️  Warning: live_mode=true dan dry_run=true, memaksa dry_run.")
            self.live_mode = False

        # ------------------------------------------------------------------
        # 2. SETUP LOGGER (BUAT DIREKTORI JIKA BELUM ADA)
        # ------------------------------------------------------------------
        log_path = self.cfg.get("log_file", "logs/md90_trades.jsonl")
        log_dir = os.path.dirname(log_path)
        if log_dir and not os.path.exists(log_dir):
            os.makedirs(log_dir, exist_ok=True)
        self.logger = setup_logger(log_path)

        # ------------------------------------------------------------------
        # 3. TENTUKAN PAIR UTAMA (KOMPATIBILITAS)
        # ------------------------------------------------------------------
        if 'pairs' in self.cfg and self.cfg['pairs']:
            self.current_pair = self.cfg['pairs'][0]
        else:
            self.current_pair = self.cfg.get('pair', 'BTCUSDT')

        # ------------------------------------------------------------------
        # 4. INISIALISASI KOMPONEN DENGAN PARAMETER DEFAULT AMAN
        # ------------------------------------------------------------------
        # MultiMarketFeed (selalu dibuat, mungkin mode dry-run)
        self.feed = MultiMarketFeed(self.cfg)

        # Risk Manager
        self.risk = RiskManager(
            max_consecutive_losses=self.cfg.get("max_consecutive_losses", 3),
            min_confidence=self.cfg.get("min_confidence", 75),
            max_liquidity_risk=self.cfg.get("max_liquidity_risk", 20)
        )

        # Fusion Engine
        self.fusion = None
        if self.cfg.get("fusion_enabled", True):
            self.fusion = FusionEngine(self.cfg)

        # Soccer Analyzer (default off)
        self.soccer = None
        if self.cfg.get("soccer_enabled", False):
            self.soccer = KimiSoccerAnalyzer(self.cfg)

        # Copy Trade Leaderboard (default on)
        self.copy_trade = None
        if self.cfg.get("copy_trade_enabled", True):
            self.copy_trade = CopyTradeLeaderboard(self.cfg)

        # ML Tuning
        ml_config_path = self.cfg.get("ml_config_file", "md90_ml_config.json")
        self.ml = MLTuning(ml_config_path)

        # ------------------------------------------------------------------
        # 5. STATE BOT
        # ------------------------------------------------------------------
        self.position            = None
        self.equity              = float(self.cfg.get("start_equity", 2000.0))
        self.realized_pnl        = 0.0
        self.consecutive_losses  = 0
        self.total_trades        = 0
        self.running             = True

        # ------------------------------------------------------------------
        # 6. TERAPKAN PARAMETER ML
        # ------------------------------------------------------------------
        self.params = self.ml.load_params()
        self._apply_ml_params()

        # ------------------------------------------------------------------
        # 7. LOG STATUS INISIALISASI
        # ------------------------------------------------------------------
        print(f"✅ MeridianBot Initialized")
        print(f"   Live Mode     : {'ON' if self.live_mode else 'OFF'}")
        print(f"   Dry Run       : {'ON' if self.dry_run else 'OFF'}")
        print(f"   Main Pair     : {self.current_pair}")
        print(f"   Fusion Engine : {'ON' if self.fusion else 'OFF'}")
        print(f"   Copy Trade    : {'ON' if self.copy_trade else 'OFF'}")
        print(f"   Soccer        : {'ON' if self.soccer else 'OFF'}")

    # ------------------------------------------------------------------
    def _apply_ml_params(self):
        """Terapkan parameter hasil ML tuning ke bot"""
        self.risk.min_confidence = self.params.get("min_confidence", self.risk.min_confidence)
        self.cfg["risk_per_trade"] = self.params.get("risk_per_trade", self.cfg.get("risk_per_trade", 0.01))
        self.cfg["atr_sl_mult"]    = self.params.get("atr_sl_mult",    self.cfg.get("atr_sl_mult",    1.2))
        self.cfg["atr_tp_mult"]    = self.params.get("atr_tp_mult",    self.cfg.get("atr_tp_mult",    1.6))
        self.cfg["rsi_buy_scalp"]  = self.params.get("rsi_buy_scalp",  self.cfg.get("rsi_buy_scalp",  38))
        self.cfg["rsi_sell_scalp"] = self.params.get("rsi_sell_scalp", self.cfg.get("rsi_sell_scalp", 62))

    # ------------------------------------------------------------------
    async def analyze_market(self, symbol: str, ohlcv: List) -> Optional[Dict]:
        """Analisis multi-layer: indikator + fusion engine + copy trade sinyal"""
        if not ohlcv or len(ohlcv) < 50:
            return None

        closes = [c[4] for c in ohlcv]
        highs  = [c[2] for c in ohlcv]
        lows   = [c[3] for c in ohlcv]

        # Indikator
        ind   = Indicators(rsi_len=self.cfg.get("rsi_len", 14), atr_len=self.cfg.get("atr_len", 14))
        rsi   = ind.rsi(closes[-1], closes)
        atr_v = ind.atr(highs[-1], lows[-1], closes[-1], highs, lows, closes)
        price = closes[-1]

        if atr_v is None or atr_v <= 0:
            atr_v = price * 0.005  # fallback 0.5%

        # Copy trade consensus
        copy_signal = None
        if self.copy_trade:
            copy_signal = await self.copy_trade.get_consensus_signal(symbol)

        # Fusion engine
        fusion_result = None
        if self.fusion:
            market_data = {
                "current_price":  price,
                "rsi":            rsi if rsi is not None else 50.0,
                "atr":            atr_v,
                "atr_avg":        atr_v,
                "ema20":          price,       # placeholder — bisa dihitung dari closes
                "volume_spike":   False,
                "whale_delta":    0,
                "btc_macro_bull": self.feed.btc_macro_bull,
                "liquidity_sweep": False,
                "trend_5m":       0,
                "trend_1h":       0,
            }
            fusion_result = self.fusion.analyze(market_data)

        # Gabungkan: copy trade prioritas jika confidence tinggi
        final_signal = None
        if copy_signal and copy_signal.get("confidence", 0) > 80:
            side = copy_signal["side"]
            final_signal = {
                "side":           side,
                "confidence":     copy_signal["confidence"],
                "price":          price,
                "sl":             price * (1 - self.cfg["atr_sl_mult"] * atr_v / price) if side == "long"
                                  else price * (1 + self.cfg["atr_sl_mult"] * atr_v / price),
                "tp":             price * (1 + self.cfg["atr_tp_mult"] * atr_v / price) if side == "long"
                                  else price * (1 - self.cfg["atr_tp_mult"] * atr_v / price),
                "fusion_status":  "COPY_TRADE",
            }
        elif fusion_result and fusion_result["status"] != "🛑 ABORT":
            side = fusion_result["direction"].lower()
            if side not in ("buy", "sell"):
                return None
            is_long = (side == "buy")
            final_signal = {
                "side":          "long" if is_long else "short",
                "confidence":    fusion_result["confidence"],
                "price":         price,
                "sl":            price * (1 - self.cfg["atr_sl_mult"] * atr_v / price) if is_long
                                 else price * (1 + self.cfg["atr_sl_mult"] * atr_v / price),
                "tp":            price * (1 + self.cfg["atr_tp_mult"] * atr_v / price) if is_long
                                 else price * (1 - self.cfg["atr_tp_mult"] * atr_v / price),
                "fusion_status": fusion_result["status"],
            }
        else:
            return None

        return final_signal

    # ------------------------------------------------------------------
    async def execute_signal(self, signal: Dict, symbol: str):
        """Eksekusi sinyal — paper atau live"""
        risk_amount  = self.equity * self.cfg["risk_per_trade"]
        price        = signal["price"]
        sl           = signal["sl"]
        risk_per_unit = abs(price - sl)
        if risk_per_unit <= 0:
            risk_per_unit = price * 0.01
        size = risk_amount / risk_per_unit
        # Batasi maks 50% equity
        max_size = (self.equity * 0.5) / price
        size = min(size, max_size)

        # GANTI: gunakan self.dry_run dan self.live_mode
        if self.dry_run or not self.live_mode:
            self.position = {
                "side":      signal["side"],
                "entry":     price,
                "size":      size,
                "sl":        sl,
                "tp":        signal["tp"],
                "open_time": datetime.now(timezone.utc).isoformat(),
            }
            self.total_trades += 1
            log_event(self.logger, "OPEN_PAPER", {
                "symbol":     symbol,
                "side":       signal["side"],
                "price":      price,
                "size":       size,
                "sl":         sl,
                "tp":         signal["tp"],
                "confidence": signal["confidence"],
            })
            print(f"📈 PAPER OPEN {signal['side'].upper()} {symbol} @ {price:.4f} "
                  f"size={size:.4f} conf={signal['confidence']:.1f}%")
        else:
            success = await self.feed.place_order(symbol, signal["side"], size, price, sl, signal["tp"])
            if success:
                log_event(self.logger, "OPEN_LIVE", {"symbol": symbol, "side": signal["side"], "price": price})
                print(f"💹 LIVE OPEN {signal['side'].upper()} {symbol} @ {price:.4f}")
            else:
                print(f"❌ LIVE ORDER FAILED {symbol}")
                return

        self.equity -= size * price * self.cfg["risk_per_trade"]  # simplified equity debit

    # ------------------------------------------------------------------
    async def manage_positions(self, current_price: float, symbol: str):
        """Kelola posisi terbuka: SL/TP check + trailing stop"""
        if not self.position:
            return

        side  = self.position["side"]
        entry = self.position["entry"]
        sl    = self.position["sl"]
        tp    = self.position["tp"]
        size  = self.position["size"]

        closed = False
        pnl    = 0.0
        reason = ""

        if side == "long":
            if current_price >= tp:
                pnl    = (tp - entry) * size
                closed = True
                reason = "TP"
            elif current_price <= sl:
                pnl    = (sl - entry) * size
                closed = True
                reason = "SL"
        else:  # short
            if current_price <= tp:
                pnl    = (entry - tp) * size
                closed = True
                reason = "TP"
            elif current_price >= sl:
                pnl    = (entry - sl) * size
                closed = True
                reason = "SL"

        if closed:
            self.realized_pnl += pnl
            self.equity       += pnl
            if pnl < 0:
                self.consecutive_losses += 1
                self.risk.record_loss()
            else:
                self.consecutive_losses = 0
            log_event(self.logger, "CLOSE", {
                "symbol":  symbol,
                "side":    side,
                "reason":  reason,
                "entry":   entry,
                "exit":    current_price,
                "pnl":     pnl,
                "equity":  self.equity,
            })
            print(f"🔒 CLOSE {side.upper()} {reason} @ {current_price:.4f} "
                  f"PnL={pnl:.2f} Equity={self.equity:.2f}")
            self.position = None
            # ML tuning setiap 20 trade
            if self.total_trades > 0 and self.total_trades % 20 == 0:
                win_rate = max(0.0, self.realized_pnl / (self.total_trades * 10))
                self.ml.update_and_save(self.total_trades, min(1.0, win_rate))
                self._apply_ml_params()
        else:
            # Trailing stop
            trail_factor = self.cfg.get("trail_mult", 1.0) * (current_price * 0.01)
            if side == "long":
                new_sl = max(sl, current_price - trail_factor)
                if new_sl > sl:
                    self.position["sl"] = new_sl
                    print(f"🔝 Trail SL → {new_sl:.4f}")
            else:
                new_sl = min(sl, current_price + trail_factor)
                if new_sl < sl:
                    self.position["sl"] = new_sl
                    print(f"🔝 Trail SL → {new_sl:.4f}")

    # ------------------------------------------------------------------
    async def run(self):
        """Main loop bot"""
        print(f"🚀 MD90 ALLIN FUSION — MERIDIAN BOT STARTED")
        # GANTI: gunakan atribut, bukan self.cfg['live_mode']
        print(f"   Mode      : {'LIVE' if self.live_mode and not self.dry_run else 'PAPER/DRY'}")
        print(f"   Pair      : {self.current_pair} | TF: {self.cfg.get('timeframe', '5m')}")
        print(f"   Risk/trade: {self.cfg.get('risk_per_trade', 0.01)*100:.1f}%")
        print(f"   Fusion    : {'ON' if self.fusion else 'OFF'}")
        print(f"   CopyTrade : {'ON' if self.copy_trade else 'OFF'}")
        print(f"   Soccer    : {'ON' if self.soccer else 'OFF'}")
        print(f"   ML Tuning : {'ON' if self.ml else 'OFF'}")

        # Jika ada data soccer, analisis sekali lalu lanjut
        if self.soccer and self.cfg.get("soccer_match_data"):
            result = self.soccer.analyze_match(self.cfg["soccer_match_data"])
            self.soccer.print_report(result)
            if not self.cfg.get("soccer_only", False):
                print("⚽ Soccer analysis done. Continuing crypto trading...\n")

        while self.running:
            try:
                data = await self.feed.get_ohlcv(self.current_pair, self.cfg.get("timeframe", "5m"), limit=100)
                if not data:
                    await asyncio.sleep(self.cfg.get("loop_seconds", 60))
                    continue

                signal        = await self.analyze_market(self.current_pair, data)
                current_price = data[-1][4]  # close

                await self.manage_positions(current_price, self.current_pair)

                if signal and not self.position:
                    if signal["confidence"] >= self.risk.min_confidence:
                        await self.execute_signal(signal, self.current_pair)
                    else:
                        print(f"⏸️  Signal conf {signal['confidence']:.1f}% < threshold {self.risk.min_confidence:.0f}%")

                if self.risk.kill_switch_triggered:
                    print("🛑 KILL SWITCH ACTIVATED. Bot shutdown.")
                    break

                await asyncio.sleep(self.cfg.get("loop_seconds", 60))

            except KeyboardInterrupt:
                print("🛑 Bot stopped by user.")
                break
            except Exception as e:
                print(f"❌ Main loop error: {e}")
                await asyncio.sleep(5)

        # Force close posisi jika masih ada
        if self.position:
            current_price = await self.feed.get_current_price(self.current_pair)
            await self.manage_positions(current_price, self.current_pair)

        print(f"🏁 Bot terminated. Trades: {self.total_trades} | "
              f"Equity: {self.equity:.2f} | PnL: {self.realized_pnl:.2f}")
        log_event(self.logger, "SHUTDOWN", {
            "equity": self.equity,
            "trades": self.total_trades,
            "pnl":    self.realized_pnl,
        })


# =============================================================================
# ENTRY POINT (DENGAN KONFIGURASI LENGKAP DARI ENVIRONMENT)
# =============================================================================
if __name__ == "__main__":
    # 1. Load Environment
    load_dotenv()

    # 2. Build Multi-Pair Configuration
    raw_pairs = os.getenv("PAIRS", "BTCUSDT")
    pair_list = [p.strip() for p in raw_pairs.split(",") if p.strip()]

    # Pastikan setidaknya ada satu pair
    if not pair_list:
        pair_list = ["BTCUSDT"]

    config = {
        # Daftar pair (untuk MultiMarketFeed)
        "pairs": pair_list,
        # Pair utama untuk kompatibilitas (gunakan pair pertama)
        "pair": pair_list[0],

        # API Keys (bisa kosong untuk dry-run)
        "binance_key": os.getenv("BINANCE_API_KEY"),
        "binance_secret": os.getenv("BINANCE_SECRET_KEY"),
        "telegram_token": os.getenv("TELEGRAM_BOT_TOKEN"),

        # Mode operasi
        "dry_run": os.getenv("DRY_RUN", "true").lower() == "true",
        "live_mode": os.getenv("LIVE_MODE", "false").lower() == "true",

        # Parameter trading
        "start_equity": float(os.getenv("START_EQUITY", 5000.0)),
        "risk_per_trade": float(os.getenv("RISK_PER_TRADE", 0.01)),
        "max_consecutive_losses": int(os.getenv("MAX_CONSECUTIVE_LOSSES", 3)),
        "min_confidence": float(os.getenv("MIN_CONFIDENCE", 75.0)),
        "max_liquidity_risk": int(os.getenv("MAX_LIQUIDITY_RISK", 20)),

        # Timeframe dan loop
        "timeframe": os.getenv("TIMEFRAME", "5m"),
        "loop_seconds": int(os.getenv("LOOP_SECONDS", 60)),

        # Feature flags
        "fusion_enabled": os.getenv("FUSION_ENABLED", "true").lower() == "true",
        "copy_trade_enabled": os.getenv("COPY_TRADE_ENABLED", "true").lower() == "true",
        "soccer_enabled": os.getenv("SOCCER_ENABLED", "false").lower() == "false",

        # Parameter indikator (bisa di-override oleh ML)
        "atr_sl_mult": float(os.getenv("ATR_SL_MULT", 1.2)),
        "atr_tp_mult": float(os.getenv("ATR_TP_MULT", 1.6)),
        "rsi_len": int(os.getenv("RSI_LEN", 14)),
        "atr_len": int(os.getenv("ATR_LEN", 14)),
        "rsi_buy_scalp": float(os.getenv("RSI_BUY_SCALP", 38.0)),
        "rsi_sell_scalp": float(os.getenv("RSI_SELL_SCALP", 62.0)),
        "trail_mult": float(os.getenv("TRAIL_MULT", 1.0)),

        # Logging
        "log_file": os.getenv("LOG_FILE", "logs/md90_trades.jsonl"),

        # ML config file
        "ml_config_file": os.getenv("ML_CONFIG_FILE", "md90_ml_config.json"),
    }

    # 3. Tampilkan banner
    print("=" * 60)
    print("🚀 MD90 MERIDIAN ENGINE STARTING...")
    print(f"📈 Monitoring Pairs: {pair_list}")
    print(f"📁 Log file: {config['log_file']}")
    print("=" * 60)

    # 4. Inisialisasi dan jalankan bot
    bot = MeridianBot(config)
    try:
        asyncio.run(bot.run())
    except KeyboardInterrupt:
        print("\n🛑 Shutdown requested by user.")
    except Exception as e:
        print(f"❌ CRITICAL SYSTEM FAILURE: {e}")
        import traceback
        traceback.print_exc()
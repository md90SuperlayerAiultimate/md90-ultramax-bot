@echo off
cd /d "C:\Users\Asus\Desktop\md90-Superlayer\md90 ultramax bot"

REM === aktifkan venv kalau ada ===
IF EXIST md90env\Scripts\activate call md90env\Scripts\activate

REM === install dependensi (sekali; nanti cepat) ===
pip install --upgrade pip
pip install -r requirements.txt

REM === jalankan kontrol & dashboard (window terpisah) ===
start "" cmd /c python start_all_control.py
start "" cmd /c python telegram_dashboard.py

echo.
echo ✅ Semua bot dan Telegram dashboard dijalankan. Buka Telegram, kirim: /status
pause

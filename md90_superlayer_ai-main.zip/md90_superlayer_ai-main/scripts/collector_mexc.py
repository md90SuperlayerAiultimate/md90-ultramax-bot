import os, json, time, requests, datetime, pytz
from config import MEXC_BASE, PAIRS, RAW_DIR, TIMEZONE
os.makedirs(RAW_DIR, exist_ok=True)
tz = pytz.timezone(TIMEZONE)

def fetch_ticker(symbol):
    r = requests.get(f"{MEXC_BASE}/api/v3/ticker/24hr", params={"symbol":symbol}, timeout=15)
    r.raise_for_status(); return r.json()

def save_jsonl(symbol, item):
    day = datetime.datetime.now(tz).strftime("%Y%m%d")
    path = os.path.join(RAW_DIR, f"MEXC_{symbol}_{day}.jsonl")
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(item)+"\n")

def main():
    while True:
        for sym in PAIRS:
            try:
                item = fetch_ticker(sym)
                save_jsonl(sym, item)
                print("[mexc]", sym, "OK")
            except Exception as e:
                print("[mexc][ERR]", sym, e)
        time.sleep(60)

if __name__ == "__main__":
    main()

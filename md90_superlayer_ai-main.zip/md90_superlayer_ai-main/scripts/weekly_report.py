import os, json, glob, datetime, pytz, pandas as pd
from config import LOG_DIR, RPT_DIR, TIMEZONE
os.makedirs(RPT_DIR, exist_ok=True)
tz = pytz.timezone(TIMEZONE)

def load_jsonl():
    rows = []
    for fp in glob.glob(os.path.join(LOG_DIR, "trade_*.jsonl")):
        with open(fp, "r", encoding="utf-8") as f:
            rows += [json.loads(x) for x in f if x.strip()]
    return rows

def main_loop():
    while True:
        rows = load_jsonl()
        df = pd.DataFrame(rows)
        week = datetime.datetime.now(tz).strftime("%G-W%V")
        out = os.path.join(RPT_DIR, f"weekly_{week}.xlsx")
        with pd.ExcelWriter(out) as xw:
            if not df.empty:
                df.to_excel(xw, index=False, sheet_name="trades")
                # summary minimal
                win = (df.get("outcome")=="TP").sum() if "outcome" in df.columns else 0
                total = len(df)
                winrate = round((win/total*100),2) if total>0 else 0.0
                pd.DataFrame([{"trades": total, "winrate_%": winrate}]).to_excel(xw, index=False, sheet_name="summary")
        print("[report] saved", out)
        import time; time.sleep(21600)

if __name__ == "__main__":
    main_loop()

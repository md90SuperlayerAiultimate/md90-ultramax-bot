import os, json, time, requests, datetime, pytz
from config import BINANCE_BASE, PAIRS, INTERVAL, RAW_DIR, TIMEZONE
os.makedirs(RAW_DIR, exist_ok=True)
tz = pytz.timezone(TIMEZONE)

def fetch_klines(symbol, interval, limit=120):
    r = requests.get(f"{BINANCE_BASE}/api/v3/klines", params={"symbol":symbol,"interval":interval,"limit":limit}, timeout=15)
    r.raise_for_status(); return r.json()

def save_jsonl(symbol, rows):
    day = datetime.datetime.now(tz).strftime("%Y%m%d")
    path = os.path.join(RAW_DIR, f"{symbol}_{INTERVAL}_{day}.jsonl")
    with open(path, "a", encoding="utf-8") as f:
        for r in rows[-5:]:
            item = {"t": r[0], "o": float(r[1]), "h": float(r[2]), "l": float(r[3]), "c": float(r[4]), "v": float(r[5])}
            f.write(json.dumps(item)+"\n")

def main():
    while True:
        for sym in PAIRS:
            try:
                rows = fetch_klines(sym, INTERVAL, 60)
                save_jsonl(sym, rows)
                print("[binance]", sym, "OK")
            except Exception as e:
                print("[binance][ERR]", sym, e)
        time.sleep(60)

if __name__ == "__main__":
    main()

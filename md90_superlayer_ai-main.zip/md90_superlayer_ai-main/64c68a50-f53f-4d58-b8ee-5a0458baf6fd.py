# === [1] main.py ===

import time
import threading
from scalping_engine import run_scalping
from sniper_supreme import run_sniper
from telegram_bot import start_bot
from watcher import auto_retrain_loop
from feed_listener import update_feed_signals
from sentiment_scraper import update_sentiment_data
from auto_sync_price import run_price_listener
from config import (
    USE_SCALPING, USE_SNIPER, USE_AUTO_RETRAIN, USE_STREAM_DASHBOARD
)

def start_all():
    print("\U0001F680 MD90 Supreme Scalping Bot V30 dimulai...")

    if USE_SCALPING:
        threading.Thread(target=run_scalping).start()
        print("✅ Scalping Engine aktif")

    if USE_SNIPER:
        threading.Thread(target=run_sniper).start()
        print("✅ Sniper Supreme aktif")

    if USE_AUTO_RETRAIN:
        threading.Thread(target=auto_retrain_loop).start()
        print("🔁 Auto Retrain aktif")

    threading.Thread(target=start_bot).start()
    print("🤖 Telegram Bot aktif")

    threading.Thread(target=update_feed_signals).start()
    threading.Thread(target=update_sentiment_data).start()
    threading.Thread(target=run_price_listener).start()

    if USE_STREAM_DASHBOARD:
        import dashboard_ui
        threading.Thread(target=dashboard_ui.run).start()
        print("📊 Dashboard Stream aktif")

    while True:
        time.sleep(60)

if __name__ == "__main__":

    start_all()
BINANCE_API_KEY = "GrAJLUZnu8yOvgilw6aw5uJ2RzWjAn5tpCTPInAK31RI84iQAZrUjK6QJDgZm4W"
BINANCE_SECRET_KEY = "fx1OO0mejdeYcUwpZ23Q5r4doNmlGnrQHNKAeIRCEG358koRz"
BOT_TOKEN = "8035261208:AAEcKMgB1D68ObU62VutkIASPCIp9JHHwt8"
OWNER_ID = 1023226304

# Pair & Entry config
ACTIVE_PAIRS = ["BTCUSDT", "ETHUSDT", "ACEUSDT"]
CONFIDENCE_THRESHOLD = 0.85
DEFAULT_SL = 0.015
DEFAULT_TP = 0.035
RRR = [1.5, 3.0]

# Webhook & Feed
DEX_SCREENER_WS = "wss://ws.dexscreener.com/realtime"
PUMPFUN_API = "https://api.pump.fun/api/trending"
MEMECASTLE_FEED = "https://t.me/memecoincastle"
TIMEZONE = "Asia/Makassar"

# Fitur aktif
USE_SCALPING = True
USE_SNIPER = True
USE_COMPOUND = True
USE_RISK_GUARDIAN = True
USE_EMOTION_FILTER = True
USE_AUTO_RETRAIN = True
USE_TRAILING_TP = True
USE_STREAM_DASHBOARD = True
USE_XGBOOST = True
USE_RF = True
USE_LSTM = True
RETRAIN_INTERVAL_HOURS = 4


# File [3/30] akan dilanjutkan otomatis...
# === ai_model.py ===

import numpy as np
from sklearn.ensemble import RandomForestClassifier
import joblib

class AIModel:
    def __init__(self):
        self.model = RandomForestClassifier()
        self.load_model()

    def load_model(self):
        try:
            self.model = joblib.load("model/ai_scalping_model.pkl")
        except:
            X = np.array([[0.1, 0.2, 0.3], [0.5, 0.6, 0.1], [0.9, 0.1, 0.8]])
            y = [1, 0, 1]
            self.model.fit(X, y)
            joblib.dump(self.model, "model/ai_scalping_model.pkl")

    def predict(self, x):
        prob = self.model.predict_proba([x])[0]
        return ("BUY" if prob[1] > 0.5 else "SELL"), max(prob)
# === scalping_engine.py ===

from ai_model import AIModel
from logic_scoring_v4 import score_signal
from risk_allocator import allocate_risk
from x12_executor import place_order
from guardian import filter_signal
import time, json

def run_scalping():
    model = AIModel()
    print("🔁 Scalping engine running...")
    while True:
        try:
            with open("signals/live_entry.json", "r") as f:
                signal_data = json.load(f)

            for pair, features in signal_data.items():
                decision, conf = model.predict(features)
                final_signal, adjusted_conf, approved = filter_signal(decision, conf)
                if approved:
                    risk = allocate_risk(adjusted_conf)
                    place_order(final_signal.lower(), risk, features[0])
        except Exception as e:
            print(f"❌ Scalping Error: {e}")
        time.sleep(30)
# === sniper_supreme.py ===

from ai_model import AIModel
from x12_executor import place_order
from config import ACTIVE_PAIRS
import time

def run_sniper():
    model = AIModel()
    print("🔫 Sniper Supreme running...")
    while True:
        for pair in ACTIVE_PAIRS:
            price = get_price(pair)
            signal, conf = model.predict([price, price * 0.99, price * 1.01])
            if conf >= 0.94:
                qty = calculate_allin_size(price)
                place_order("long" if signal == "BUY" else "short", qty, price)
        time.sleep(20)

def get_price(pair):
    # Placeholder for price fetch logic
    return 1.0
# === telegram_bot.py ===

from telegram import Bot, Update
from telegram.ext import Updater, CommandHandler
from config import BOT_TOKEN, OWNER_ID

bot = Bot(token=BOT_TOKEN)

def start(update: Update, context):
    if update.effective_user.id == OWNER_ID:
        context.bot.send_message(chat_id=OWNER_ID, text="🤖 Scalping Bot Aktif!")

def start_bot():
    updater = Updater(token=BOT_TOKEN, use_context=True)
    dp = updater.dispatcher
    dp.add_handler(CommandHandler("start", start))
    updater.start_polling()
# === watcher.py ===

import time, json
from ai_model import AIModel
import numpy as np

def auto_retrain_loop():
    model = AIModel()
    while True:
        try:
            with open("data/retrain_set.json", "r") as f:
                retrain_data = json.load(f)
            X = np.array([d["features"] for d in retrain_data])
            y = np.array([d["label"] for d in retrain_data])
            model.model.fit(X, y)
            print("✅ Retrain sukses")
        except Exception as e:
            print(f"❌ Retrain error: {e}")
        time.sleep(14400)  # 4 jam
# === guardian.py ===

from config import CONFIDENCE_THRESHOLD

def filter_signal(signal, confidence):
    if confidence < 0.5:
        return "HOLD", confidence, False
    approved = confidence >= CONFIDENCE_THRESHOLD
    return signal if approved else "HOLD", confidence, approved
# === feed_listener.py ===

import json, time
import random

def update_feed_signals():
    print("📡 Feed Listener aktif...")
    while True:
        signals = {
            "BTCUSDT": [random.uniform(0.5, 1.0), 0.1, 0.3],
            "ETHUSDT": [random.uniform(0.4, 0.9), 0.2, 0.2]
        }
        with open("signals/live_entry.json", "w") as f:
            json.dump(signals, f)
        time.sleep(60)
# === sentiment_scraper.py ===

import random, time

def update_sentiment_data():
    print("💬 Scraper Sentimen aktif...")
    while True:
        sentiment_score = random.uniform(0, 1)
        with open("data/sentiment.json", "w") as f:
            f.write(str(sentiment_score))
        time.sleep(90)
# === auto_sync_price.py ===

import time, json

def run_price_listener():
    print("🔄 Sync Harga aktif...")
    while True:
        price_data = {
            "BTCUSDT": 27000 + 500 * time.time() % 1,
            "ETHUSDT": 1800 + 100 * time.time() % 1
        }
        with open("data/price_snapshot.json", "w") as f:
            json.dump(price_data, f)
        time.sleep(45)
# === dashboard_ui.py ===

from flask import Flask, jsonify
import json

app = Flask(__name__)

@app.route("/")
def home():
    with open("signals/live_entry.json") as f:
        signals = json.load(f)
    return jsonify(signals)

def run():
    print("📊 Dashboard UI aktif di http://localhost:5000")
    app.run(port=5000)
# === logic_scoring_v4.py ===

def score_signal(features):
    x = sum(features)
    confidence = round((x % 1) * 1.2, 3)
    return confidence
# === risk_allocator.py ===

def allocate_risk(confidence, balance=100):
    if confidence >= 0.9:
        return balance * 0.5
    elif confidence >= 0.8:
        return balance * 0.3
    elif confidence >= 0.7:
        return balance * 0.15
    else:
        return balance * 0.05
# === mikhacuan.py ===

from config import CONFIDENCE_THRESHOLD

def run_mikhacuan_filter(signal, conf, volatility=0.01, sentiment=0.7):
    adjusted = conf
    if sentiment < 0.3:
        adjusted -= 0.1
    elif sentiment > 0.8:
        adjusted += 0.05
    if volatility > 0.03:
        adjusted -= 0.05
    approved = adjusted >= CONFIDENCE_THRESHOLD
    return signal if approved else "HOLD", round(adjusted, 4), approved
# === x12_executor.py ===

from binance.client import Client
from binance.enums import *
from config import *
from telegram import Bot

client = Client(BINANCE_API_KEY, BINANCE_SECRET_KEY)
bot = Bot(token=BOT_TOKEN)

def send_telegram_msg(msg):
    bot.send_message(chat_id=OWNER_ID, text=msg)

def calculate_sl_tp(entry, direction):
    sl = entry * (1 - DEFAULT_SL) if direction == "long" else entry * (1 + DEFAULT_SL)
    tp = entry * (1 + DEFAULT_TP) if direction == "long" else entry * (1 - DEFAULT_TP)
    return round(sl, 2), round(tp, 2)

def calculate_allin_size(entry):
    balance = float(client.futures_account_balance()[0]['balance'])
    usdt = balance * 20
    return round(usdt / entry, 3)

def place_order(direction, qty, entry):
    side = SIDE_BUY if direction == "long" else SIDE_SELL
    sl, tp = calculate_sl_tp(entry, direction)
    try:
        order = client.futures_create_order(
            symbol=TRADING_PAIR,
            side=side,
            type=ORDER_TYPE_MARKET,
            quantity=qty,
            reduceOnly=False
        )
        client.futures_create_order(
            symbol=TRADING_PAIR,
            side=SIDE_SELL if side == SIDE_BUY else SIDE_BUY,
            type=ORDER_TYPE_STOP_MARKET,
            stopPrice=str(sl),
            quantity=qty,
            reduceOnly=True
        )
        client.futures_create_order(
            symbol=TRADING_PAIR,
            side=SIDE_SELL if side == SIDE_BUY else SIDE_BUY,
            type=ORDER_TYPE_LIMIT,
            price=str(tp),
            timeInForce=TIME_IN_FORCE_GTC,
            quantity=qty,
            reduceOnly=True
        )
        send_telegram_msg(f"✅ Order {direction.upper()} | Qty: {qty} | SL: {sl} | TP: {tp}")
    except Exception as e:
        send_telegram_msg(f"❌ Gagal Eksekusi: {e}")
# === x12_executor.py ===

from binance.client import Client
from binance.enums import *
from config import *
from telegram import Bot

client = Client(BINANCE_API_KEY, BINANCE_SECRET_KEY)
bot = Bot(token=BOT_TOKEN)

def send_telegram_msg(msg):
    bot.send_message(chat_id=OWNER_ID, text=msg)

def calculate_sl_tp(entry, direction):
    sl = entry * (1 - DEFAULT_SL) if direction == "long" else entry * (1 + DEFAULT_SL)
    tp = entry * (1 + DEFAULT_TP) if direction == "long" else entry * (1 - DEFAULT_TP)
    return round(sl, 2), round(tp, 2)

def calculate_allin_size(entry):
    balance = float(client.futures_account_balance()[0]['balance'])
    usdt = balance * 20
    return round(usdt / entry, 3)

def place_order(direction, qty, entry):
    side = SIDE_BUY if direction == "long" else SIDE_SELL
    sl, tp = calculate_sl_tp(entry, direction)
    try:
        order = client.futures_create_order(
            symbol=TRADING_PAIR,
            side=side,
            type=ORDER_TYPE_MARKET,
            quantity=qty,
            reduceOnly=False
        )
        client.futures_create_order(
            symbol=TRADING_PAIR,
            side=SIDE_SELL if side == SIDE_BUY else SIDE_BUY,
            type=ORDER_TYPE_STOP_MARKET,
            stopPrice=str(sl),
            quantity=qty,
            reduceOnly=True
        )
        client.futures_create_order(
            symbol=TRADING_PAIR,
            side=SIDE_SELL if side == SIDE_BUY else SIDE_BUY,
            type=ORDER_TYPE_LIMIT,
            price=str(tp),
            timeInForce=TIME_IN_FORCE_GTC,
            quantity=qty,
            reduceOnly=True
        )
        send_telegram_msg(f"✅ Order {direction.upper()} | Qty: {qty} | SL: {sl} | TP: {tp}")
    except Exception as e:
        send_telegram_msg(f"❌ Gagal Eksekusi: {e}")
# === x12_executor.py ===

from binance.client import Client
from binance.enums import *
from config import *
from telegram import Bot

client = Client(BINANCE_API_KEY, BINANCE_SECRET_KEY)
bot = Bot(token=BOT_TOKEN)

def send_telegram_msg(msg):
    bot.send_message(chat_id=OWNER_ID, text=msg)

def calculate_sl_tp(entry, direction):
    sl = entry * (1 - DEFAULT_SL) if direction == "long" else entry * (1 + DEFAULT_SL)
    tp = entry * (1 + DEFAULT_TP) if direction == "long" else entry * (1 - DEFAULT_TP)
    return round(sl, 2), round(tp, 2)

def calculate_allin_size(entry):
    balance = float(client.futures_account_balance()[0]['balance'])
    usdt = balance * 20
    return round(usdt / entry, 3)

def place_order(direction, qty, entry):
    side = SIDE_BUY if direction == "long" else SIDE_SELL
    sl, tp = calculate_sl_tp(entry, direction)
    try:
        order = client.futures_create_order(
            symbol=TRADING_PAIR,
            side=side,
            type=ORDER_TYPE_MARKET,
            quantity=qty,
            reduceOnly=False
        )
        client.futures_create_order(
            symbol=TRADING_PAIR,
            side=SIDE_SELL if side == SIDE_BUY else SIDE_BUY,
            type=ORDER_TYPE_STOP_MARKET,
            stopPrice=str(sl),
            quantity=qty,
            reduceOnly=True
        )
        client.futures_create_order(
            symbol=TRADING_PAIR,
            side=SIDE_SELL if side == SIDE_BUY else SIDE_BUY,
            type=ORDER_TYPE_LIMIT,
            price=str(tp),
            timeInForce=TIME_IN_FORCE_GTC,
            quantity=qty,
            reduceOnly=True
        )
        send_telegram_msg(f"✅ Order {direction.upper()} | Qty: {qty} | SL: {sl} | TP: {tp}")
    except Exception as e:
        send_telegram_msg(f"❌ Gagal Eksekusi: {e}")
# === mikhacuan.py ===

from config import CONFIDENCE_THRESHOLD

def run_mikhacuan_filter(signal, conf, volatility=0.01, sentiment=0.7):
    adjusted = conf
    if sentiment < 0.3:
        adjusted -= 0.1
    elif sentiment > 0.8:
        adjusted += 0.05
    if volatility > 0.03:
        adjusted -= 0.05
    approved = adjusted >= CONFIDENCE_THRESHOLD
    return signal if approved else "HOLD", round(adjusted, 4), approved
# === x12_executor.py ===

from binance.client import Client
from binance.enums import *
from config import *
from telegram import Bot

client = Client(BINANCE_API_KEY, BINANCE_SECRET_KEY)
bot = Bot(token=BOT_TOKEN)

def send_telegram_msg(msg):
    bot.send_message(chat_id=OWNER_ID, text=msg)

def calculate_sl_tp(entry, direction):
    sl = entry * (1 - DEFAULT_SL) if direction == "long" else entry * (1 + DEFAULT_SL)
    tp = entry * (1 + DEFAULT_TP) if direction == "long" else entry * (1 - DEFAULT_TP)
    return round(sl, 2), round(tp, 2)

def calculate_allin_size(entry):
    balance = float(client.futures_account_balance()[0]['balance'])
    usdt = balance * 20
    return round(usdt / entry, 3)

def place_order(direction, qty, entry):
    side = SIDE_BUY if direction == "long" else SIDE_SELL
    sl, tp = calculate_sl_tp(entry, direction)
    try:
        order = client.futures_create_order(
            symbol=TRADING_PAIR,
            side=side,
            type=ORDER_TYPE_MARKET,
            quantity=qty,
            reduceOnly=False
        )
        client.futures_create_order(
            symbol=TRADING_PAIR,
            side=SIDE_SELL if side == SIDE_BUY else SIDE_BUY,
            type=ORDER_TYPE_STOP_MARKET,
            stopPrice=str(sl),
            quantity=qty,
            reduceOnly=True
        )
        client.futures_create_order(
            symbol=TRADING_PAIR,
            side=SIDE_SELL if side == SIDE_BUY else SIDE_BUY,
            type=ORDER_TYPE_LIMIT,
            price=str(tp),
            timeInForce=TIME_IN_FORCE_GTC,
            quantity=qty,
            reduceOnly=True
        )
        send_telegram_msg(f"✅ Order {direction.upper()} | Qty: {qty} | SL: {sl} | TP: {tp}")
    except Exception as e:
        send_telegram_msg(f"❌ Gagal Eksekusi: {e}")
{
  "BTCUSDT": [0.85, 0.12, 0.21],
  "ETHUSDT": [0.74, 0.14, 0.16]
}
[
  {
    "pair": "BTCUSDT",
    "signal": "BUY",
    "confidence": 0.91,
    "timestamp": "2025-08-03 03:15:12 WITA",
    "executed": true
  },
  {
    "pair": "ETHUSDT",
    "signal": "SELL",
    "confidence": 0.88,
    "timestamp": "2025-08-03 03:17:44 WITA",
    "executed": true
  }
]
[
  {
    "pair": "DUCKAIUSDT",
    "type": "SNIPER ALL-IN",
    "entry": 0.000174,
    "status": "FILLED",
    "confidence": 0.93,
    "time": "2025-08-03 03:18:05 WITA"
  }
]
[
  {
    "features": [0.2, 0.15, 0.07],
    "label": 1
  },
  {
    "features": [0.1, 0.3, 0.12],
    "label": 0
  }
]
[
  {
    "pair": "ACEUSDT",
    "user_feedback": "late entry",
    "actual_outcome": "profit",
    "confidence_at_signal": 0.87
  }
]
#!/bin/bash
echo "🚀 Menjalankan MD90 Supreme Scalping Bot..."
python3 main.py
numpy
pandas
scikit-learn
matplotlib
python-telegram-bot==13.15
websockets
requests
aiohttp
schedule
binance
web: python3 main.py
# MD90 Supreme Scalping Bot

Bot trading otomatis untuk strategi scalping dan sniper berbasis AI.  
Fitur:
- Multi-threaded execution
- SL/TP otomatis
- Real-time volume & sentiment analysis
- Telegram Bot untuk kontrol dan notifikasi
- Auto retraining model ML

Deploy ke Railway atau VPS.

Versi: v3.0 FINAL
BINANCE_API_KEY=your_api_key_here
BINANCE_SECRET_KEY=your_secret_key_here
MEXC_API_KEY=your_mexc_key_here
MEXC_SECRET=your_mexc_secret_here
BOT_TOKEN=your_bot_token_here
OWNER_ID=your_owner_id_here
MD90_SCALPING_BOT_VERSION=v3.0.2025-FINAL
BuildDate=2025-08-03
import os
import signal
import psutil

def kill_all_threads():
    current_pid = os.getpid()
    parent = psutil.Process(current_pid)
    for child in parent.children(recursive=True):
        try:
            child.send_signal(signal.SIGTERM)
        except Exception as e:
            print(f"Gagal menghentikan proses: {e}")
    print("🔥 Semua thread dihentikan darurat!")

if __name__ == "__main__":
    kill_all_threads()

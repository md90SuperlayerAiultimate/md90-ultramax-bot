# MD90 Master Ultimax Pack — Agustus 2025 (TANAM PERMANEN)
- Waktu: Asia/Makassar
- Keys: Telegram & Football-data **ditanam**
- Binance/MEXC isi hanya jika LIVE

## Jalankan
```bash
pip install -r requirements.txt
python3 validate_syntax.py   # pastikan no syntax error
bash start.sh
```

## Letakkan Bot Kamu
Taruh file .py bot kamu ke folder:
- `bots/scalping/`
- `bots/compound/`
- `bots/sniper/`
- `bots/parlay/`
- `bots/spaceman/`
- `bots/togel/`

Runner akan otomatis **menjalankan semua .py** di folder tsb.

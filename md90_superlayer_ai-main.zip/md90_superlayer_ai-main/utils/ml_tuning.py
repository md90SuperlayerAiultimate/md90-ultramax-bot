"""
MD90 - ML Tuning
Auto-load parameter dari JSON, update adaptif berdasarkan win rate
"""

import json
import os
from typing import Dict


class MLTuning:
    """
    Machine learning parameter tuning.
    Parameter disimpan di JSON — diperbarui setelah setiap siklus evaluasi.
    """

    DEFAULT_PARAMS: Dict = {
        "min_confidence":  75.0,
        "risk_per_trade":   0.01,
        "atr_sl_mult":      1.2,
        "atr_tp_mult":      1.6,
        "rsi_buy_scalp":   38,
        "rsi_sell_scalp":  62,
        "version":          1.0,
    }

    def __init__(self, config_file: str):
        self.config_file = config_file
        self.params      = self.load_params()

    # ------------------------------------------------------------------
    def load_params(self) -> Dict:
        """Load parameter dari JSON. Jika tidak ada, kembalikan default."""
        params = dict(self.DEFAULT_PARAMS)
        if os.path.exists(self.config_file):
            try:
                with open(self.config_file, "r") as f:
                    saved = json.load(f)
                    params.update(saved)
            except Exception:
                pass
        return params

    def save_params(self) -> None:
        """Simpan parameter ke JSON"""
        try:
            with open(self.config_file, "w") as f:
                json.dump(self.params, f, indent=2)
        except Exception as e:
            print(f"[ML_TUNING] Save error: {e}")

    # ------------------------------------------------------------------
    def update_and_save(self, total_trades: int, avg_win_rate: float) -> None:
        """
        Update parameter berdasarkan performa.
        - win_rate > 0.60 : naikkan risk sedikit
        - win_rate < 0.40 : naikkan threshold confidence, turunkan risk
        """
        if avg_win_rate > 0.60:
            self.params["risk_per_trade"] = min(0.02, self.params["risk_per_trade"] * 1.05)
            print(f"🧠 ML: win_rate tinggi → risk naik ke {self.params['risk_per_trade']:.4f}")
        elif avg_win_rate < 0.40:
            self.params["min_confidence"] = min(90.0, self.params["min_confidence"] + 2.0)
            self.params["risk_per_trade"] = max(0.005, self.params["risk_per_trade"] * 0.95)
            print(f"🧠 ML: win_rate rendah → conf={self.params['min_confidence']:.0f}% "
                  f"risk={self.params['risk_per_trade']:.4f}")

        self.params["version"] = round(self.params.get("version", 1.0) + 0.01, 3)
        self.save_params()
        print(f"🧠 ML Tuning saved (v{self.params['version']:.2f}) "
              f"— trades={total_trades} win_rate={avg_win_rate:.2%}")

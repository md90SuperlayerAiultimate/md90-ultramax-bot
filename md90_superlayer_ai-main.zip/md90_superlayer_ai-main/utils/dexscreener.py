"""
MD90 - DexScreener WebSocket Client
Real-time pair data dari DexScreener via Socket.IO
"""

import asyncio
from typing import Dict, AsyncIterator, Optional

try:
    import socketio
    SOCKETIO_OK = True
except ImportError:
    SOCKETIO_OK = False


class DexScreenerClient:
    """
    WebSocket client untuk real-time data dari DexScreener.
    Memerlukan: pip install python-socketio[asyncio_client]
    """

    BASE_URL = "https://frontend-api.dexscreener.io"

    def __init__(self):
        if not SOCKETIO_OK:
            raise ImportError(
                "python-socketio[asyncio_client] tidak terinstall. "
                "Jalankan: pip install python-socketio[asyncio_client]"
            )
        self.sio       = socketio.AsyncClient(reconnection=True, reconnection_attempts=5)
        self.connected = False
        self._queue: asyncio.Queue = asyncio.Queue()

        @self.sio.event
        async def connect():
            print("✅ DexScreener WebSocket connected")
            self.connected = True

        @self.sio.event
        async def disconnect():
            print("❌ DexScreener WebSocket disconnected")
            self.connected = False

        @self.sio.on("pairs")
        async def on_pairs(data):
            """Terima data pairs dan masukkan ke queue"""
            pairs = data.get("pairs", []) if isinstance(data, dict) else []
            for pair in pairs:
                await self._queue.put(pair)

    # ------------------------------------------------------------------
    async def connect(self) -> None:
        """Hubungkan ke DexScreener WebSocket"""
        await self.sio.connect(self.BASE_URL)

    async def subscribe(self, url: str) -> None:
        """Subscribe ke pair / pool tertentu"""
        await self.sio.emit("subscribe", {"url": url})

    async def disconnect(self) -> None:
        """Putus koneksi"""
        await self.sio.disconnect()

    # ------------------------------------------------------------------
    async def stream(self) -> AsyncIterator[Dict]:
        """
        Generator async — yield pair data satu per satu dari queue.
        Gunakan: async for pair in client.stream(): ...
        """
        while self.connected:
            try:
                pair = await asyncio.wait_for(self._queue.get(), timeout=5.0)
                yield pair
            except asyncio.TimeoutError:
                continue
            except Exception as e:
                print(f"[DEXSCREENER] stream error: {e}")
                break

"""
MD90 - Indikator teknis murni Python (tanpa numpy/pandas)
"""

from collections import deque
from typing import List, Optional


class Indicators:
    """Indikator teknis: RSI, ATR, EMA — pure Python"""

    def __init__(self, rsi_len: int = 14, atr_len: int = 14):
        self.rsi_len = rsi_len
        self.atr_len = atr_len
        self._tr_history: deque = deque(maxlen=atr_len)

    # ------------------------------------------------------------------
    def rsi(self, close: float, closes: List[float]) -> Optional[float]:
        """
        Hitung RSI dari list harga close.
        :param close:  harga close terbaru (unused — sudah termasuk di closes[-1])
        :param closes: list harga close setidaknya rsi_len+1 elemen
        """
        all_closes = list(closes)
        if len(all_closes) < self.rsi_len + 1:
            return None

        # Ambil rsi_len perubahan terakhir
        gains  = []
        losses = []
        for i in range(-self.rsi_len, 0):
            ch = all_closes[i] - all_closes[i - 1]
            gains.append(max(ch, 0.0))
            losses.append(max(-ch, 0.0))

        avg_gain = sum(gains)  / self.rsi_len
        avg_loss = sum(losses) / self.rsi_len

        if avg_loss == 0.0:
            return 100.0
        rs = avg_gain / avg_loss
        return 100.0 - (100.0 / (1.0 + rs))

    # ------------------------------------------------------------------
    def atr(self,
            high:   float, low: float, close: float,
            highs:  List[float],
            lows:   List[float],
            closes: List[float]) -> Optional[float]:
        """
        Hitung ATR dari data historis.
        Membutuhkan minimal atr_len+1 bar.
        """
        if len(highs) < self.atr_len + 1:
            return None

        tr_list = []
        for i in range(-self.atr_len, 0):
            h  = highs[i]
            l  = lows[i]
            pc = closes[i - 1]
            tr = max(h - l, abs(h - pc), abs(l - pc))
            tr_list.append(tr)

        return sum(tr_list) / self.atr_len

    # ------------------------------------------------------------------
    def ema(self, closes: List[float], period: int) -> Optional[float]:
        """Hitung EMA dari list closes"""
        if len(closes) < period:
            return None
        k      = 2.0 / (period + 1)
        ema_val = sum(closes[:period]) / period
        for price in closes[period:]:
            ema_val = price * k + ema_val * (1 - k)
        return ema_val

    def sma(self, closes: List[float], period: int) -> Optional[float]:
        """Hitung SMA"""
        if len(closes) < period:
            return None
        return sum(closes[-period:]) / period

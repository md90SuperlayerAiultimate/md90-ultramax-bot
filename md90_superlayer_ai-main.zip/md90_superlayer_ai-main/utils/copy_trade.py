"""
MD90 - Copy Trade Leaderboard
Consensus sinyal dari top-N trader (simulasi / extensible ke API nyata)
"""

import asyncio
import random
from typing import Dict, List, Optional


class CopyTradeLeaderboard:
    """
    Copy trade dari top-N leaderboard.
    Implementasi nyata: ganti fetch_leaderboard() dengan panggilan
    API exchange (Binance Leaderboard, Bybit Leaderboard, dll.)
    """

    def __init__(self, cfg: Dict):
        self.cfg       = cfg
        self.top_n     = cfg.get("copy_trade_top_n", 5)
        self.leaderboard: List[Dict] = []

    # ------------------------------------------------------------------
    async def fetch_leaderboard(self, symbol: str) -> List[Dict]:
        """
        Fetch leaderboard top-N trader.
        Dummy data — ganti dengan API nyata untuk production.
        """
        # Simulasi delay network
        await asyncio.sleep(0)

        dummy_traders = [
            {"name": "WhaleAlpha",   "win_rate": 78, "total_pnl": 125000,
             "last_signal": "BUY",  "confidence": 85},
            {"name": "CryptoKing",   "win_rate": 72, "total_pnl":  98000,
             "last_signal": "BUY",  "confidence": 80},
            {"name": "SniperElite",  "win_rate": 81, "total_pnl": 142000,
             "last_signal": "SELL", "confidence": 82},
            {"name": "MoonShotter",  "win_rate": 68, "total_pnl":  65000,
             "last_signal": "BUY",  "confidence": 75},
            {"name": "HODLGod",      "win_rate": 65, "total_pnl":  54000,
             "last_signal": "SELL", "confidence": 70},
        ]

        # Urutkan berdasarkan total PnL (desc)
        sorted_traders = sorted(dummy_traders, key=lambda x: x["total_pnl"], reverse=True)
        self.leaderboard = sorted_traders[: self.top_n]
        return self.leaderboard

    # ------------------------------------------------------------------
    async def get_consensus_signal(self, symbol: str) -> Optional[Dict]:
        """Dapatkan sinyal mayoritas dari top-N trader"""
        await self.fetch_leaderboard(symbol)
        if not self.leaderboard:
            return None

        buy_count  = sum(1 for t in self.leaderboard if t["last_signal"] == "BUY")
        sell_count = self.top_n - buy_count
        majority   = "long" if buy_count > sell_count else "short"

        avg_confidence  = sum(t["confidence"] for t in self.leaderboard) / self.top_n
        consensus_ratio = max(buy_count, sell_count) / self.top_n
        confidence      = avg_confidence * consensus_ratio

        return {
            "side":       majority,
            "confidence": round(confidence, 2),
            "source":     "copy_trade_leaderboard",
            "buy_votes":  buy_count,
            "sell_votes": sell_count,
        }

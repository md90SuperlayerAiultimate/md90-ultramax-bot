"""
MD90 - Multi Market Feed
Data OHLCV + price + order execution via CCXT (crypto, forex, index, commodity)
"""

import asyncio
import random
from typing import List, Dict, Optional

try:
    import ccxt
    CCXT_OK = True
except ImportError:
    CCXT_OK = False


class MultiMarketFeed:
    """Feed data multi-market via CCXT (exchange) atau dummy jika dry_run"""

    def __init__(self, cfg: Dict):
        self.cfg           = cfg
        self.exchange      = None
        self.btc_macro_bull = True  # default simulasi

        live = cfg.get("live_mode", False) and not cfg.get("dry_run", True)
        if live and CCXT_OK:
            exchange_id = cfg.get("exchange", "binance")
            try:
                exchange_cls   = getattr(ccxt, exchange_id)
                self.exchange  = exchange_cls({
                    "apiKey":        cfg.get("api_key",    ""),
                    "secret":        cfg.get("api_secret", ""),
                    "enableRateLimit": True,
                })
                print(f"✅ CCXT exchange connected: {exchange_id}")
            except Exception as e:
                print(f"⚠️  CCXT init error ({exchange_id}): {e}")
                self.exchange = None

    # ------------------------------------------------------------------
    async def get_ohlcv(self, symbol: str, timeframe: str, limit: int = 100) -> Optional[List]:
        """
        Ambil data OHLCV.
        Format tiap baris: [timestamp, open, high, low, close, volume]
        """
        if self.exchange:
            try:
                # CCXT fetch_ohlcv adalah synchronous — jalankan di executor
                loop = asyncio.get_event_loop()
                ohlcv = await loop.run_in_executor(
                    None,
                    lambda: self.exchange.fetch_ohlcv(symbol, timeframe=timeframe, limit=limit)
                )
                # Update btc_macro_bull dari data nyata
                if "BTC" in symbol and ohlcv:
                    closes = [c[4] for c in ohlcv]
                    ema50  = sum(closes[-50:]) / 50 if len(closes) >= 50 else closes[-1]
                    self.btc_macro_bull = closes[-1] > ema50
                return ohlcv
            except Exception as e:
                print(f"⚠️  OHLCV fetch error ({symbol}): {e}")
                return self._dummy_ohlcv(symbol, limit)
        else:
            return self._dummy_ohlcv(symbol, limit)

    def _dummy_ohlcv(self, symbol: str, limit: int) -> List:
        """Generate dummy OHLCV untuk paper trading"""
        base = (
            50000 if "BTC" in symbol else
            3000  if "ETH" in symbol else
            150   if "SOL" in symbol else
            1.2   if "EUR" in symbol else
            2000
        )
        data = []
        price = base
        for i in range(limit):
            chg    = random.uniform(-0.015, 0.015)
            o      = price
            h      = o * (1 + abs(chg) * 1.2)
            l      = o * (1 - abs(chg) * 1.2)
            c      = o * (1 + chg)
            vol    = random.uniform(500, 5000)
            data.append([i * 60000, o, h, l, c, vol])
            price  = c
        return data

    # ------------------------------------------------------------------
    async def get_current_price(self, symbol: str) -> float:
        """Ambil harga current"""
        if self.exchange:
            try:
                loop   = asyncio.get_event_loop()
                ticker = await loop.run_in_executor(
                    None, lambda: self.exchange.fetch_ticker(symbol)
                )
                return float(ticker["last"])
            except Exception as e:
                print(f"⚠️  Price fetch error ({symbol}): {e}")
        # Fallback dummy
        base = 50000 if "BTC" in symbol else 3000 if "ETH" in symbol else 150
        return base * random.uniform(0.995, 1.005)

    # ------------------------------------------------------------------
    async def place_order(self,
                          symbol: str, side: str, size: float,
                          price: float, sl: float, tp: float) -> bool:
        """
        Place live order via CCXT.
        Hanya aktif di live_mode=True.
        SL/TP ditempatkan sebagai order terpisah jika exchange mendukung.
        """
        if not self.exchange:
            print(f"⚠️  No exchange connected — order not placed ({symbol} {side} {size})")
            return False
        try:
            loop       = asyncio.get_event_loop()
            order_side = "buy" if side in ("buy", "long") else "sell"
            order = await loop.run_in_executor(
                None,
                lambda: self.exchange.create_market_order(symbol, order_side, size)
            )
            print(f"✅ Order placed: {symbol} {order_side} {size} → {order.get('id', 'N/A')}")
            return True
        except Exception as e:
            print(f"❌ Order error ({symbol}): {e}")
            return False

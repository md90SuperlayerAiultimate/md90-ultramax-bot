"""
MD90 - Fusion Engine
17-layer signal analysis dengan weighted scoring
"""

import math
from datetime import datetime, timezone
from typing import Dict, List


class FusionEngine:
    """
    Mesin analisis fusion 17 layer.
    Layer aktif: 5 core + extensible.
    Status output: 🔥 ALL-IN | ⏸️ WAITING | 🛑 ABORT
    """

    LAYER_NAMES = [
        "RSI",           # 1
        "EMA_CROSS",     # 2
        "VOLUME_SPIKE",  # 3
        "ATR_BREAKOUT",  # 4
        "WHALE_DELTA",   # 5
        "BTC_MACRO",     # 6
        "LIQUIDITY_SWEEP",# 7
        "TREND_5M",      # 8
        "TREND_1H",      # 9
        "MOMENTUM",      # 10
        "VWAP_BIAS",     # 11
        "SPREAD_OK",     # 12
        "SESSION_BIAS",  # 13
        "OB_CONFLUENCE", # 14
        "FVG_FILL",      # 15
        "MSB_BOS",       # 16
        "SENTIMENT",     # 17
    ]

    LAYER_WEIGHTS = {
        "RSI":           0.10,
        "EMA_CROSS":     0.10,
        "VOLUME_SPIKE":  0.08,
        "ATR_BREAKOUT":  0.07,
        "WHALE_DELTA":   0.08,
        "BTC_MACRO":     0.10,
        "LIQUIDITY_SWEEP":0.07,
        "TREND_5M":      0.06,
        "TREND_1H":      0.08,
        "MOMENTUM":      0.06,
        "VWAP_BIAS":     0.05,
        "SPREAD_OK":     0.03,
        "SESSION_BIAS":  0.03,
        "OB_CONFLUENCE": 0.03,
        "FVG_FILL":      0.02,
        "MSB_BOS":       0.02,
        "SENTIMENT":     0.02,
    }

    def __init__(self, cfg: Dict):
        self.cfg           = cfg
        self.timestamp     = datetime.now(timezone.utc).isoformat()

    # ------------------------------------------------------------------
    def _score_layer(self, name: str, market_data: Dict) -> float:
        """
        Return skor layer: 1.0=BUY, -1.0=SELL, 0.0=NEUTRAL
        """
        price   = market_data.get("current_price", 0)
        rsi     = market_data.get("rsi", 50.0)
        atr     = market_data.get("atr", price * 0.005)
        atr_avg = market_data.get("atr_avg", atr)

        if name == "RSI":
            if rsi < 35:    return 1.0
            if rsi > 65:    return -1.0
            return 0.0

        if name == "EMA_CROSS":
            ema20 = market_data.get("ema20", price)
            if price > ema20: return 1.0
            if price < ema20: return -1.0
            return 0.0

        if name == "VOLUME_SPIKE":
            return 1.0 if market_data.get("volume_spike", False) else 0.0

        if name == "ATR_BREAKOUT":
            return 1.0 if (atr > atr_avg * 1.1) else -0.5

        if name == "WHALE_DELTA":
            delta = market_data.get("whale_delta", 0)
            if delta > 0:  return 1.0
            if delta < 0:  return -1.0
            return 0.0

        if name == "BTC_MACRO":
            return 1.0 if market_data.get("btc_macro_bull", False) else -0.5

        if name == "LIQUIDITY_SWEEP":
            return 1.0 if market_data.get("liquidity_sweep", False) else 0.0

        if name == "TREND_5M":
            t = market_data.get("trend_5m", 0)
            return float(max(-1.0, min(1.0, t)))

        if name == "TREND_1H":
            t = market_data.get("trend_1h", 0)
            return float(max(-1.0, min(1.0, t)))

        if name == "MOMENTUM":
            mom = market_data.get("momentum", 0)
            if mom > 0:  return 1.0
            if mom < 0:  return -1.0
            return 0.0

        if name == "VWAP_BIAS":
            vwap = market_data.get("vwap", price)
            if price > vwap * 1.001:  return 1.0
            if price < vwap * 0.999:  return -1.0
            return 0.0

        if name == "SPREAD_OK":
            spread_pct = market_data.get("spread_pct", 0.0)
            return 1.0 if spread_pct < 0.1 else -1.0

        if name == "SESSION_BIAS":
            return float(market_data.get("session_bias", 0))

        if name == "OB_CONFLUENCE":
            return float(market_data.get("ob_confluence", 0))

        if name == "FVG_FILL":
            return float(market_data.get("fvg_fill", 0))

        if name == "MSB_BOS":
            return float(market_data.get("msb_bos", 0))

        if name == "SENTIMENT":
            sent = market_data.get("sentiment", 0.5)
            if sent > 0.6:  return 1.0
            if sent < 0.4:  return -1.0
            return 0.0

        return 0.0

    # ------------------------------------------------------------------
    def analyze(self, market_data: Dict) -> Dict:
        """
        Jalankan semua 17 layer, hitung weighted fusion score.
        Return: status, direction, fusion_score, confidence, layer_results
        """
        layer_results: Dict[str, float] = {}
        weighted_sum  = 0.0
        total_weight  = 0.0

        for name in self.LAYER_NAMES:
            score  = self._score_layer(name, market_data)
            weight = self.LAYER_WEIGHTS.get(name, 0.0)
            layer_results[name] = score
            weighted_sum  += score  * weight
            total_weight  += abs(weight)

        # Normalise ke -1..+1
        fusion_score = weighted_sum / total_weight if total_weight > 0 else 0.0
        fusion_score = max(-1.0, min(1.0, fusion_score))

        direction = "BUY" if fusion_score > 0 else ("SELL" if fusion_score < 0 else "NEUTRAL")
        abs_score = abs(fusion_score)

        # Confidence 0-100
        confidence = abs_score * 100.0
        if market_data.get("btc_macro_bull", False):
            confidence = min(100.0, confidence + 5.0)
        if market_data.get("liquidity_sweep", False):
            confidence = min(100.0, confidence + 5.0)

        min_conf   = self.cfg.get("min_confidence",   75.0)
        min_fusion = self.cfg.get("min_fusion_score",  0.75)

        if confidence >= min_conf and abs_score >= min_fusion:
            status = "🔥 ALL-IN" if confidence >= 85.0 else "⏸️ WAITING"
        else:
            status = "🛑 ABORT"

        return {
            "status":        status,
            "direction":     direction,
            "fusion_score":  round(fusion_score, 4),
            "confidence":    round(confidence, 2),
            "layer_results": layer_results,
        }

"""
MD90 - Risk Manager
Kill switch, consecutive loss guard, confidence filter
"""

from typing import Dict


class RiskManager:
    """Risk management dengan kill switch otomatis"""

    def __init__(self,
                 max_consecutive_losses: int = 3,
                 min_confidence: float = 52.0,
                 max_liquidity_risk: float = 20.0):
        self.max_losses          = max_consecutive_losses
        self.min_confidence      = min_confidence
        self.max_liquidity_risk  = max_liquidity_risk
        self.consecutive_losses  = 0
        self.kill_switch_triggered = False

    # ------------------------------------------------------------------
    async def check(self, phase: str, confidence: float, liquidity_risk: float) -> bool:
        """Validasi sinyal sebelum eksekusi"""
        if phase not in ("ACCUMULATION_MACRO", "ALPHA_BUILDING"):
            print(f"   ❌ Phase check failed: {phase}")
            return False
        if confidence < self.min_confidence:
            print(f"   ❌ Confidence too low: {confidence:.1f}% < {self.min_confidence:.1f}%")
            return False
        if liquidity_risk > self.max_liquidity_risk:
            print(f"   ❌ Liquidity risk too high: {liquidity_risk:.1f} > {self.max_liquidity_risk:.1f}")
            return False
        return True

    def record_loss(self) -> None:
        """Catat loss dan aktifkan kill switch jika threshold terlampaui"""
        self.consecutive_losses += 1
        if self.consecutive_losses >= self.max_losses:
            self.kill_switch_triggered = True
            print(f"🛑 KILL SWITCH: {self.consecutive_losses} consecutive losses")

    def record_win(self) -> None:
        """Reset consecutive loss counter setelah win"""
        self.consecutive_losses = 0

    def reset(self) -> None:
        """Reset penuh — manual override"""
        self.consecutive_losses    = 0
        self.kill_switch_triggered = False

    def status(self) -> Dict:
        return {
            "consecutive_losses":    self.consecutive_losses,
            "kill_switch_triggered": self.kill_switch_triggered,
            "min_confidence":        self.min_confidence,
            "max_losses":            self.max_losses,
        }

"""
MD90 - Jupiter Executor
Swap via Jupiter aggregator untuk Solana DEX trading.
Memerlukan: pip install solana solders
"""

from typing import Optional

try:
    import aiohttp
    from solana.rpc.async_api import AsyncClient
    from solders.keypair import Keypair
    from solders.transaction import VersionedTransaction
    SOLANA_OK = True
except ImportError:
    SOLANA_OK = False


class JupiterExecutor:
    """
    Eksekusi swap via Jupiter aggregator (Solana).
    Hanya tersedia jika solana + solders terinstall.
    """

    BASE_URL = "https://quote-api.jup.ag/v6"

    def __init__(self, rpc_client=None, wallet=None):
        if not SOLANA_OK:
            raise ImportError(
                "solana dan solders tidak terinstall. "
                "Jalankan: pip install solana solders"
            )
        self.rpc_client = rpc_client
        self.wallet     = wallet

    # ------------------------------------------------------------------
    async def get_quote(self,
                        input_mint: str,
                        output_mint: str,
                        amount: int,
                        slippage_bps: int = 50) -> Optional[dict]:
        """Dapatkan quote swap dari Jupiter"""
        params = {
            "inputMint":   input_mint,
            "outputMint":  output_mint,
            "amount":      amount,
            "slippageBps": slippage_bps,
        }
        async with aiohttp.ClientSession() as session:
            async with session.get(f"{self.BASE_URL}/quote", params=params) as resp:
                if resp.status == 200:
                    return await resp.json()
                print(f"[JUPITER] Quote error: {resp.status}")
                return None

    async def execute_swap(self, quote: dict) -> str:
        """Eksekusi swap dan return transaction signature"""
        payload = {
            "quoteResponse":             quote,
            "userPublicKey":             str(self.wallet.pubkey()),
            "wrapAndUnwrapSol":          True,
            "dynamicComputeUnitLimit":   True,
            "prioritizationFeeLamports": "auto",
        }
        async with aiohttp.ClientSession() as session:
            async with session.post(f"{self.BASE_URL}/swap", json=payload) as resp:
                swap_data = await resp.json()

        transaction_bytes = bytes.fromhex(swap_data["swapTransaction"])
        tx         = VersionedTransaction.from_bytes(transaction_bytes)
        signed_tx  = VersionedTransaction(tx.message, [self.wallet])
        result     = await self.rpc_client.send_transaction(
            signed_tx, opts={"skip_preflight": True}
        )
        return str(result.value)

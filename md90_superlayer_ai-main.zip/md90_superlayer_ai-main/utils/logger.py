import logging
import os
from config import LOG_DIR

def setup_logger(name="MD90_Bot"):
    if not os.path.exists(LOG_DIR):
        os.makedirs(LOG_DIR)
    
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    
    # Log ke file
    file_handler = logging.FileHandler(os.path.join(LOG_DIR, 'bot_activity.log'))
    file_handler.setFormatter(formatter)
    
    # Log ke console/terminal
    stream_handler = logging.StreamHandler()
    stream_handler.setFormatter(formatter)
    
    if not logger.handlers:
        logger.addHandler(file_handler)
        logger.addHandler(stream_handler)
        
    return logger

def log_event(message, level="info"):
    logger = logging.getLogger("MD90_Bot")
    if level == "info":
        logger.info(message)
    elif level == "error":
        logger.error(message)
"""
MD90 ALLIN FUSION - Utils Package
"""

from .risk import RiskManager
from .logger import setup_logger, log_event
from .fusion_engine import FusionEngine
from .kimi_soccer import KimiSoccerAnalyzer
from .copy_trade import CopyTradeLeaderboard
from .ml_tuning import MLTuning
from .multi_market_feed import MultiMarketFeed
from .indicators import Indicators

# DexScreener — requires python-socketio[asyncio_client]
try:
    from .dexscreener import DexScreenerClient
except ImportError:
    DexScreenerClient = None  # type: ignore

# Jupiter + Jito — requires solana / solders (Solana chain only)
try:
    from .jupiter import JupiterExecutor
except ImportError:
    JupiterExecutor = None   # type: ignore

try:
    from .jito import JitoClient
except ImportError:
    JitoClient = None        # type: ignore

__all__ = [
    "RiskManager",
    "setup_logger",
    "log_event",
    "FusionEngine",
    "KimiSoccerAnalyzer",
    "CopyTradeLeaderboard",
    "MLTuning",
    "MultiMarketFeed",
    "Indicators",
    "DexScreenerClient",
    "JupiterExecutor",
    "JitoClient",
]

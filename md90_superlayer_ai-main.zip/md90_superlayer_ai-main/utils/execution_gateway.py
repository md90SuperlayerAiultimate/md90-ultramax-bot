import time, hmac, hashlib, requests
from urllib.parse import urlencode
from config import EXECUTION_MODE, BINANCE_BASE, BINANCE_API_KEY, BINANCE_SECRET
from utils.logger import log_event

def place_order(symbol, side, qty, price=None, order_type="MARKET"):
    if EXECUTION_MODE == "PAPER":
        log_event({"mode":"PAPER","symbol":symbol,"side":side,"qty":qty,"price":price,"type":order_type,"status":"ACK"}, "orders")
        return {"paper": True, "status": "ACK"}
    # LIVE (Binance Spot example)
    ts = int(time.time()*1000)
    params = {"symbol": symbol, "side": side, "type": order_type, "timestamp": ts}
    if order_type == "MARKET":
        params["quantity"] = qty
    elif order_type == "LIMIT":
        params["timeInForce"] = "GTC"; params["quantity"]=qty; params["price"]=price
    query = urlencode(params)
    sig = hmac.new(BINANCE_SECRET.encode(), query.encode(), hashlib.sha256).hexdigest()
    headers = {"X-MBX-APIKEY": BINANCE_API_KEY}
    url = f"{BINANCE_BASE}/api/v3/order?{query}&signature={sig}"
    r = requests.post(url, headers=headers, timeout=10)
    r.raise_for_status()
    resp = r.json()
    log_event({"mode":"LIVE","resp":resp}, "orders")
    return resp

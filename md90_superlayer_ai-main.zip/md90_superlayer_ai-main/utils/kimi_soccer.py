"""
MD90 - KIMI Soccer Analyzer v3.1
Prediksi sepak bola: O/U, BTTS, Corner, Asian Handicap
Framework 5 langkah dengan QLR (Quality League Ratio)
"""

import math
from typing import Dict, List, Optional


class KimiSoccerAnalyzer:
    """
    Analisis prediktif sepak bola dengan framework KIMI v3.1.
    Output: Over/Under, BTTS, Corner, Asian Handicap, VPI (Value Bet Index)
    """

    def __init__(self, cfg: Dict):
        self.league_avg_goals   = cfg.get("league_avg_goals",   2.5)
        self.league_avg_corners = cfg.get("league_avg_corners", 10.0)
        self.verbose            = True

    # ------------------------------------------------------------------
    def verify_data(self, match_data: Dict) -> bool:
        required = [
            "home_team", "away_team",
            "odds_home", "odds_draw", "odds_away",
            "form_home", "form_away", "h2h_results",
        ]
        for key in required:
            if key not in match_data:
                if self.verbose:
                    print(f"❌ Missing data: {key}")
                return False
        return True

    # ------------------------------------------------------------------
    def calculate_clr(self, match_data: Dict) -> Dict:
        """QLR = Quality League Ratio — perbandingan kekuatan relatif"""
        home_gf = match_data.get("home_goals_scored_avg",    1.2)
        away_ga = match_data.get("away_goals_conceded_avg",  1.2)
        HAI     = home_gf / self.league_avg_goals
        ADI     = away_ga / self.league_avg_goals
        QLR     = HAI / ADI if ADI > 0 else 1.0

        if QLR > 1.30:
            interp = "Home Dominan (⚠️ Favorite Trap!)"
        elif 1.10 <= QLR <= 1.30:
            interp = "Home Unggul (aman)"
        elif 0.90 <= QLR < 1.10:
            interp = "Seimbang (TARGET TERBAIK)"
        elif 0.70 <= QLR < 0.90:
            interp = "Away Unggul (value)"
        else:
            interp = "Away Dominan (hati-hati)"

        return {"HAI": HAI, "ADI": ADI, "QLR": QLR, "interpretasi": interp}

    # ------------------------------------------------------------------
    def momentum_factor(self, match_data: Dict, clr: Dict) -> float:
        adj = 0.0
        form_home = match_data.get("form_home", [])
        form_away = match_data.get("form_away", [])

        if len(form_home) >= 5 and form_home.count("W") >= 4:
            adj += 0.05
        if len(form_away) >= 5 and form_away.count("W") >= 4:
            adj -= 0.05

        # Desperation Index (relegation / title race)
        home_pos    = match_data.get("home_league_position", 10)
        away_pos    = match_data.get("away_league_position", 10)
        total_teams = match_data.get("league_teams", 20)
        if home_pos <= 4:
            adj += 0.05
        elif home_pos >= total_teams - 2:
            adj += 0.10
        if away_pos <= 4:
            adj -= 0.05
        elif away_pos >= total_teams - 2:
            adj -= 0.10

        # Days of Rest
        dor_home = match_data.get("days_of_rest_home", 3)
        dor_away = match_data.get("days_of_rest_away", 3)
        if dor_home - dor_away >= 2:
            adj += 0.03
        elif dor_away - dor_home >= 2:
            adj -= 0.03

        # Streak & injuries
        if match_data.get("home_win_streak", 0) >= 3:
            adj += 0.05
        if match_data.get("away_win_streak", 0) >= 3:
            adj -= 0.05
        if match_data.get("injuries_home_count", 0) >= 5:
            adj -= 0.05
        if match_data.get("injuries_away_count", 0) >= 5:
            adj += 0.05

        return adj

    # ------------------------------------------------------------------
    def generate_outputs(self, match_data: Dict, clr: Dict, momentum_adj: float) -> Dict:
        QLR = clr["QLR"]
        home_avg_gf = match_data.get("home_goals_scored_avg",    1.2)
        away_avg_gf = match_data.get("away_goals_scored_avg",    1.0)
        home_avg_ga = match_data.get("home_goals_conceded_avg",  1.2)
        away_avg_ga = match_data.get("away_goals_conceded_avg",  1.2)
        total_expected = (home_avg_gf + away_avg_gf + home_avg_ga + away_avg_ga) / 2

        # Over / Under
        if total_expected < 2.2 or (home_avg_gf < 1.5 and away_avg_gf < 1.5):
            ou = {"pick": "Under 2.5", "reason": "Kedua tim produktivitas rendah"}
        elif home_avg_gf > 2.0 or away_avg_gf > 2.0:
            ou = {"pick": "Over 2.5",  "reason": "Salah satu tim subur gol"}
        else:
            ou = {"pick": "Under 2.5", "reason": "Seimbang, cenderung rendah"}

        # BTTS
        home_xg  = home_avg_gf * 1.1
        away_xg  = away_avg_gf * 1.1
        home_xga = home_avg_ga
        away_xga = away_avg_ga
        if home_xg > 1.2 and away_xg > 1.2 and home_xga < 1.3 and away_xga < 1.3:
            btts = {"pick": "Yes", "reason": "Keduanya punya daya gedor & defense rapuh"}
        elif home_xga > 1.3 or away_xga > 1.3:
            btts = {"pick": "Yes", "reason": "Salah satu defense bocor"}
        else:
            btts = {"pick": "No",  "reason": "Salah satu tim solid bertahan"}

        # Corner
        home_corner  = match_data.get("home_corners_avg", 5.0)
        away_corner  = match_data.get("away_corners_avg", 4.5)
        total_corner = home_corner + away_corner
        if total_corner > 10.5:
            corner = {"pick": "Over 10.5", "reason": "Tim main direct/wing play"}
        elif total_corner > 9.5:
            corner = {"pick": "Over 9.5",  "reason": "Rata-rata corner tinggi"}
        else:
            corner = {"pick": "Under 9.5", "reason": "Possession-based, sedikit corner"}

        # Asian Handicap
        if 1.10 <= QLR <= 1.25:
            asian = {"pick": "Home -0.5",    "reason": f"QLR {QLR:.2f} cukup unggul"}
        elif QLR < 0.90:
            asian = {"pick": "Away +0.5",    "reason": f"QLR {QLR:.2f} away value"}
        elif 0.95 <= QLR <= 1.05:
            asian = {"pick": "Draw No Bet",  "reason": "Seimbang, aman"}
        else:
            asian = {"pick": "Skip",         "reason": "Tidak ada value jelas"}

        best = "asian" if asian["pick"] != "Skip" else "ou"
        return {"ou": ou, "btts": btts, "corner": corner, "asian": asian, "best_pick": best}

    # ------------------------------------------------------------------
    def calculate_confidence(self, match_data: Dict, clr: Dict, outputs: Dict) -> float:
        conf = 70.0
        if match_data.get("h2h_recent_wins_home", 0) >= 3:
            conf += 5
        form_home = match_data.get("form_home", [])
        form_away = match_data.get("form_away", [])
        if len(form_home) >= 5 and form_home.count("W") >= 3:
            conf += 5
        if len(form_away) >= 5 and form_away.count("L") >= 3:
            conf += 5
        if match_data.get("injuries_home_count", 0) <= 2 and match_data.get("injuries_away_count", 0) <= 2:
            conf += 5

        QLR       = clr["QLR"]
        odds_home = match_data.get("odds_home", 1.5)
        if QLR > 2.0 or match_data.get("home_win_streak", 0) > 5 or odds_home < 1.10:
            conf -= 15
        if match_data.get("home_possession_avg", 50) > 60 and match_data.get("home_xg_avg", 1.0) < 1.5:
            conf -= 10

        return max(0.0, min(100.0, conf))

    # ------------------------------------------------------------------
    def analyze_referee(self, match_data: Dict) -> Dict:
        name      = match_data.get("referee", "Unknown")
        avg_cards = match_data.get("referee_avg_cards", 4.5)
        style     = ("Agresif ⚡" if avg_cards > 5.5 else
                     "Lembut 🕊️"  if avg_cards < 3.5 else "Normal")
        return {"name": name, "avg_cards": avg_cards, "style": style}

    def analyze_corners(self, match_data: Dict) -> Dict:
        home_for     = match_data.get("home_corners_avg",          5.0)
        home_against = match_data.get("home_corners_conceded_avg", 4.0)
        away_for     = match_data.get("away_corners_avg",          4.5)
        away_against = match_data.get("away_corners_conceded_avg", 4.5)
        total_avg    = (home_for + away_for + home_against + away_against) / 2

        if total_avg > 10.5:
            pick, eff = "Over 10.5", 75
        elif total_avg > 9.5:
            pick, eff = "Over 9.5",  65
        else:
            pick, eff = "Under 9.5", 70

        return {"total_avg": total_avg, "pick": pick, "efficiency": eff}

    def value_bet_index(self, match_data: Dict, clr: Dict) -> float:
        odds_home = match_data.get("odds_home", 2.0)
        implied   = 1 / odds_home if odds_home > 0 else 1.0
        QLR       = clr["QLR"]
        stat      = 0.65 if QLR > 1.3 else (0.55 if QLR > 1.1 else (0.45 if QLR > 0.9 else 0.35))
        return stat / implied if implied > 0 else 1.0

    # ------------------------------------------------------------------
    def analyze_match(self, match_data: Dict) -> Dict:
        if not self.verify_data(match_data):
            return {"error": "Data tidak lengkap"}

        clr          = self.calculate_clr(match_data)
        momentum_adj = self.momentum_factor(match_data, clr)
        outputs      = self.generate_outputs(match_data, clr, momentum_adj)
        confidence   = self.calculate_confidence(match_data, clr, outputs)
        referee      = self.analyze_referee(match_data)
        corner_pred  = self.analyze_corners(match_data)
        vpi          = self.value_bet_index(match_data, clr)
        value_status = "VALUE" if vpi > 1.05 else "NO VALUE"

        return {
            "match":             f"{match_data['home_team']} vs {match_data['away_team']}",
            "competition":       match_data.get("competition", "Unknown"),
            "kickoff":           match_data.get("kickoff_time", "N/A"),
            "qlr":               round(clr["QLR"], 2),
            "qlr_interp":        clr["interpretasi"],
            "confidence":        round(confidence),
            "outputs":           outputs,
            "odds_1x2":          (
                                    match_data.get("odds_home", 0),
                                    match_data.get("odds_draw", 0),
                                    match_data.get("odds_away", 0),
                                 ),
            "value_status":      value_status,
            "vpi":               round(vpi, 3),
            "referee":           referee,
            "corner_prediction": corner_pred,
            "risk_assessment":   match_data.get("risk_factor", "Tidak ada faktor kritis"),
            "stake_recommendation": (
                "1u" if confidence < 75 else
                "3u" if confidence >= 80 else "2u"
            ),
        }

    # ------------------------------------------------------------------
    def print_report(self, result: Dict) -> None:
        if "error" in result:
            print(f"❌ {result['error']}")
            return
        sep = "=" * 70
        print(f"\n{sep}")
        print(f"🏆 {result['competition']} – {result['match']} – Kick-off: {result['kickoff']}")
        print(f"QLR: {result['qlr']} ({result['qlr_interp']})")
        print(f"Confidence: {result['confidence']}%")
        print(f"Value Bet Index (VPI): {result['vpi']} – {result['value_status']}")
        print("-" * 70)
        print("📊 4 OUTPUT BETTING:")
        o = result["outputs"]
        print(f"1. O/U:     {o['ou']['pick']}     | {o['ou']['reason']}")
        print(f"2. BTTS:    {o['btts']['pick']}    | {o['btts']['reason']}")
        print(f"3. Corner:  {o['corner']['pick']}  | {o['corner']['reason']}")
        print(f"4. Asian H: {o['asian']['pick']}   | {o['asian']['reason']}")
        if o.get("best_pick"):
            best = o[o["best_pick"]]
            print(f"🔥 BEST PICK: {best['pick']}")
        print("-" * 70)
        r = result["referee"]
        cp = result["corner_prediction"]
        print(f"🃏 Wasit: {r['name']} – Avg kartu {r['avg_cards']} – Gaya: {r['style']}")
        print(f"📐 Corner: {cp['pick']} (Efisiensi {cp['efficiency']}%)")
        print(f"⚠️  Risk: {result['risk_assessment']}")
        print(f"💰 Stake: {result['stake_recommendation']}")
        print(f"{sep}\n")

import datetime, pytz
from collections import deque
from config import TIMEZONE, RISK_CAP_DAILY, COOLDOWN_MINUTES_AFTER_2SL
tz = pytz.timezone(TIMEZONE)

class RiskGuardian:
    def __init__(self, equity_fn):
        self.equity_fn = equity_fn
        self.start_equity = equity_fn()
        self.sl_times = deque(maxlen=5)
        self.cooldown_until = None
    def now(self): return datetime.datetime.now(tz)
    def daily_ok(self):
        eq = self.equity_fn()
        max_loss = self.start_equity * RISK_CAP_DAILY
        return (self.start_equity - eq) <= max_loss
    def register(self, outcome):
        if outcome == "SL":
            self.sl_times.append(self.now())
            if len(self.sl_times)>=2 and (self.sl_times[-1]-self.sl_times[-2]).seconds < 3600:
                self.cooldown_until = self.now() + datetime.timedelta(minutes=COOLDOWN_MINUTES_AFTER_2SL)
    def in_cooldown(self):
        return self.cooldown_until and self.now() < self.cooldown_until

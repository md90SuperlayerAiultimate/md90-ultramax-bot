"""
MD90 - Jito Client
Kirim bundle transaksi ke Jito Block Engine (MEV protection, Solana)
"""

from typing import List

try:
    import aiohttp
    AIOHTTP_OK = True
except ImportError:
    AIOHTTP_OK = False


class JitoClient:
    """
    Client untuk mengirim bundle ke Jito Block Engine.
    Digunakan untuk MEV-protected execution di Solana.
    """

    def __init__(self, block_engine_url: str):
        if not AIOHTTP_OK:
            raise ImportError("aiohttp tidak terinstall. Jalankan: pip install aiohttp")
        self.block_engine_url = block_engine_url

    async def send_bundle(self, transactions: List[str]) -> str:
        """
        Kirim bundle transaksi (base58-encoded) ke Jito.
        Return: bundle ID dari block engine.
        """
        payload = {
            "jsonrpc": "2.0",
            "id":      1,
            "method":  "sendBundle",
            "params":  [transactions],
        }
        async with aiohttp.ClientSession() as session:
            async with session.post(self.block_engine_url, json=payload) as resp:
                result = await resp.json()
                bundle_id = result.get("result", "")
                print(f"✅ Jito bundle sent: {bundle_id}")
                return bundle_id

    async def get_bundle_status(self, bundle_id: str) -> dict:
        """Cek status bundle yang sudah dikirim"""
        payload = {
            "jsonrpc": "2.0",
            "id":      1,
            "method":  "getBundleStatuses",
            "params":  [[bundle_id]],
        }
        async with aiohttp.ClientSession() as session:
            async with session.post(self.block_engine_url, json=payload) as resp:
                return await resp.json()
